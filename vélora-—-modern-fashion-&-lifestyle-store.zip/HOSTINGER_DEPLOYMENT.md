# Hostinger Deployment Guide — VÉLORA E-Commerce Platform

## 1. Build for Production
Run the production build locally or in CI:

```bash
npm install
npm run build
```

This generates the static production bundle inside the `dist/` directory, including compiled assets, `index.html`, `.htaccess`, `robots.txt`, and `sitemap.xml`.

## 2. Upload to Hostinger
1. Log in to **hPanel** on Hostinger and open **File Manager** (or connect via FTP/SFTP).
2. Navigate to `public_html/` for your domain (or the subfolder/domain directory).
3. Upload the entire contents of `dist/` directly into `public_html/` (ensure `index.html` and `.htaccess` sit in the root of `public_html/`).
4. Confirm hidden files are visible in File Manager so `.htaccess` is present.

## 3. SPA Routing & Direct URLs
`public/.htaccess` is automatically copied to `dist/.htaccess` during `vite build`. It ensures direct visits or page refreshes on routes like `/shop`, `/product/classic-premium-hoodie`, `/checkout`, or `/about` route cleanly to `index.html` without returning 404 errors.

## 4. Connecting a Production Backend & Payment Gateway
- **Database**: Implement the `StoreDataAdapter` interface in `src/services/storeAdapter.ts` with Firebase Firestore or Supabase client SDKs (using environment variables prefixed with `VITE_` for public client keys only).
- **Payments**: Never store secret keys in frontend code. Connect the `OnlinePaymentGateway` hook in `src/pages/CheckoutPage.tsx` to a serverless endpoint or Node/Express backend verifying Stripe/PayPal/Checkout webhooks before marking orders paid.
