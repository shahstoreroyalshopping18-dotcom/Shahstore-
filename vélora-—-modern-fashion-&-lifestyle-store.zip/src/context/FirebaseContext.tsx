import {
  doc,
  getDoc,
} from 'firebase/firestore';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  User,
} from 'firebase/auth';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from 'react';
import { auth, db, googleProvider, OWNER_EMAIL } from '../firebase';

interface FirebaseContextValue {
  user: User | null;
  isAuthReady: boolean;
  isAdmin: boolean;
  authError: string | null;
  isSigningIn: boolean;
  signInAsOwner: () => Promise<boolean>;
  signOutOwner: () => Promise<void>;
  clearAuthError: () => void;
}

const FirebaseContext = createContext<FirebaseContextValue | undefined>(undefined);

async function verifyAdminStatus(currentUser: User | null): Promise<boolean> {
  if (!currentUser || !currentUser.emailVerified) return false;
  if (currentUser.email?.toLowerCase() === OWNER_EMAIL.toLowerCase()) {
    return true;
  }
  try {
    const adminSnap = await getDoc(doc(db, 'admins', currentUser.uid));
    return adminSnap.exists();
  } catch {
    return false;
  }
}

export function FirebaseProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);

  useEffect(() => {
    let active = true;
    const unsubscribe = onAuthStateChanged(auth, async (nextUser) => {
      if (!active) return;
      setUser(nextUser);
      const adminFlag = await verifyAdminStatus(nextUser);
      if (!active) return;
      setIsAdmin(adminFlag);
      setIsAuthReady(true);
    });
    return () => {
      active = false;
      unsubscribe();
    };
  }, []);

  const signInAsOwner = useCallback(async (): Promise<boolean> => {
    setAuthError(null);
    setIsSigningIn(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const signedInUser = result.user;
      const adminFlag = await verifyAdminStatus(signedInUser);
      setUser(signedInUser);
      setIsAdmin(adminFlag);
      if (!adminFlag) {
        setAuthError(
          `Signed in as ${signedInUser.email || 'this account'}, which does not have store owner permissions.`
        );
        return false;
      }
      return true;
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'Unable to complete Google sign-in.';
      if (!message.includes('popup-closed-by-user')) {
        setAuthError(message);
      }
      return false;
    } finally {
      setIsSigningIn(false);
    }
  }, []);

  const signOutOwner = useCallback(async () => {
    setAuthError(null);
    await signOut(auth);
    setUser(null);
    setIsAdmin(false);
  }, []);

  const clearAuthError = useCallback(() => setAuthError(null), []);

  return (
    <FirebaseContext.Provider
      value={{
        user,
        isAuthReady,
        isAdmin,
        authError,
        isSigningIn,
        signInAsOwner,
        signOutOwner,
        clearAuthError,
      }}
    >
      {children}
    </FirebaseContext.Provider>
  );
}

export function useFirebase(): FirebaseContextValue {
  const ctx = useContext(FirebaseContext);
  if (!ctx) {
    throw new Error('useFirebase must be used within a FirebaseProvider');
  }
  return ctx;
}
