import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { STORE_CONFIG } from '../config/storeConfig';
import { PRODUCTS } from '../data/products';
import {
  createFirestoreOrder,
  deleteFirestoreOrder,
  FirestoreCatalogRecord,
  removeCatalogProductDoc,
  saveSocialSettings,
  subscribeCatalogProducts,
  subscribeOwnerOrders,
  subscribeSocialSettings,
  updateFirestoreOrderStatus,
  upsertCatalogProduct,
} from '../services/firestoreStore';
import { localStoreAdapter, SocialLinksConfig } from '../services/storeAdapter';
import {
  CartItem,
  CustomerInfo,
  Order,
  OrderStatus,
  PaymentMethodId,
  Product,
  WishlistItem,
} from '../types/ecommerce';
import { useFirebase } from './FirebaseContext';

interface StoreContextValue {
  products: Product[];
  customProducts: Product[];
  deletedDefaultProducts: Product[];
  socialLinks: SocialLinksConfig;
  cart: CartItem[];
  wishlist: WishlistItem[];
  orders: Order[];
  ownerOrders: Order[];
  lastOrder: Order | null;
  cartCount: number;
  wishlistCount: number;
  subtotal: number;
  shippingCost: number;
  total: number;
  amountToFreeShipping: number;
  isCartDrawerOpen: boolean;
  isSearchOpen: boolean;
  toastMessage: string | null;
  isCatalogLoading: boolean;
  localDraftCount: number;
  setIsCartDrawerOpen: (open: boolean) => void;
  setIsSearchOpen: (open: boolean) => void;
  addProduct: (product: Product) => Promise<void>;
  updateProduct: (product: Product) => Promise<void>;
  deleteProduct: (productId: string) => Promise<void>;
  deleteCustomProduct: (productId: string) => Promise<void>;
  restoreDefaultProduct: (productId: string) => Promise<void>;
  restoreAllDefaultProducts: () => Promise<void>;
  updateSocialLinks: (links: SocialLinksConfig) => Promise<void>;
  resetSocialLinks: () => Promise<void>;
  syncLocalDraftsToLiveStore: () => Promise<void>;
  discardLocalDrafts: () => void;
  updateOrderStatus: (orderId: string, status: OrderStatus) => Promise<void>;
  deleteOrderRecord: (orderId: string) => Promise<void>;
  addToCart: (
    product: Product,
    options?: { quantity?: number; size?: string; color?: string; openDrawer?: boolean }
  ) => void;
  updateQuantity: (itemKey: string, quantity: number) => void;
  removeFromCart: (itemKey: string) => void;
  clearCart: () => void;
  isInWishlist: (productId: string) => boolean;
  toggleWishlist: (productId: string, productName?: string) => void;
  placeDemoOrder: (customer: CustomerInfo, paymentMethod: PaymentMethodId) => Promise<Order>;
  showToast: (message: string) => void;
}

const StoreContext = createContext<StoreContextValue | undefined>(undefined);

const DEFAULT_PRODUCT_IDS = new Set(PRODUCTS.map((p) => p.id));

function toPlainProduct(rec: FirestoreCatalogRecord): Product {
  const prod: Product = {
    id: rec.id,
    sku: rec.sku,
    slug: rec.slug,
    name: rec.name,
    categorySlug: rec.categorySlug,
    categoryName: rec.categoryName,
    price: Number(rec.price) || 0,
    rating: Number(rec.rating) || 5,
    reviewCount: Number(rec.reviewCount) || 1,
    image: rec.image,
    gallery: Array.isArray(rec.gallery) && rec.gallery.length > 0 ? rec.gallery : [rec.image],
    imageAlt: rec.imageAlt,
    shortDescription: rec.shortDescription,
    description: rec.description,
    materialsAndCare: Array.isArray(rec.materialsAndCare) ? rec.materialsAndCare : [],
    stock: Number(rec.stock) || 0,
    isBestSeller: Boolean(rec.isBestSeller),
    isNewArrival: Boolean(rec.isNewArrival),
    isOnSale: Boolean(rec.isOnSale),
  };
  if (typeof rec.originalPrice === 'number') prod.originalPrice = rec.originalPrice;
  if (typeof rec.discountPercent === 'number') prod.discountPercent = rec.discountPercent;
  if (Array.isArray(rec.sizes) && rec.sizes.length > 0) prod.sizes = rec.sizes;
  if (Array.isArray(rec.colors) && rec.colors.length > 0) prod.colors = rec.colors;
  return prod;
}

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const { user, isAuthReady, isAdmin } = useFirebase();

  const [firestoreCatalog, setFirestoreCatalog] = useState<FirestoreCatalogRecord[]>([]);
  const [isCatalogLoading, setIsCatalogLoading] = useState(true);
  const [socialLinks, setSocialLinks] = useState<SocialLinksConfig>(STORE_CONFIG.socialLinks);
  const [ownerOrders, setOwnerOrders] = useState<Order[]>([]);

  // Track any unsynced browser-local drafts created before Firebase was configured
  const [localDraftVersion, setLocalDraftVersion] = useState(0);

  const [cart, setCart] = useState<CartItem[]>(() => localStoreAdapter.loadCart());
  const [wishlist, setWishlist] = useState<WishlistItem[]>(() =>
    localStoreAdapter.loadWishlist()
  );
  const [orders, setOrders] = useState<Order[]>(() => localStoreAdapter.loadOrders());
  const [lastOrder, setLastOrder] = useState<Order | null>(() => {
    const existing = localStoreAdapter.loadOrders();
    return existing[0] ?? null;
  });
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Subscribe to public storefront catalog and social links once Firebase auth is ready
  useEffect(() => {
    if (!isAuthReady) return;
    const unsubCatalog = subscribeCatalogProducts((records) => {
      setFirestoreCatalog(records);
      setIsCatalogLoading(false);
    });
    const unsubSocial = subscribeSocialSettings((remoteLinks) => {
      setSocialLinks(remoteLinks ?? STORE_CONFIG.socialLinks);
    });
    return () => {
      unsubCatalog();
      unsubSocial();
    };
  }, [isAuthReady]);

  // Subscribe to customer orders ONLY when verified as store owner
  useEffect(() => {
    if (!isAuthReady || !isAdmin) {
      setOwnerOrders([]);
      return;
    }
    const unsubOrders = subscribeOwnerOrders((remoteOrders) => {
      setOwnerOrders(remoteOrders);
    });
    return () => {
      unsubOrders();
    };
  }, [isAdmin, isAuthReady]);

  useEffect(() => {
    localStoreAdapter.saveCart(cart);
  }, [cart]);

  useEffect(() => {
    localStoreAdapter.saveWishlist(wishlist);
  }, [wishlist]);

  useEffect(() => {
    if (!toastMessage) return;
    const timer = window.setTimeout(() => setToastMessage(null), 2800);
    return () => window.clearTimeout(timer);
  }, [toastMessage]);

  const showToast = useCallback((message: string) => {
    setToastMessage(message);
  }, []);

  const localDraftCount = useMemo(() => {
    void localDraftVersion;
    const custom = localStoreAdapter.loadCustomProducts();
    const deleted = localStoreAdapter.loadDeletedProductIds();
    const overrides = localStoreAdapter.loadProductOverrides();
    return custom.length + deleted.length + Object.keys(overrides).length;
  }, [localDraftVersion]);

  const { products, customProducts, deletedDefaultProducts } = useMemo(() => {
    const firestoreById = new Map<string, FirestoreCatalogRecord>();
    for (const rec of firestoreCatalog) {
      firestoreById.set(rec.id, rec);
    }

    const customList: Product[] = [];
    for (const rec of firestoreCatalog) {
      if (!DEFAULT_PRODUCT_IDS.has(rec.id) && !rec.isDeleted) {
        customList.push(toPlainProduct(rec));
      }
    }

    const deletedBuiltIns: Product[] = [];
    const activeBuiltIns: Product[] = [];

    for (const baseProd of PRODUCTS) {
      const override = firestoreById.get(baseProd.id);
      if (override) {
        if (override.isDeleted) {
          deletedBuiltIns.push(toPlainProduct(override));
        } else {
          activeBuiltIns.push(toPlainProduct(override));
        }
      } else {
        activeBuiltIns.push(baseProd);
      }
    }

    return {
      products: [...customList, ...activeBuiltIns],
      customProducts: customList,
      deletedDefaultProducts: deletedBuiltIns,
    };
  }, [firestoreCatalog]);

  const addProduct = useCallback(
    async (product: Product) => {
      if (!isAdmin || !user) {
        showToast('Owner sign-in is required to add products.');
        return;
      }
      await upsertCatalogProduct(product, user.uid, false);
      showToast(`${product.name} published to live store`);
    },
    [isAdmin, showToast, user]
  );

  const updateProduct = useCallback(
    async (updated: Product) => {
      if (!isAdmin || !user) {
        showToast('Owner sign-in is required to edit products.');
        return;
      }
      await upsertCatalogProduct(updated, user.uid, false);

      setCart((prev) =>
        prev.map((item) =>
          item.productId === updated.id
            ? {
                ...item,
                slug: updated.slug,
                name: updated.name,
                categoryName: updated.categoryName,
                image: updated.image,
                imageAlt: updated.imageAlt,
                price: updated.price,
                originalPrice: updated.originalPrice,
              }
            : item
        )
      );

      showToast(`"${updated.name}" updated live`);
    },
    [isAdmin, showToast, user]
  );

  const deleteProduct = useCallback(
    async (productId: string) => {
      if (!isAdmin || !user) {
        showToast('Owner sign-in is required to delete products.');
        return;
      }
      const target =
        products.find((p) => p.id === productId) ??
        PRODUCTS.find((p) => p.id === productId);

      if (DEFAULT_PRODUCT_IDS.has(productId)) {
        const baseOrEdited = target ?? PRODUCTS.find((p) => p.id === productId)!;
        await upsertCatalogProduct(baseOrEdited, user.uid, true);
      } else {
        await removeCatalogProductDoc(productId);
      }

      setCart((prev) => prev.filter((c) => c.productId !== productId));
      setWishlist((prev) => prev.filter((w) => w.productId !== productId));
      showToast(
        target ? `"${target.name}" removed from public store` : 'Product removed from store'
      );
    },
    [isAdmin, products, showToast, user]
  );

  const restoreDefaultProduct = useCallback(
    async (productId: string) => {
      if (!isAdmin || !user) return;
      const target =
        deletedDefaultProducts.find((p) => p.id === productId) ??
        PRODUCTS.find((p) => p.id === productId);
      if (target) {
        await upsertCatalogProduct(target, user.uid, false);
        showToast(`"${target.name}" restored to public store`);
      }
    },
    [deletedDefaultProducts, isAdmin, showToast, user]
  );

  const restoreAllDefaultProducts = useCallback(async () => {
    if (!isAdmin || !user) return;
    await Promise.all(
      deletedDefaultProducts.map((item) => upsertCatalogProduct(item, user.uid, false))
    );
    showToast('All built-in products restored');
  }, [deletedDefaultProducts, isAdmin, showToast, user]);

  const updateSocialLinks = useCallback(
    async (links: SocialLinksConfig) => {
      if (!isAdmin || !user) {
        showToast('Owner sign-in is required to update social links.');
        return;
      }
      await saveSocialSettings(links, user.uid);
      showToast('Social media links updated live');
    },
    [isAdmin, showToast, user]
  );

  const resetSocialLinks = useCallback(async () => {
    if (!isAdmin || !user) return;
    await saveSocialSettings(STORE_CONFIG.socialLinks, user.uid);
    showToast('Social media links reset to defaults');
  }, [isAdmin, showToast, user]);

  const syncLocalDraftsToLiveStore = useCallback(async () => {
    if (!isAdmin || !user) return;
    const custom = localStoreAdapter.loadCustomProducts();
    const overrides = localStoreAdapter.loadProductOverrides();
    const deletedIds = new Set(localStoreAdapter.loadDeletedProductIds());

    for (const prod of custom) {
      await upsertCatalogProduct(prod, user.uid, false);
    }
    for (const prod of Object.values(overrides)) {
      await upsertCatalogProduct(prod, user.uid, deletedIds.has(prod.id));
    }
    for (const delId of deletedIds) {
      if (!overrides[delId]) {
        const baseProd = PRODUCTS.find((p) => p.id === delId);
        if (baseProd) {
          await upsertCatalogProduct(baseProd, user.uid, true);
        }
      }
    }

    localStoreAdapter.saveCustomProducts([]);
    localStoreAdapter.saveProductOverrides({});
    localStoreAdapter.saveDeletedProductIds([]);
    setLocalDraftVersion((v) => v + 1);
    showToast('Local drafts published to live public store');
  }, [isAdmin, showToast, user]);

  const discardLocalDrafts = useCallback(() => {
    localStoreAdapter.saveCustomProducts([]);
    localStoreAdapter.saveProductOverrides({});
    localStoreAdapter.saveDeletedProductIds([]);
    setLocalDraftVersion((v) => v + 1);
    showToast('Cleared local browser drafts');
  }, [showToast]);

  const updateOrderStatus = useCallback(
    async (orderId: string, status: OrderStatus) => {
      if (!isAdmin) return;
      await updateFirestoreOrderStatus(orderId, status);
      showToast(`Order status updated to "${status}"`);
    },
    [isAdmin, showToast]
  );

  const deleteOrderRecord = useCallback(
    async (orderId: string) => {
      if (!isAdmin) return;
      await deleteFirestoreOrder(orderId);
      showToast('Order record deleted');
    },
    [isAdmin, showToast]
  );

  const addToCart = useCallback(
    (
      product: Product,
      options?: { quantity?: number; size?: string; color?: string; openDrawer?: boolean }
    ) => {
      const qty = Math.max(1, options?.quantity ?? 1);
      const selectedSize = options?.size ?? product.sizes?.[0];
      const selectedColor = options?.color ?? product.colors?.[0]?.name;
      const itemKey = `${product.id}__${selectedSize ?? 'default'}__${selectedColor ?? 'default'}`;

      setCart((prev) => {
        const existingIndex = prev.findIndex((item) => item.key === itemKey);
        if (existingIndex >= 0) {
          return prev.map((item, idx) =>
            idx === existingIndex ? { ...item, quantity: item.quantity + qty } : item
          );
        }
        return [
          ...prev,
          {
            key: itemKey,
            productId: product.id,
            slug: product.slug,
            name: product.name,
            categoryName: product.categoryName,
            image: product.image,
            imageAlt: product.imageAlt,
            price: product.price,
            originalPrice: product.originalPrice,
            quantity: qty,
            selectedSize,
            selectedColor,
          },
        ];
      });

      if (options?.openDrawer !== false) {
        setIsCartDrawerOpen(true);
      } else {
        showToast(`${product.name} added to bag`);
      }
    },
    [showToast]
  );

  const updateQuantity = useCallback((itemKey: string, quantity: number) => {
    if (quantity <= 0) {
      setCart((prev) => prev.filter((item) => item.key !== itemKey));
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.key === itemKey ? { ...item, quantity } : item))
    );
  }, []);

  const removeFromCart = useCallback((itemKey: string) => {
    setCart((prev) => prev.filter((item) => item.key !== itemKey));
  }, []);

  const clearCart = useCallback(() => {
    setCart([]);
  }, []);

  const isInWishlist = useCallback(
    (productId: string) => wishlist.some((item) => item.productId === productId),
    [wishlist]
  );

  const toggleWishlist = useCallback(
    (productId: string, productName?: string) => {
      setWishlist((prev) => {
        const exists = prev.some((item) => item.productId === productId);
        if (exists) {
          showToast(productName ? `Removed ${productName} from wishlist` : 'Removed from wishlist');
          return prev.filter((item) => item.productId !== productId);
        }
        showToast(productName ? `Saved ${productName} to wishlist` : 'Saved to wishlist');
        return [{ productId, addedAt: new Date().toISOString() }, ...prev];
      });
    },
    [showToast]
  );

  const cartCount = useMemo(
    () => cart.reduce((acc, item) => acc + item.quantity, 0),
    [cart]
  );

  const wishlistCount = wishlist.length;

  const subtotal = useMemo(
    () => cart.reduce((acc, item) => acc + item.price * item.quantity, 0),
    [cart]
  );

  const shippingCost = useMemo(() => {
    if (cart.length === 0 || STORE_CONFIG.shipping.freeShippingThreshold <= 0) return 0;
    return subtotal >= STORE_CONFIG.shipping.freeShippingThreshold
      ? 0
      : STORE_CONFIG.shipping.standardRate;
  }, [cart.length, subtotal]);

  const total = subtotal + shippingCost;

  const amountToFreeShipping = Math.max(
    0,
    STORE_CONFIG.shipping.freeShippingThreshold - subtotal
  );

  const placeDemoOrder = useCallback(
    async (customer: CustomerInfo, paymentMethod: PaymentMethodId): Promise<Order> => {
      const orderNum = `SHAH-${Math.floor(100000 + Math.random() * 900000)}`;
      const newOrder: Order = {
        id: `ord-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        orderNumber: orderNum,
        createdAt: new Date().toISOString(),
        customer: {
          fullName: customer.fullName.trim(),
          phone: customer.phone.trim(),
          city: customer.city.trim(),
          address: customer.address.trim(),
        },
        items: [...cart],
        subtotal,
        shippingCost,
        total,
        paymentMethod,
        paymentVerified: false,
        isDemoOrder: false,
        status: 'Order Received (COD)',
      };

      await createFirestoreOrder(newOrder);
      localStoreAdapter.saveOrder(newOrder);
      setOrders((prev) => [newOrder, ...prev]);
      setLastOrder(newOrder);
      setCart([]);
      return newOrder;
    },
    [cart, shippingCost, subtotal, total]
  );

  const value: StoreContextValue = {
    products,
    customProducts,
    deletedDefaultProducts,
    socialLinks,
    cart,
    wishlist,
    orders,
    ownerOrders,
    lastOrder,
    cartCount,
    wishlistCount,
    subtotal,
    shippingCost,
    total,
    amountToFreeShipping,
    isCartDrawerOpen,
    isSearchOpen,
    toastMessage,
    isCatalogLoading,
    localDraftCount,
    setIsCartDrawerOpen,
    setIsSearchOpen,
    addProduct,
    updateProduct,
    deleteProduct,
    deleteCustomProduct: deleteProduct,
    restoreDefaultProduct,
    restoreAllDefaultProducts,
    updateSocialLinks,
    resetSocialLinks,
    syncLocalDraftsToLiveStore,
    discardLocalDrafts,
    updateOrderStatus,
    deleteOrderRecord,
    addToCart,
    updateQuantity,
    removeFromCart,
    clearCart,
    isInWishlist,
    toggleWishlist,
    placeDemoOrder,
    showToast,
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore(): StoreContextValue {
  const ctx = useContext(StoreContext);
  if (!ctx) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return ctx;
}
