export interface StoreConfig {
  brandName: string;
  logoUrl: string;
  tagline: string;
  legalEntity: string;
  currency: {
    code: string;
    symbol: string;
    locale: string;
  };
  shipping: {
    standardRate: number;
    freeShippingThreshold: number;
    estimatedDeliveryDays: string;
  };
  contact: {
    email: string;
    phone: string;
    address: string;
    hours: string;
  };
  socialLinks: {
    facebook: string;
    instagram: string;
    youtube: string;
    pinterest: string;
    tiktok: string;
  };
  supportedPaymentMethods: {
    id: 'cod';
    label: string;
    badgeText: string;
    enabled: boolean;
    requiresServerGateway: boolean;
    description: string;
  }[];
  policies: {
    returnWindowDays: number;
    warrantyMonths: number;
    privacyUpdated: string;
    termsUpdated: string;
  };
}

export const STORE_CONFIG: StoreConfig = {
  brandName: 'Shah Store Royal Shopping',
  logoUrl: '/assets/aistudio/file_00000000cec082119c5560af9ee80034_3edc34b2.png',
  tagline: 'The Art of Modern Living',
  legalEntity: 'Shah Store Royal Shopping Co.',
  currency: {
    code: 'PKR',
    symbol: 'PKR',
    locale: 'en-PK',
  },
  shipping: {
    standardRate: 0,
    freeShippingThreshold: 0,
    estimatedDeliveryDays: '3–5 business days',
  },
  contact: {
    email: 'concierge@shahstoreroyal.example',
    phone: '+1 (555) 234-8910',
    address: '418 Mercer Courtyard, Suite 3B, New York, NY 10013',
    hours: 'Monday – Saturday, 9:00 AM – 6:00 PM EST',
  },
  socialLinks: {
    facebook: 'https://facebook.com',
    instagram: 'https://instagram.com',
    youtube: 'https://youtube.com',
    pinterest: 'https://pinterest.com',
    tiktok: 'https://tiktok.com',
  },
  supportedPaymentMethods: [
    {
      id: 'cod',
      label: 'Cash on Delivery (COD)',
      badgeText: 'Cash on Delivery',
      enabled: true,
      requiresServerGateway: false,
      description: 'Pay directly in cash when your order arrives. Demonstration orders are recorded locally in your browser.',
    },
  ],
  policies: {
    returnWindowDays: 30,
    warrantyMonths: 12,
    privacyUpdated: 'November 2026',
    termsUpdated: 'November 2026',
  },
};

export function formatPrice(amount: number): string {
  const formatted = new Intl.NumberFormat(STORE_CONFIG.currency.locale, {
    minimumFractionDigits: 0,
    maximumFractionDigits: amount % 1 === 0 ? 0 : 2,
  }).format(amount);
  return `${STORE_CONFIG.currency.code} ${formatted}`;
}
