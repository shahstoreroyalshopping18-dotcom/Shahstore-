import { ArrowLeft, ArrowRight } from 'lucide-react';
import { useState } from 'react';
import { SafeImage } from '../components/common/SafeImage';
import { BLOG_POSTS } from '../data/blog';
import { BlogPost } from '../types/ecommerce';

export function BlogPage() {
  const [activePost, setActivePost] = useState<BlogPost | null>(null);

  if (activePost) {
    return (
      <article className="bg-[#FFF9F1] py-12 sm:py-16">
        <div className="max-w-[820px] mx-auto px-4 sm:px-6">
          <button
            type="button"
            onClick={() => setActivePost(null)}
            className="inline-flex items-center gap-2 text-sm font-semibold text-[#7A0B24] hover:underline mb-8 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Journal</span>
          </button>

          <p className="text-xs text-[#77736D] mb-2">
            {activePost.category} · {activePost.publishedDate} · {activePost.readTime}
          </p>
          <h1 className="font-editorial text-3xl sm:text-5xl font-semibold text-[#171A18] leading-tight mb-4">
            {activePost.title}
          </h1>
          <p className="text-sm font-medium text-[#961734] mb-8">
            By {activePost.author}
          </p>

          <div className="aspect-[16/10] rounded-3xl overflow-hidden border border-[#EDE5DB] mb-8 bg-[#F8F0E6]">
            <SafeImage
              src={activePost.image}
              alt={activePost.imageAlt}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="space-y-5 text-base sm:text-lg text-[#171A18]/90 leading-relaxed">
            {activePost.content.map((para, idx) => (
              <p key={idx}>{para}</p>
            ))}
          </div>
        </div>
      </article>
    );
  }

  return (
    <div className="bg-[#FFF9F1] py-12 sm:py-16">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10">
        <div className="max-w-2xl mb-10 sm:mb-12">
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#961734] mb-1.5">
            The Shah Store Royal Shopping Journal
          </p>
          <h1 className="font-editorial text-4xl sm:text-5xl font-semibold text-[#171A18]">
            Notes on Style &amp; Living
          </h1>
          <p className="text-base text-[#77736D] mt-2">
            Essays on capsule wardrobes, material provenance, leather care, and calm interiors.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-7">
          {BLOG_POSTS.map((post) => (
            <article
              key={post.id}
              className="group bg-white border border-[#EDE5DB] rounded-2xl overflow-hidden flex flex-col shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="aspect-[4/3] bg-[#F8F0E6] overflow-hidden">
                <SafeImage
                  src={post.image}
                  alt={post.imageAlt}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="p-6 flex flex-col flex-1 justify-between">
                <div>
                  <p className="text-xs text-[#77736D] mb-2">
                    {post.category} · {post.publishedDate} · {post.readTime}
                  </p>
                  <h2 className="font-editorial text-2xl font-semibold text-[#171A18] group-hover:text-[#7A0B24] leading-snug mb-2">
                    {post.title}
                  </h2>
                  <p className="text-sm text-[#77736D] leading-relaxed">
                    {post.excerpt}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setActivePost(post)}
                  className="mt-5 pt-4 border-t border-[#F1E5D8] inline-flex items-center gap-1.5 text-sm font-semibold text-[#7A0B24] hover:underline cursor-pointer self-start"
                >
                  <span>Read Essay</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
}
