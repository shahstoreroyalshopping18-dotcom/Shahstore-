import { ArrowRight, Leaf, ShieldCheck, Sparkles } from 'lucide-react';
import { SafeImage } from '../components/common/SafeImage';
import { STORE_CONFIG } from '../config/storeConfig';
import { Link } from '../router/RouterContext';

export function AboutPage() {
  return (
    <div className="bg-[#FFF9F1] py-12 sm:py-16">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10 space-y-16">
        {/* Editorial Intro */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-6 space-y-5">
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#961734]">
              Our House Philosophy
            </p>
            <h1 className="font-editorial text-4xl sm:text-5xl lg:text-6xl font-semibold text-[#171A18] leading-[1.06]">
              Crafted for Quiet Confidence &amp; Modern Living.
            </h1>
            <p className="text-base text-[#77736D] leading-relaxed">
              Founded as an antidote to fleeting seasonal excess, {STORE_CONFIG.brandName} brings together enduring wardrobe staples, full-grain leather goods, botanical skincare, and tactile home objects under one cohesive aesthetic.
            </p>
            <p className="text-base text-[#77736D] leading-relaxed">
              Every silhouette begins with natural materials—GOTS-certified organic cotton fleece, Belgian flax linen, Grade-A Mongolian cashmere, and vegetable-tanned European calfskin—selected for how gracefully they age over years of daily wear.
            </p>
            <div className="pt-2">
              <Link
                to="/shop"
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] transition-colors"
              >
                <span>Explore the Collection</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="aspect-[4/3] rounded-3xl overflow-hidden border border-[#EDE5DB] shadow-lg bg-[#F8F0E6]">
              <SafeImage
                src="/src/assets/images/category_home_living_1794832182701.jpg"
                alt="Shah Store Royal Shopping studio interior vignette with ceramic vase, oat throw, and brass taper"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>

        {/* Three Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              icon: Leaf,
              title: 'Natural Provenance',
              desc: 'We prioritize organic cotton, unbleached Belgian linen, bio-acetate frames, and low-impact mineral dyes across our studio lines.',
            },
            {
              icon: Sparkles,
              title: 'Measured Craft',
              desc: 'Partner workshops in Portugal, Italy, and northern Europe produce small batches with reinforced seams and repairable hardware.',
            },
            {
              icon: ShieldCheck,
              title: 'Transparent Care',
              desc: 'Every order includes clear care guidance, a 30-day return window, and a 12-month craftsmanship guarantee.',
            },
          ].map((pillar) => {
            const Icon = pillar.icon;
            return (
              <div
                key={pillar.title}
                className="bg-white border border-[#EDE5DB] rounded-2xl p-7 space-y-3"
              >
                <div className="w-11 h-11 rounded-xl bg-[#F8F0E6] text-[#7A0B24] flex items-center justify-center">
                  <Icon className="w-5 h-5" />
                </div>
                <h2 className="font-editorial text-2xl font-semibold text-[#171A18]">
                  {pillar.title}
                </h2>
                <p className="text-sm text-[#77736D] leading-relaxed">{pillar.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
