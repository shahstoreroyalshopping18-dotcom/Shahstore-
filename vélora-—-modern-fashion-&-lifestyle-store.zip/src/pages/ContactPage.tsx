import { CheckCircle2, Clock, Facebook, Instagram, Mail, MapPin, Pencil, Phone, Youtube } from 'lucide-react';
import { FormEvent, useState } from 'react';
import { STORE_CONFIG } from '../config/storeConfig';
import { useFirebase } from '../context/FirebaseContext';
import { useStore } from '../context/StoreContext';
import { Link } from '../router/RouterContext';

export function ContactPage() {
  const { isAdmin } = useFirebase();
  const { socialLinks } = useStore();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()) || !message.trim()) {
      setError('Please complete your name, a valid email address, and your message.');
      return;
    }
    setError('');
    setSubmitted(true);
    setName('');
    setEmail('');
    setSubject('');
    setMessage('');
  };

  return (
    <div className="bg-[#FFF9F1] py-12 sm:py-16">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10">
        <div className="max-w-2xl mb-10">
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#961734] mb-1.5">
            Client Concierge
          </p>
          <h1 className="font-editorial text-4xl sm:text-5xl font-semibold text-[#171A18]">
            Get in Touch
          </h1>
          <p className="text-base text-[#77736D] mt-2">
            Questions about sizing, materials, or wholesale inquiries? Reach our studio team below.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Contact Details */}
          <div className="lg:col-span-5 bg-[#7A0B24] text-white rounded-3xl p-8 space-y-6">
            <h2 className="font-editorial text-3xl font-semibold">Studio Details</h2>
            <div className="space-y-4 text-sm text-white/85">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[#EAB96B] shrink-0 mt-0.5" />
                <span>{STORE_CONFIG.contact.address}</span>
              </div>
              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-[#EAB96B] shrink-0 mt-0.5" />
                <span>{STORE_CONFIG.contact.email}</span>
              </div>
              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-[#EAB96B] shrink-0 mt-0.5" />
                <span>{STORE_CONFIG.contact.phone}</span>
              </div>
              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 text-[#EAB96B] shrink-0 mt-0.5" />
                <span>{STORE_CONFIG.contact.hours}</span>
              </div>
            </div>

            <div className="pt-5 border-t border-white/15 space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold uppercase tracking-[0.12em] text-[#EAB96B]">
                  Social Media
                </p>
                {isAdmin && (
                  <Link
                    to="/add-product?tab=social"
                    className="inline-flex items-center gap-1 text-xs text-white/80 hover:text-white underline underline-offset-2"
                  >
                    <Pencil className="w-3 h-3" />
                    <span>Add / Edit IDs</span>
                  </Link>
                )}
              </div>
              <div className="flex flex-wrap gap-2.5">
                {socialLinks.facebook && (
                  <a
                    href={socialLinks.facebook}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium text-white transition-colors"
                  >
                    <Facebook className="w-3.5 h-3.5 text-[#EAB96B]" />
                    <span>Facebook</span>
                  </a>
                )}
                {socialLinks.youtube && (
                  <a
                    href={socialLinks.youtube}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium text-white transition-colors"
                  >
                    <Youtube className="w-3.5 h-3.5 text-[#EAB96B]" />
                    <span>YouTube</span>
                  </a>
                )}
                {socialLinks.tiktok && (
                  <a
                    href={socialLinks.tiktok}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium text-white transition-colors"
                  >
                    <svg className="w-3.5 h-3.5 text-[#EAB96B]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
                      <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    <span>TikTok</span>
                  </a>
                )}
                {socialLinks.instagram && (
                  <a
                    href={socialLinks.instagram}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium text-white transition-colors"
                  >
                    <Instagram className="w-3.5 h-3.5 text-[#EAB96B]" />
                    <span>Instagram</span>
                  </a>
                )}
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-7 bg-white border border-[#EDE5DB] rounded-3xl p-6 sm:p-8">
            <form onSubmit={handleSubmit} noValidate className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="contact-name" className="block text-xs font-semibold text-[#171A18] mb-1.5">
                    Your Name *
                  </label>
                  <input
                    id="contact-name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Full name"
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                  />
                </div>
                <div>
                  <label htmlFor="contact-email" className="block text-xs font-semibold text-[#171A18] mb-1.5">
                    Email Address *
                  </label>
                  <input
                    id="contact-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="contact-subject" className="block text-xs font-semibold text-[#171A18] mb-1.5">
                  Subject
                </label>
                <input
                  id="contact-subject"
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Sizing inquiry, order assistance..."
                  className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                />
              </div>

              <div>
                <label htmlFor="contact-message" className="block text-xs font-semibold text-[#171A18] mb-1.5">
                  Message *
                </label>
                <textarea
                  id="contact-message"
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="How can our concierge team assist you?"
                  className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                />
              </div>

              {error && <p className="text-xs text-red-700">{error}</p>}

              {submitted && (
                <div className="p-4 rounded-xl bg-[#F8F0E6] border border-[#7A0B24]/30 flex items-start gap-2.5 text-xs text-[#7A0B24]">
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>
                    Message validated in demonstration mode. Connect a backend email endpoint (e.g. Resend or Formspree) before launching live to forward inquiries to your inbox.
                  </span>
                </div>
              )}

              <button
                type="submit"
                className="px-7 py-3.5 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] transition-colors cursor-pointer"
              >
                Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
