import { ArrowRight, Minus, Plus, ShoppingBag, Trash2 } from 'lucide-react';
import { SafeImage } from '../components/common/SafeImage';
import { formatPrice, STORE_CONFIG } from '../config/storeConfig';
import { useStore } from '../context/StoreContext';
import { Link } from '../router/RouterContext';

export function CartPage() {
  const {
    cart,
    cartCount,
    subtotal,
    shippingCost,
    total,
    amountToFreeShipping,
    updateQuantity,
    removeFromCart,
    clearCart,
  } = useStore();

  return (
    <div className="bg-[#FFF9F1] min-h-[70vh] py-12 sm:py-16">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10">
        <div className="pb-8 border-b border-[#EDE5DB] mb-8 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#961734] mb-1.5">
              Order Review
            </p>
            <h1 className="font-editorial text-4xl sm:text-5xl font-semibold text-[#171A18]">
              Shopping Bag ({cartCount})
            </h1>
          </div>
          {cart.length > 0 && (
            <button
              type="button"
              onClick={clearCart}
              className="text-xs font-semibold text-[#77736D] hover:text-[#171A18] underline cursor-pointer self-start sm:self-auto"
            >
              Clear Bag
            </button>
          )}
        </div>

        {cart.length === 0 ? (
          <div className="bg-white border border-[#EDE5DB] rounded-3xl p-12 text-center max-w-xl mx-auto">
            <div className="w-14 h-14 rounded-full bg-[#F1E5D8] text-[#7A0B24] flex items-center justify-center mx-auto mb-4">
              <ShoppingBag className="w-6 h-6" strokeWidth={1.75} />
            </div>
            <h2 className="font-editorial text-3xl font-semibold text-[#171A18] mb-2">
              Your bag is empty
            </h2>
            <p className="text-sm text-[#77736D] mb-6">
              Browse our curated essentials and add pieces to begin checkout.
            </p>
            <Link
              to="/shop"
              className="inline-flex px-6 py-3 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734]"
            >
              Shop Collection
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Items Table / List */}
            <div className="lg:col-span-8 space-y-4">
              {cart.map((item) => (
                <div
                  key={item.key}
                  className="bg-white border border-[#EDE5DB] rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-6"
                >
                  <Link
                    to={`/product/${item.slug}`}
                    className="w-24 h-24 rounded-xl overflow-hidden bg-[#F8F0E6] shrink-0"
                  >
                    <SafeImage
                      src={item.image}
                      alt={item.imageAlt}
                      className="w-full h-full object-cover"
                    />
                  </Link>

                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] uppercase tracking-[0.08em] text-[#77736D]">
                      {item.categoryName}
                    </p>
                    <Link
                      to={`/product/${item.slug}`}
                      className="text-base font-semibold text-[#171A18] hover:text-[#7A0B24]"
                    >
                      {item.name}
                    </Link>
                    {(item.selectedSize || item.selectedColor) && (
                      <p className="text-xs text-[#77736D] mt-1">
                        {[item.selectedSize, item.selectedColor].filter(Boolean).join(' · ')}
                      </p>
                    )}
                    <p className="text-sm font-semibold text-[#7A0B24] tabular-nums mt-1">
                      {formatPrice(item.price)} each
                    </p>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-5">
                    <div className="inline-flex items-center border border-[#EDE5DB] rounded-xl bg-[#FFF9F1]">
                      <button
                        type="button"
                        onClick={() => updateQuantity(item.key, item.quantity - 1)}
                        aria-label={`Decrease quantity of ${item.name}`}
                        className="w-9 h-9 flex items-center justify-center text-[#171A18] hover:bg-[#F1E5D8] rounded-l-xl cursor-pointer"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-9 text-center text-xs font-semibold tabular-nums">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => updateQuantity(item.key, item.quantity + 1)}
                        aria-label={`Increase quantity of ${item.name}`}
                        className="w-9 h-9 flex items-center justify-center text-[#171A18] hover:bg-[#F1E5D8] rounded-r-xl cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <span className="text-base font-bold text-[#171A18] tabular-nums min-w-[70px] text-right">
                      {formatPrice(item.price * item.quantity)}
                    </span>

                    <button
                      type="button"
                      onClick={() => removeFromCart(item.key)}
                      aria-label={`Remove ${item.name}`}
                      className="p-2 text-[#77736D] hover:text-[#171A18] cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Order Summary */}
            <aside className="lg:col-span-4 bg-white border border-[#EDE5DB] rounded-2xl p-6 space-y-5 sticky top-24">
              <h2 className="font-editorial text-2xl font-semibold text-[#171A18]">
                Order Summary
              </h2>

              <div className="p-3.5 rounded-xl bg-[#F8F0E6] text-xs font-medium text-[#171A18]">
                {amountToFreeShipping === 0
                  ? 'All Pakistan Free Delivery included on every order.'
                  : `Add ${formatPrice(amountToFreeShipping)} more for free delivery (orders ${formatPrice(
                      STORE_CONFIG.shipping.freeShippingThreshold
                    )}+).`}
              </div>

              <div className="space-y-3 text-sm pt-1">
                <div className="flex justify-between text-[#77736D]">
                  <span>Subtotal</span>
                  <span className="font-medium text-[#171A18] tabular-nums">
                    {formatPrice(subtotal)}
                  </span>
                </div>
                <div className="flex justify-between text-[#77736D]">
                  <span>All Pakistan Delivery</span>
                  <span className="font-semibold text-[#7A0B24] tabular-nums">
                    {shippingCost === 0 ? 'Free' : formatPrice(shippingCost)}
                  </span>
                </div>
                <div className="flex justify-between text-base font-bold text-[#171A18] pt-3 border-t border-[#EDE5DB]">
                  <span>Total</span>
                  <span className="tabular-nums">{formatPrice(total)}</span>
                </div>
              </div>

              <Link
                to="/checkout"
                className="w-full inline-flex items-center justify-center gap-2 py-3.5 px-5 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] transition-colors"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </Link>

              <Link
                to="/shop"
                className="block text-center text-xs font-semibold text-[#7A0B24] hover:underline"
              >
                Continue Shopping
              </Link>
            </aside>
          </div>
        )}
      </div>
    </div>
  );
}
