import { ChevronDown } from 'lucide-react';
import { useState } from 'react';
import { FAQ_ITEMS } from '../data/faqs';
import { Link } from '../router/RouterContext';

export function FaqPage() {
  const [openId, setOpenId] = useState<string>(FAQ_ITEMS[0].id);

  return (
    <div className="bg-[#FFF9F1] py-12 sm:py-16">
      <div className="max-w-[960px] mx-auto px-4 sm:px-6 lg:px-10 space-y-10">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#961734] mb-1.5">
            Help Center
          </p>
          <h1 className="font-editorial text-4xl sm:text-5xl font-semibold text-[#171A18]">
            Frequently Asked Questions
          </h1>
          <p className="text-base text-[#77736D] mt-2">
            Answers regarding All Pakistan free delivery, 30-day returns, sizing, and Cash on Delivery.
          </p>
        </div>

        <div className="space-y-3">
          {FAQ_ITEMS.map((item) => {
            const isOpen = openId === item.id;
            return (
              <div
                key={item.id}
                className="bg-white border border-[#EDE5DB] rounded-2xl overflow-hidden"
              >
                <button
                  type="button"
                  onClick={() => setOpenId(isOpen ? '' : item.id)}
                  aria-expanded={isOpen}
                  className="w-full px-6 py-5 flex items-center justify-between gap-4 text-left cursor-pointer hover:bg-[#FFF9F1]/60 transition-colors"
                >
                  <div>
                    <span className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[#961734] block mb-1">
                      {item.category}
                    </span>
                    <span className="text-base font-semibold text-[#171A18]">
                      {item.question}
                    </span>
                  </div>
                  <ChevronDown
                    className={`w-5 h-5 text-[#77736D] shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-6 pb-5 pt-1 text-sm text-[#77736D] leading-relaxed border-t border-[#F1E5D8]">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="bg-[#F1E5D8] rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-editorial text-2xl font-semibold text-[#171A18]">
              Looking for an order status?
            </h2>
            <p className="text-sm text-[#77736D] mt-0.5">
              Check your recorded demonstration order details anytime.
            </p>
          </div>
          <Link
            to="/order-confirmation"
            className="px-6 py-3 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] whitespace-nowrap self-start sm:self-auto"
          >
            Track Order
          </Link>
        </div>
      </div>
    </div>
  );
}
