import { ArrowRight } from 'lucide-react';
import { SafeImage } from '../components/common/SafeImage';
import { useStore } from '../context/StoreContext';
import { CATEGORIES } from '../data/categories';
import { Link } from '../router/RouterContext';

export function CategoriesPage() {
  const { products } = useStore();

  return (
    <div className="bg-[#FFF9F1] py-12 sm:py-16">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10">
        <div className="max-w-2xl mb-10 sm:mb-12">
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#961734] mb-2">
            Department Directory
          </p>
          <h1 className="font-editorial text-4xl sm:text-5xl font-semibold text-[#171A18]">
            Explore All Categories
          </h1>
          <p className="text-base text-[#77736D] mt-2 leading-relaxed">
            Six curated departments spanning apparel, fine leather accessories, footwear, botanical beauty, and tactile objects for the home.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {CATEGORIES.map((category) => {
            const liveCount = products.filter((p) => p.categorySlug === category.slug).length;
            return (
              <Link
                key={category.id}
                to={`/shop?category=${category.slug}`}
                className="group bg-white border border-[#EDE5DB] rounded-2xl overflow-hidden shadow-[0_6px_24px_rgba(23,26,24,0.04)] hover:shadow-[0_14px_34px_rgba(7,63,56,0.10)] hover:-translate-y-0.5 transition-all duration-200 flex flex-col"
              >
                <div className="aspect-[4/3] overflow-hidden bg-[#F8F0E6]">
                  <SafeImage
                    src={category.image}
                    alt={category.imageAlt}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <div className="p-6 flex flex-col flex-1 justify-between">
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <h2 className="font-editorial text-2xl font-semibold text-[#171A18] group-hover:text-[#7A0B24]">
                        {category.name}
                      </h2>
                      <span className="text-xs font-medium text-[#77736D] tabular-nums">
                        {liveCount} pieces
                      </span>
                    </div>
                    <p className="text-sm text-[#77736D] leading-relaxed">
                      {category.description}
                    </p>
                  </div>

                  <div className="mt-5 pt-4 border-t border-[#F1E5D8] flex items-center justify-between text-sm font-semibold text-[#7A0B24]">
                    <span>Browse {category.name}</span>
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
