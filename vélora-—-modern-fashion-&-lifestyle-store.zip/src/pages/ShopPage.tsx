import { Plus, Search, SlidersHorizontal, X } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { ProductCard } from '../components/common/ProductCard';
import { formatPrice } from '../config/storeConfig';
import { useFirebase } from '../context/FirebaseContext';
import { useStore } from '../context/StoreContext';
import { CATEGORIES } from '../data/categories';
import { Link, useRouter } from '../router/RouterContext';

type SortOption = 'featured' | 'newest' | 'bestselling' | 'price-asc' | 'price-desc';
type SpecialFilter = 'all' | 'sale' | 'new' | 'bestsellers';

export function ShopPage() {
  const { isAdmin } = useFirebase();
  const { products } = useStore();
  const { searchParams, navigate } = useRouter();

  const priceCeiling = useMemo(
    () => Math.max(25000, ...products.map((p) => Math.ceil(p.price / 1000) * 1000)),
    [products]
  );

  const initialCategory = searchParams.get('category') || 'all';
  const initialQuery = searchParams.get('q') || '';
  const initialFilter = (searchParams.get('filter') as SpecialFilter) || 'all';
  const initialSort = (searchParams.get('sort') as SortOption) || 'featured';

  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [searchTerm, setSearchTerm] = useState(initialQuery);
  const [specialFilter, setSpecialFilter] = useState<SpecialFilter>(initialFilter);
  const [sortBy, setSortBy] = useState<SortOption>(initialSort);
  const [maxPrice, setMaxPrice] = useState<number>(priceCeiling);
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  useEffect(() => {
    setSelectedCategory(searchParams.get('category') || 'all');
    setSearchTerm(searchParams.get('q') || '');
    setSpecialFilter((searchParams.get('filter') as SpecialFilter) || 'all');
    setSortBy((searchParams.get('sort') as SortOption) || 'featured');
  }, [searchParams]);

  useEffect(() => {
    setMaxPrice((prev) => (prev > priceCeiling ? priceCeiling : prev));
  }, [priceCeiling]);

  const filteredProducts = useMemo(() => {
    let list = [...products];

    if (selectedCategory !== 'all') {
      list = list.filter((p) => p.categorySlug === selectedCategory);
    }

    if (searchTerm.trim()) {
      const q = searchTerm.trim().toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.categoryName.toLowerCase().includes(q) ||
          p.shortDescription.toLowerCase().includes(q)
      );
    }

    if (specialFilter === 'sale') {
      list = list.filter((p) => Boolean(p.isOnSale || p.discountPercent));
    } else if (specialFilter === 'new') {
      list = list.filter((p) => Boolean(p.isNewArrival));
    } else if (specialFilter === 'bestsellers') {
      list = list.filter((p) => Boolean(p.isBestSeller));
    }

    list = list.filter((p) => p.price <= maxPrice);

    switch (sortBy) {
      case 'newest':
        list.sort((a, b) => Number(Boolean(b.isNewArrival)) - Number(Boolean(a.isNewArrival)));
        break;
      case 'bestselling':
        list.sort((a, b) => b.reviewCount - a.reviewCount);
        break;
      case 'price-asc':
        list.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        list.sort((a, b) => b.price - a.price);
        break;
      default:
        break;
    }

    return list;
  }, [maxPrice, products, searchTerm, selectedCategory, sortBy, specialFilter]);

  const resetFilters = () => {
    setSelectedCategory('all');
    setSearchTerm('');
    setSpecialFilter('all');
    setSortBy('featured');
    setMaxPrice(priceCeiling);
    navigate('/shop');
  };

  return (
    <div className="bg-[#FFF9F1] min-h-[75vh] py-10 sm:py-14">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10">
        {/* Page Header */}
        <div className="pb-8 border-b border-[#EDE5DB] flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#961734] mb-1.5">
              Curated Catalog
            </p>
            <h1 className="font-editorial text-4xl sm:text-5xl font-semibold text-[#171A18]">
              Shop the Collection
            </h1>
            <p className="text-sm sm:text-base text-[#77736D] mt-1.5">
              Showing <span className="font-semibold text-[#171A18] tabular-nums">{filteredProducts.length}</span> of{' '}
              <span className="tabular-nums">{products.length}</span> pieces
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Search Input */}
            <div className="relative flex-1 sm:w-64">
              <Search className="w-4 h-4 text-[#77736D] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="search"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search products..."
                aria-label="Search products"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white border border-[#EDE5DB] text-sm text-[#171A18] placeholder:text-[#77736D] focus:outline-none focus:border-[#7A0B24]"
              />
            </div>

            {/* Sort Dropdown */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              aria-label="Sort products"
              className="px-4 py-2.5 rounded-xl bg-white border border-[#EDE5DB] text-sm font-medium text-[#171A18] focus:outline-none focus:border-[#7A0B24] cursor-pointer"
            >
              <option value="featured">Sort: Featured</option>
              <option value="bestselling">Best Selling</option>
              <option value="newest">Newest Arrivals</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
            </select>

            {isAdmin && (
              <Link
                to="/add-product"
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] transition-colors whitespace-nowrap"
              >
                <Plus className="w-4 h-4" />
                <span>Add Product</span>
              </Link>
            )}

            <button
              type="button"
              onClick={() => setMobileFiltersOpen((prev) => !prev)}
              className="lg:hidden inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-[#EDE5DB] text-sm font-medium text-[#171A18] cursor-pointer"
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span>Filters</span>
            </button>
          </div>
        </div>

        <div className="pt-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Sidebar Filters */}
          <aside
            className={`lg:col-span-3 space-y-6 ${
              mobileFiltersOpen ? 'block' : 'hidden lg:block'
            }`}
          >
            <div className="bg-white border border-[#EDE5DB] rounded-2xl p-5 space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="font-sans text-sm font-semibold uppercase tracking-[0.08em] text-[#171A18]">
                  Filters
                </h2>
                <button
                  type="button"
                  onClick={resetFilters}
                  className="text-xs font-medium text-[#7A0B24] hover:underline cursor-pointer"
                >
                  Reset All
                </button>
              </div>

              {/* Categories */}
              <div>
                <h3 className="font-sans text-xs font-semibold uppercase tracking-[0.08em] text-[#77736D] mb-2.5">
                  Category
                </h3>
                <div className="space-y-1">
                  <button
                    type="button"
                    onClick={() => setSelectedCategory('all')}
                    className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors cursor-pointer ${
                      selectedCategory === 'all'
                        ? 'bg-[#7A0B24] text-white font-medium'
                        : 'text-[#171A18] hover:bg-[#F8F0E6]'
                    }`}
                  >
                    All Categories
                  </button>
                  {CATEGORIES.map((cat) => {
                    const count = products.filter((p) => p.categorySlug === cat.slug).length;
                    return (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setSelectedCategory(cat.slug)}
                        className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-colors cursor-pointer ${
                          selectedCategory === cat.slug
                            ? 'bg-[#7A0B24] text-white font-medium'
                            : 'text-[#171A18] hover:bg-[#F8F0E6]'
                        }`}
                      >
                        <span>{cat.name}</span>
                        <span
                          className={`text-xs tabular-nums ${
                            selectedCategory === cat.slug ? 'text-white/80' : 'text-[#77736D]'
                          }`}
                        >
                          {count}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Collections / Status */}
              <div className="pt-4 border-t border-[#F1E5D8]">
                <h3 className="font-sans text-xs font-semibold uppercase tracking-[0.08em] text-[#77736D] mb-2.5">
                  Collection Edit
                </h3>
                <div className="grid grid-cols-2 gap-2">
                  {(
                    [
                      { id: 'all', label: 'All Pieces' },
                      { id: 'bestsellers', label: 'Best Sellers' },
                      { id: 'new', label: 'New Arrivals' },
                      { id: 'sale', label: 'On Sale' },
                    ] as const
                  ).map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setSpecialFilter(opt.id)}
                      className={`px-3 py-2 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                        specialFilter === opt.id
                          ? 'bg-[#7A0B24] border-[#7A0B24] text-white'
                          : 'bg-[#FFF9F1] border-[#EDE5DB] text-[#171A18] hover:border-[#7A0B24]'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price Range */}
              <div className="pt-4 border-t border-[#F1E5D8]">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-sans text-xs font-semibold uppercase tracking-[0.08em] text-[#77736D]">
                    Max Price
                  </h3>
                  <span className="text-sm font-semibold text-[#7A0B24] tabular-nums">
                    {formatPrice(maxPrice)}
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={priceCeiling}
                  step={500}
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(Number(e.target.value))}
                  aria-label="Maximum price filter"
                  className="w-full accent-[#7A0B24] cursor-pointer"
                />
                <div className="flex justify-between text-[11px] text-[#77736D] tabular-nums mt-1">
                  <span>{formatPrice(0)}</span>
                  <span>{formatPrice(priceCeiling)}</span>
                </div>
              </div>
            </div>
          </aside>

          {/* Product Grid */}
          <div className="lg:col-span-9">
            {/* Active filter pills summary (interactive remove buttons) */}
            {(selectedCategory !== 'all' || specialFilter !== 'all' || searchTerm.trim() || maxPrice < priceCeiling) && (
              <div className="flex flex-wrap items-center gap-2 mb-5">
                {selectedCategory !== 'all' && (
                  <button
                    type="button"
                    onClick={() => setSelectedCategory('all')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#F1E5D8] text-xs font-medium text-[#171A18] hover:bg-[#EDE5DB] cursor-pointer"
                  >
                    <span>Category: {selectedCategory}</span>
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
                {specialFilter !== 'all' && (
                  <button
                    type="button"
                    onClick={() => setSpecialFilter('all')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#F1E5D8] text-xs font-medium text-[#171A18] hover:bg-[#EDE5DB] cursor-pointer"
                  >
                    <span>Edit: {specialFilter}</span>
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
                {maxPrice < priceCeiling && (
                  <button
                    type="button"
                    onClick={() => setMaxPrice(priceCeiling)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#F1E5D8] text-xs font-medium text-[#171A18] hover:bg-[#EDE5DB] cursor-pointer"
                  >
                    <span>Under {formatPrice(maxPrice)}</span>
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            )}

            {filteredProducts.length === 0 ? (
              <div className="bg-white border border-[#EDE5DB] rounded-2xl p-12 text-center">
                <h2 className="font-editorial text-3xl font-semibold text-[#171A18] mb-2">
                  No pieces match your selection
                </h2>
                <p className="text-sm text-[#77736D] mb-6">
                  Try widening your price ceiling or clearing active category filters.
                </p>
                <button
                  type="button"
                  onClick={resetFilters}
                  className="px-6 py-3 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] cursor-pointer"
                >
                  Reset Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
