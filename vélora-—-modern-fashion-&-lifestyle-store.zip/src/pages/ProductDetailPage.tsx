import {
  Check,
  ChevronRight,
  Heart,
  Minus,
  Pencil,
  Plus,
  RotateCcw,
  ShieldCheck,
  ShoppingBag,
  Star,
  Trash2,
  Truck,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { ProductCard } from '../components/common/ProductCard';
import { SafeImage } from '../components/common/SafeImage';
import { formatPrice, STORE_CONFIG } from '../config/storeConfig';
import { useFirebase } from '../context/FirebaseContext';
import { useStore } from '../context/StoreContext';
import { Link, useRouter } from '../router/RouterContext';

interface ProductDetailPageProps {
  slug: string;
}

export function ProductDetailPage({ slug }: ProductDetailPageProps) {
  const { isAdmin } = useFirebase();
  const { products, addToCart, isInWishlist, toggleWishlist, deleteProduct } = useStore();
  const { navigate } = useRouter();

  const product = products.find((p) => p.slug === slug);

  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string | undefined>(undefined);
  const [selectedColor, setSelectedColor] = useState<string | undefined>(undefined);
  const [quantity, setQuantity] = useState(1);
  const [confirmingDelete, setConfirmingDelete] = useState(false);

  useEffect(() => {
    if (!product) return;
    setSelectedImage(0);
    setSelectedSize(product.sizes?.[0]);
    setSelectedColor(product.colors?.[0]?.name);
    setQuantity(1);
    document.title = `${product.name} — ${STORE_CONFIG.brandName}`;
  }, [product]);

  if (!product) {
    return (
      <div className="bg-[#FFF9F1] py-20 text-center px-4">
        <h1 className="font-editorial text-4xl font-semibold text-[#171A18] mb-3">
          Piece Not Found
        </h1>
        <p className="text-sm text-[#77736D] mb-6">
          The product you are looking for may have moved or sold out.
        </p>
        <Link
          to="/shop"
          className="inline-flex px-6 py-3 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734]"
        >
          Return to Shop
        </Link>
      </div>
    );
  }

  const wishlisted = isInWishlist(product.id);
  const related = products.filter(
    (p) => p.id !== product.id && (p.categorySlug === product.categorySlug || p.isBestSeller)
  ).slice(0, 4);

  const handleBuyNow = () => {
    addToCart(product, {
      quantity,
      size: selectedSize,
      color: selectedColor,
      openDrawer: false,
    });
    navigate('/checkout');
  };

  return (
    <div className="bg-[#FFF9F1] py-8 sm:py-12">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10">
        {/* Breadcrumb */}
        <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-xs text-[#77736D] mb-8">
          <Link to="/" className="hover:text-[#7A0B24]">
            Home
          </Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <Link to="/shop" className="hover:text-[#7A0B24]">
            Shop
          </Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <Link to={`/shop?category=${product.categorySlug}`} className="hover:text-[#7A0B24]">
            {product.categoryName.split('·')[0].trim()}
          </Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-[#171A18] font-medium truncate">{product.name}</span>
        </nav>

        {/* Contiguous PDP Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          {/* Left Gallery */}
          <div className="lg:col-span-7 space-y-4">
            <div className="relative aspect-[4/3] rounded-3xl overflow-hidden bg-[#F8F0E6] border border-[#EDE5DB]">
              <SafeImage
                src={product.gallery[selectedImage] || product.image}
                alt={product.imageAlt}
                loading="eager"
                className="w-full h-full object-cover"
              />
              {product.discountPercent && (
                <span className="absolute top-4 left-4 px-3 py-1 rounded-lg bg-[#E07A3A] text-white text-xs font-semibold tabular-nums">
                  Save {product.discountPercent}%
                </span>
              )}
            </div>

            {product.gallery.length > 1 && (
              <div className="flex items-center gap-3">
                {product.gallery.map((imgUrl, idx) => (
                  <button
                    key={imgUrl + idx}
                    type="button"
                    onClick={() => setSelectedImage(idx)}
                    aria-label={`View gallery image ${idx + 1}`}
                    className={`w-24 aspect-[4/3] rounded-xl overflow-hidden border-2 transition-all cursor-pointer ${
                      selectedImage === idx
                        ? 'border-[#7A0B24] shadow-sm'
                        : 'border-[#EDE5DB] opacity-75 hover:opacity-100'
                    }`}
                  >
                    <SafeImage
                      src={imgUrl}
                      alt={`${product.name} view ${idx + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Contiguous Purchase Module */}
          <div className="lg:col-span-5 lg:sticky lg:top-24 bg-white border border-[#EDE5DB] rounded-3xl p-6 sm:p-8 shadow-[0_10px_30px_rgba(23,26,24,0.05)] space-y-6">
            <div>
              <p className="text-xs uppercase tracking-[0.12em] text-[#961734] font-semibold mb-1.5">
                {product.categoryName} · SKU {product.sku}
              </p>
              <h1 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#171A18] leading-tight">
                {product.name}
              </h1>

              <div className="flex items-center gap-3 mt-3">
                <div className="flex items-center gap-1 text-sm">
                  <Star className="w-4 h-4 text-[#EAB96B] fill-[#EAB96B]" />
                  <span className="font-semibold text-[#171A18] tabular-nums">
                    {product.rating.toFixed(1)}
                  </span>
                </div>
                <span className="text-[#EDE5DB]">|</span>
                <span className="text-xs text-[#77736D] tabular-nums">
                  {product.reviewCount} reviews
                </span>
                <span className="text-[#EDE5DB]">|</span>
                <span className="text-xs font-medium text-[#961734] tabular-nums">
                  {product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}
                </span>
              </div>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-3 pb-5 border-b border-[#F1E5D8]">
              <span className="text-3xl font-bold text-[#171A18] tabular-nums">
                {formatPrice(product.price)}
              </span>
              {product.originalPrice && (
                <span className="text-base text-[#77736D] line-through tabular-nums">
                  {formatPrice(product.originalPrice)}
                </span>
              )}
            </div>

            <p className="text-sm sm:text-base text-[#77736D] leading-relaxed">
              {product.description}
            </p>

            {/* Color Options */}
            {product.colors && product.colors.length > 0 && (
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.08em] text-[#171A18] mb-2.5">
                  Color: <span className="font-normal text-[#77736D]">{selectedColor}</span>
                </p>
                <div className="flex flex-wrap gap-2.5">
                  {product.colors.map((color) => (
                    <button
                      key={color.name}
                      type="button"
                      onClick={() => setSelectedColor(color.name)}
                      className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                        selectedColor === color.name
                          ? 'border-[#7A0B24] bg-[#F8F0E6] text-[#7A0B24] font-semibold'
                          : 'border-[#EDE5DB] bg-white text-[#171A18] hover:border-[#7A0B24]/50'
                      }`}
                    >
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-black/15"
                        style={{ backgroundColor: color.hex }}
                      />
                      <span>{color.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Size Options */}
            {product.sizes && product.sizes.length > 0 && (
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.08em] text-[#171A18] mb-2.5">
                  Size: <span className="font-normal text-[#77736D]">{selectedSize}</span>
                </p>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      type="button"
                      onClick={() => setSelectedSize(size)}
                      className={`min-w-[46px] px-3.5 py-2 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                        selectedSize === size
                          ? 'bg-[#7A0B24] border-[#7A0B24] text-white'
                          : 'bg-[#FFF9F1] border-[#EDE5DB] text-[#171A18] hover:border-[#7A0B24]'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity + Action Buttons */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center gap-3">
                <div className="inline-flex items-center border border-[#EDE5DB] rounded-xl bg-[#FFF9F1] h-12">
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    aria-label="Decrease quantity"
                    className="w-11 h-full flex items-center justify-center text-[#171A18] hover:bg-[#F1E5D8] rounded-l-xl cursor-pointer"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-10 text-center text-sm font-semibold tabular-nums">
                    {quantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
                    aria-label="Increase quantity"
                    className="w-11 h-full flex items-center justify-center text-[#171A18] hover:bg-[#F1E5D8] rounded-r-xl cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() =>
                    addToCart(product, {
                      quantity,
                      size: selectedSize,
                      color: selectedColor,
                    })
                  }
                  className="flex-1 h-12 inline-flex items-center justify-center gap-2 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] active:scale-[0.99] transition-all cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Add to Bag</span>
                </button>

                <button
                  type="button"
                  onClick={() => toggleWishlist(product.id, product.name)}
                  aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
                  aria-pressed={wishlisted}
                  className={`w-12 h-12 rounded-xl border flex items-center justify-center transition-colors cursor-pointer ${
                    wishlisted
                      ? 'bg-[#7A0B24] border-[#7A0B24] text-white'
                      : 'border-[#EDE5DB] bg-[#FFF9F1] text-[#171A18] hover:border-[#7A0B24]'
                  }`}
                >
                  <Heart className="w-5 h-5" fill={wishlisted ? 'currentColor' : 'none'} />
                </button>
              </div>

              <button
                type="button"
                onClick={handleBuyNow}
                className="w-full h-12 rounded-xl bg-[#EAB96B] text-[#171A18] text-sm font-semibold hover:bg-[#f2c882] transition-colors cursor-pointer"
              >
                Buy Now — Proceed to Checkout
              </button>
            </div>

            {/* Materials & Service Assurances */}
            <div className="pt-4 border-t border-[#F1E5D8] space-y-3">
              <p className="text-xs font-semibold uppercase tracking-[0.08em] text-[#171A18]">
                Materials &amp; Care
              </p>
              <ul className="space-y-1.5">
                {product.materialsAndCare.map((line) => (
                  <li key={line} className="flex items-start gap-2 text-xs text-[#77736D]">
                    <Check className="w-3.5 h-3.5 text-[#7A0B24] shrink-0 mt-0.5" />
                    <span>{line}</span>
                  </li>
                ))}
              </ul>

              <div className="grid grid-cols-3 gap-2 pt-3 text-[11px] text-[#77736D]">
                <div className="flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-[#7A0B24] shrink-0" />
                  <span>All Pakistan Free Delivery</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <RotateCcw className="w-3.5 h-3.5 text-[#7A0B24] shrink-0" />
                  <span>30-day returns</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#7A0B24] shrink-0" />
                  <span>12-mo warranty</span>
                </div>
              </div>

              {isAdmin && (
                <div className="pt-3 border-t border-[#F1E5D8] flex items-center justify-between gap-2">
                  {confirmingDelete ? (
                    <div className="flex items-center justify-between w-full gap-2">
                      <span className="text-xs font-medium text-red-700">
                        Delete this product from store?
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setConfirmingDelete(false)}
                          className="px-3 py-1.5 rounded-lg border border-[#EDE5DB] text-xs font-medium text-[#171A18] hover:bg-[#F8F0E6] cursor-pointer"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            void deleteProduct(product.id);
                            navigate('/shop');
                          }}
                          className="px-3 py-1.5 rounded-lg bg-red-700 text-white text-xs font-semibold hover:bg-red-800 cursor-pointer"
                        >
                          Confirm Delete
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between w-full gap-4">
                      <Link
                        to={`/add-product?edit=${encodeURIComponent(product.id)}`}
                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#7A0B24] hover:underline"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                        <span>Edit product</span>
                      </Link>
                      <button
                        type="button"
                        onClick={() => setConfirmingDelete(true)}
                        className="inline-flex items-center gap-1.5 text-xs font-medium text-[#77736D] hover:text-red-700 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Delete product from store</span>
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Related Products */}
        {related.length > 0 && (
          <section className="mt-16 pt-12 border-t border-[#EDE5DB]">
            <div className="flex items-end justify-between mb-8">
              <div>
                <h2 className="font-editorial text-3xl font-semibold text-[#171A18]">
                  You May Also Appreciate
                </h2>
                <p className="text-sm text-[#77736D] mt-1">
                  Complementary pieces from the Shah Store Royal Shopping catalog.
                </p>
              </div>
              <Link to="/shop" className="text-sm font-semibold text-[#7A0B24] hover:underline">
                View All →
              </Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {related.map((item) => (
                <ProductCard key={item.id} product={item} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
