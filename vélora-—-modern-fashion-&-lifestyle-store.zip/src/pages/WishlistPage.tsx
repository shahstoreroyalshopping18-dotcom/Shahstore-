import { Heart, ShoppingBag, Trash2 } from 'lucide-react';
import { SafeImage } from '../components/common/SafeImage';
import { formatPrice } from '../config/storeConfig';
import { useStore } from '../context/StoreContext';
import { Link } from '../router/RouterContext';

export function WishlistPage() {
  const { products, wishlist, toggleWishlist, addToCart } = useStore();

  const savedProducts = wishlist
    .map((w) => products.find((p) => p.id === w.productId))
    .filter((p): p is NonNullable<typeof p> => Boolean(p));

  return (
    <div className="bg-[#FFF9F1] min-h-[70vh] py-12 sm:py-16">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10">
        <div className="pb-8 border-b border-[#EDE5DB] mb-8 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#961734] mb-1.5">
              Personal Curation
            </p>
            <h1 className="font-editorial text-4xl sm:text-5xl font-semibold text-[#171A18]">
              Saved Wishlist ({savedProducts.length})
            </h1>
          </div>
          <Link to="/shop" className="text-sm font-semibold text-[#7A0B24] hover:underline">
            Continue Shopping →
          </Link>
        </div>

        {savedProducts.length === 0 ? (
          <div className="bg-white border border-[#EDE5DB] rounded-3xl p-12 text-center max-w-xl mx-auto">
            <div className="w-14 h-14 rounded-full bg-[#F1E5D8] text-[#7A0B24] flex items-center justify-center mx-auto mb-4">
              <Heart className="w-6 h-6" strokeWidth={1.75} />
            </div>
            <h2 className="font-editorial text-3xl font-semibold text-[#171A18] mb-2">
              No saved pieces yet
            </h2>
            <p className="text-sm text-[#77736D] mb-6">
              Tap the heart icon on any product to save favorites across visits.
            </p>
            <Link
              to="/shop"
              className="inline-flex px-6 py-3 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734]"
            >
              Explore Collection
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {savedProducts.map((product) => (
              <article
                key={product.id}
                className="bg-white border border-[#EDE5DB] rounded-2xl overflow-hidden flex flex-col shadow-sm"
              >
                <Link
                  to={`/product/${product.slug}`}
                  className="aspect-[4/3] bg-[#F8F0E6] overflow-hidden block"
                >
                  <SafeImage
                    src={product.image}
                    alt={product.imageAlt}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  />
                </Link>
                <div className="p-4 flex flex-col flex-1 justify-between gap-4">
                  <div>
                    <p className="text-[11px] uppercase tracking-[0.08em] text-[#77736D]">
                      {product.categoryName}
                    </p>
                    <Link
                      to={`/product/${product.slug}`}
                      className="block text-base font-semibold text-[#171A18] hover:text-[#7A0B24] mt-0.5 truncate"
                    >
                      {product.name}
                    </Link>
                    <p className="text-sm font-bold text-[#171A18] tabular-nums mt-1">
                      {formatPrice(product.price)}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-[#F1E5D8]">
                    <button
                      type="button"
                      onClick={() => addToCart(product)}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg bg-[#7A0B24] text-white text-xs font-semibold hover:bg-[#961734] cursor-pointer"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>Move to Bag</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => toggleWishlist(product.id, product.name)}
                      aria-label={`Remove ${product.name} from wishlist`}
                      className="w-9 h-9 rounded-lg border border-[#EDE5DB] flex items-center justify-center text-[#77736D] hover:text-[#171A18] hover:border-[#7A0B24] cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
