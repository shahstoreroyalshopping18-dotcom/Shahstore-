import {
  AlertCircle,
  CheckCircle2,
  ExternalLink,
  Facebook,
  ImagePlus,
  Instagram,
  Lock,
  LogOut,
  MapPin,
  Package,
  Pencil,
  Phone,
  Plus,
  RotateCcw,
  Search,
  Share2,
  ShieldCheck,
  Star,
  Trash2,
  Upload,
  X,
  Youtube,
} from 'lucide-react';
import { ChangeEvent, DragEvent, FormEvent, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { SafeImage } from '../components/common/SafeImage';
import { formatPrice } from '../config/storeConfig';
import { useFirebase } from '../context/FirebaseContext';
import { useStore } from '../context/StoreContext';
import { CATEGORIES } from '../data/categories';
import { Link, useRouter } from '../router/RouterContext';
import { SocialLinksConfig } from '../services/storeAdapter';
import { CategorySlug, OrderStatus, Product, ProductColorOption } from '../types/ecommerce';

type SocialPlatformKey = keyof SocialLinksConfig;
const ORDER_STATUS_OPTIONS: OrderStatus[] = [
  'Order Received (COD)',
  'Preparing Shipment',
  'Dispatched',
  'Delivered',
  'Cancelled',
];

function normalizeSocialUrl(platform: SocialPlatformKey, rawValue: string): string {
  const val = rawValue.trim();
  if (!val) return '';
  if (val.startsWith('http://') || val.startsWith('https://')) {
    return val;
  }
  if (/^(www\.)?(facebook|fb|instagram|youtube|youtu\.be|tiktok|pinterest)\./i.test(val)) {
    return `https://${val}`;
  }
  const handle = val.replace(/^@+/, '').replace(/^\/+/, '');
  switch (platform) {
    case 'facebook':
      return `https://facebook.com/${handle}`;
    case 'instagram':
      return `https://instagram.com/${handle}`;
    case 'youtube':
      return `https://youtube.com/@${handle}`;
    case 'tiktok':
      return `https://tiktok.com/@${handle}`;
    case 'pinterest':
      return `https://pinterest.com/${handle}`;
  }
}

const PRESET_SIZES = ['XS', 'S', 'M', 'L', 'XL', 'One Size'];

function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

async function compressImageToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image file.'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Invalid image format.'));
      img.onload = () => {
        const maxDim = 720;
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          if (width >= height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(reader.result as string);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.74));
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  });
}

export function AddProductPage() {
  const {
    user,
    isAuthReady,
    isAdmin,
    authError,
    isSigningIn,
    signInAsOwner,
    signOutOwner,
  } = useFirebase();
  const {
    products,
    customProducts,
    deletedDefaultProducts,
    socialLinks,
    ownerOrders,
    localDraftCount,
    addProduct,
    updateProduct,
    deleteProduct,
    restoreDefaultProduct,
    restoreAllDefaultProducts,
    updateSocialLinks,
    resetSocialLinks,
    syncLocalDraftsToLiveStore,
    discardLocalDrafts,
    updateOrderStatus,
    deleteOrderRecord,
  } = useStore();
  const { searchParams, navigate } = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const tabParam = searchParams.get('tab');
  const [activeTab, setActiveTab] = useState<'products' | 'social' | 'orders'>(() => {
    if (tabParam === 'social') return 'social';
    if (tabParam === 'orders') return 'orders';
    return 'products';
  });
  const [socialDraft, setSocialDraft] = useState<SocialLinksConfig>(() => ({ ...socialLinks }));
  const [socialSavedBanner, setSocialSavedBanner] = useState(false);
  const [isSavingProduct, setIsSavingProduct] = useState(false);
  const [isSavingSocial, setIsSavingSocial] = useState(false);
  const [isSyncingDrafts, setIsSyncingDrafts] = useState(false);
  const [confirmDeleteOrderId, setConfirmDeleteOrderId] = useState<string | null>(null);

  const [manageFilter, setManageFilter] = useState<'all' | 'custom' | 'builtin'>('all');
  const [manageSearch, setManageSearch] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  const [images, setImages] = useState<string[]>([]);
  const [imageUrlInput, setImageUrlInput] = useState('');
  const [isDragging, setIsDragging] = useState(false);

  const [name, setName] = useState('');
  const [categorySlug, setCategorySlug] = useState<CategorySlug>('women');
  const [subCategory, setSubCategory] = useState('Royal Edit');
  const [price, setPrice] = useState('');
  const [originalPrice, setOriginalPrice] = useState('');
  const [stock, setStock] = useState('15');
  const [shortDescription, setShortDescription] = useState('');
  const [description, setDescription] = useState('');
  const [selectedSizes, setSelectedSizes] = useState<string[]>(['S', 'M', 'L']);
  const [customSizeInput, setCustomSizeInput] = useState('');

  const [colors, setColors] = useState<ProductColorOption[]>([
    { name: 'Royal Crimson', hex: '#7A0B24' },
  ]);
  const [colorNameInput, setColorNameInput] = useState('');
  const [colorHexInput, setColorHexInput] = useState('#D9A441');

  const [careNotes, setCareNotes] = useState(
    'Crafted from curated premium materials\nSpot clean or gentle care recommended'
  );
  const [isNewArrival, setIsNewArrival] = useState(true);
  const [isBestSeller, setIsBestSeller] = useState(false);

  const [error, setError] = useState('');
  const [savedNotice, setSavedNotice] = useState<{
    product: Product;
    mode: 'added' | 'updated';
  } | null>(null);

  const resetFormToCreate = useCallback(() => {
    setEditingProduct(null);
    setImages([]);
    setImageUrlInput('');
    setName('');
    setCategorySlug('women');
    setSubCategory('Royal Edit');
    setPrice('');
    setOriginalPrice('');
    setStock('15');
    setShortDescription('');
    setDescription('');
    setSelectedSizes(['S', 'M', 'L']);
    setColors([{ name: 'Royal Crimson', hex: '#7A0B24' }]);
    setCareNotes('Crafted from curated premium materials\nSpot clean or gentle care recommended');
    setIsNewArrival(true);
    setIsBestSeller(false);
    setError('');
  }, []);

  const populateFormForEdit = useCallback((prod: Product) => {
    setEditingProduct(prod);
    setSavedNotice(null);
    setError('');
    setImages(prod.gallery && prod.gallery.length > 0 ? [...prod.gallery] : [prod.image]);
    setImageUrlInput('');
    setName(prod.name);
    setCategorySlug(prod.categorySlug);
    const parts = prod.categoryName.split('·');
    setSubCategory(parts.length > 1 ? parts.slice(1).join('·').trim() : '');
    setPrice(String(prod.price));
    setOriginalPrice(prod.originalPrice ? String(prod.originalPrice) : '');
    setStock(String(prod.stock));
    setShortDescription(prod.shortDescription);
    setDescription(prod.description);
    setSelectedSizes(prod.sizes ? [...prod.sizes] : []);
    setColors(prod.colors ? prod.colors.map((c) => ({ ...c })) : []);
    setCareNotes(prod.materialsAndCare.join('\n'));
    setIsNewArrival(Boolean(prod.isNewArrival));
    setIsBestSeller(Boolean(prod.isBestSeller));
  }, []);

  const editIdParam = searchParams.get('edit');
  const lastLoadedEditParamRef = useRef<string | null>(null);
  useEffect(() => {
    if (tabParam === 'social') {
      setActiveTab('social');
    } else if (tabParam === 'orders') {
      setActiveTab('orders');
    } else if (editIdParam) {
      setActiveTab('products');
    }
  }, [editIdParam, tabParam]);

  useEffect(() => {
    setSocialDraft({ ...socialLinks });
  }, [socialLinks]);

  useEffect(() => {
    if (!editIdParam) {
      lastLoadedEditParamRef.current = null;
      return;
    }
    if (lastLoadedEditParamRef.current === editIdParam) return;
    const match = products.find((p) => p.id === editIdParam);
    if (match) {
      lastLoadedEditParamRef.current = editIdParam;
      populateFormForEdit(match);
    }
  }, [editIdParam, populateFormForEdit, products]);

  const handleSaveSocialLinks = async (e: FormEvent) => {
    e.preventDefault();
    if (isSavingSocial) return;
    const normalized: SocialLinksConfig = {
      facebook: normalizeSocialUrl('facebook', socialDraft.facebook),
      youtube: normalizeSocialUrl('youtube', socialDraft.youtube),
      tiktok: normalizeSocialUrl('tiktok', socialDraft.tiktok),
      instagram: normalizeSocialUrl('instagram', socialDraft.instagram),
      pinterest: normalizeSocialUrl('pinterest', socialDraft.pinterest),
    };
    setIsSavingSocial(true);
    try {
      await updateSocialLinks(normalized);
      setSocialDraft(normalized);
      setSocialSavedBanner(true);
    } finally {
      setIsSavingSocial(false);
    }
  };

  const customIdSet = useMemo(() => new Set(customProducts.map((p) => p.id)), [customProducts]);

  const managedProducts = useMemo(() => {
    const q = manageSearch.trim().toLowerCase();
    return products.filter((item) => {
      const isCustom = customIdSet.has(item.id);
      if (manageFilter === 'custom' && !isCustom) return false;
      if (manageFilter === 'builtin' && isCustom) return false;
      if (q && !item.name.toLowerCase().includes(q) && !item.categoryName.toLowerCase().includes(q)) {
        return false;
      }
      return true;
    });
  }, [customIdSet, manageFilter, manageSearch, products]);

  const selectedCategoryObj = CATEGORIES.find((c) => c.slug === categorySlug);

  const parsedPrice = Number(price) || 0;
  const parsedOriginal = Number(originalPrice) || 0;
  const computedDiscount =
    parsedOriginal > parsedPrice && parsedPrice > 0
      ? Math.round(((parsedOriginal - parsedPrice) / parsedOriginal) * 100)
      : undefined;

  const handleFiles = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    setError('');
    const validFiles = Array.from(fileList).filter((f) => f.type.startsWith('image/'));
    if (validFiles.length === 0) {
      setError('Please upload valid image files (JPG, PNG, or WebP).');
      return;
    }

    try {
      const compressed = await Promise.all(validFiles.slice(0, 5).map(compressImageToDataUrl));
      setImages((prev) => [...prev, ...compressed].slice(0, 6));
    } catch {
      setError('Could not process one of the selected images. Please try another file.');
    }
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    void handleFiles(e.target.files);
    e.target.value = '';
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    void handleFiles(e.dataTransfer.files);
  };

  const handleAddImageUrl = () => {
    const trimmed = imageUrlInput.trim();
    if (!trimmed) return;
    if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://') && !trimmed.startsWith('/')) {
      setError('Image URL must start with https://, http://, or /.');
      return;
    }
    setError('');
    setImages((prev) => [...prev, trimmed].slice(0, 6));
    setImageUrlInput('');
  };

  const toggleSize = (size: string) => {
    setSelectedSizes((prev) =>
      prev.includes(size) ? prev.filter((s) => s !== size) : [...prev, size]
    );
  };

  const handleAddCustomSize = () => {
    const val = customSizeInput.trim();
    if (!val) return;
    if (!selectedSizes.includes(val)) {
      setSelectedSizes((prev) => [...prev, val]);
    }
    setCustomSizeInput('');
  };

  const handleAddColor = () => {
    const val = colorNameInput.trim();
    if (!val) return;
    setColors((prev) => [...prev, { name: val, hex: colorHexInput }]);
    setColorNameInput('');
  };

  const previewCategoryLabel = useMemo(() => {
    const base = selectedCategoryObj?.name ?? 'Collection';
    return subCategory.trim() ? `${base} · ${subCategory.trim()}` : base;
  }, [selectedCategoryObj, subCategory]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (isSavingProduct) return;
    setError('');

    if (images.length === 0) {
      setError('Please upload at least one product picture.');
      return;
    }
    const totalImageBytes = images.reduce((acc, img) => acc + img.length, 0);
    if (totalImageBytes > 820000) {
      setError('Selected images are too large combined. Please use fewer photos or smaller files.');
      return;
    }
    if (!name.trim()) {
      setError('Please enter a product name.');
      return;
    }
    if (parsedPrice <= 0) {
      setError('Please enter a valid product price greater than PKR 0.');
      return;
    }
    if (!description.trim() && !shortDescription.trim()) {
      setError('Please provide product details / description.');
      return;
    }

    const cleanShort =
      shortDescription.trim() ||
      description.trim().slice(0, 95) + (description.trim().length > 95 ? '...' : '');
    const cleanFull = description.trim() || shortDescription.trim();
    const careList = careNotes
      .split('\n')
      .map((l) => l.trim())
      .filter(Boolean);

    setIsSavingProduct(true);
    try {
      if (editingProduct) {
        const updatedProduct: Product = {
          ...editingProduct,
          name: name.trim(),
          categorySlug,
          categoryName: previewCategoryLabel,
          price: parsedPrice,
          originalPrice: parsedOriginal > parsedPrice ? parsedOriginal : undefined,
          discountPercent: computedDiscount,
          image: images[0],
          gallery: images,
          imageAlt: `${name.trim()} — ${previewCategoryLabel}`,
          shortDescription: cleanShort,
          description: cleanFull,
          materialsAndCare:
            careList.length > 0 ? careList : ['Premium quality finish', 'Hand-inspected before dispatch'],
          sizes: selectedSizes.length > 0 ? selectedSizes : undefined,
          colors: colors.length > 0 ? colors : undefined,
          stock: Math.max(1, Number(stock) || 10),
          isBestSeller,
          isNewArrival,
          isOnSale: Boolean(computedDiscount),
        };

        await updateProduct(updatedProduct);
        setSavedNotice({ product: updatedProduct, mode: 'updated' });
        resetFormToCreate();
        if (editIdParam) {
          navigate('/add-product');
        } else {
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
        return;
      }

      const baseSlug = slugify(name) || `product-${Date.now()}`;
      const slugExists = products.some((p) => p.slug === baseSlug);
      const finalSlug = slugExists ? `${baseSlug}-${Date.now().toString().slice(-4)}` : baseSlug;

      const newProduct: Product = {
        id: `custom-${Date.now()}`,
        sku: `SHAH-${Math.floor(1000 + Math.random() * 9000)}`,
        slug: finalSlug,
        name: name.trim(),
        categorySlug,
        categoryName: previewCategoryLabel,
        price: parsedPrice,
        originalPrice: parsedOriginal > parsedPrice ? parsedOriginal : undefined,
        discountPercent: computedDiscount,
        rating: 5.0,
        reviewCount: 1,
        image: images[0],
        gallery: images,
        imageAlt: `${name.trim()} — ${previewCategoryLabel}`,
        shortDescription: cleanShort,
        description: cleanFull,
        materialsAndCare:
          careList.length > 0 ? careList : ['Premium quality finish', 'Hand-inspected before dispatch'],
        sizes: selectedSizes.length > 0 ? selectedSizes : undefined,
        colors: colors.length > 0 ? colors : undefined,
        stock: Math.max(1, Number(stock) || 10),
        isBestSeller,
        isNewArrival,
        isOnSale: Boolean(computedDiscount),
      };

      await addProduct(newProduct);
      setSavedNotice({ product: newProduct, mode: 'added' });
      resetFormToCreate();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch {
      setError('Could not save product to the live store. Please check your connection and try again.');
    } finally {
      setIsSavingProduct(false);
    }
  };

  if (!isAuthReady) {
    return (
      <div className="bg-[#FFF9F1] min-h-[70vh] flex items-center justify-center px-4">
        <p className="text-sm text-[#77736D] font-medium">Checking store access...</p>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="bg-[#FFF9F1] min-h-[70vh] py-16 px-4 flex items-center justify-center">
        <div className="max-w-md w-full bg-white border border-[#EDE5DB] rounded-3xl p-8 sm:p-10 text-center space-y-5 shadow-[0_12px_36px_rgba(23,26,24,0.06)]">
          <div className="w-14 h-14 rounded-2xl bg-[#7A0B24] text-[#EAB96B] flex items-center justify-center mx-auto">
            <Lock className="w-6 h-6" strokeWidth={1.75} />
          </div>

          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#961734]">
              Private Admin Area
            </p>
            <h1 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#171A18]">
              Store Owner Access Only
            </h1>
            <p className="text-sm text-[#77736D] leading-relaxed">
              Adding or editing products, updating social media links, and viewing customer orders are restricted to the store owner. Public shoppers cannot access these settings.
            </p>
          </div>

          {(authError || user) && (
            <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800 text-left flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>
                {authError ||
                  `Signed in as ${user?.email || 'guest account'}, which is not authorized as the store owner.`}
              </span>
            </div>
          )}

          <div className="space-y-3 pt-1">
            {user ? (
              <button
                type="button"
                onClick={() => void signOutOwner()}
                className="w-full py-3.5 px-5 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] transition-colors cursor-pointer"
              >
                Sign Out &amp; Switch Account
              </button>
            ) : (
              <button
                type="button"
                disabled={isSigningIn}
                onClick={() => void signInAsOwner()}
                className="w-full py-3.5 px-5 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] transition-colors cursor-pointer disabled:opacity-60"
              >
                {isSigningIn ? 'Signing in...' : 'Sign in as Store Owner (Google)'}
              </button>
            )}

            <Link
              to="/shop"
              className="block w-full py-3 px-5 rounded-xl border border-[#EDE5DB] text-sm font-semibold text-[#171A18] hover:border-[#7A0B24] transition-colors"
            >
              Return to Storefront
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#FFF9F1] min-h-[75vh] py-10 sm:py-14">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10 space-y-10">
        {/* Owner Status & Local Drafts Sync Bar */}
        <div className="bg-[#5A071A] text-white rounded-2xl px-5 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 text-xs sm:text-sm">
            <ShieldCheck className="w-4 h-4 text-[#EAB96B] shrink-0" />
            <span>
              Signed in as Store Owner (<strong>{user?.email}</strong>) · Changes publish live for all public visitors
            </span>
          </div>
          <button
            type="button"
            onClick={() => void signOutOwner()}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition-colors self-start sm:self-auto cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5 text-[#EAB96B]" />
            <span>Sign Out (Preview Public View)</span>
          </button>
        </div>

        {localDraftCount > 0 && (
          <div className="bg-white border border-[#EAB96B] rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <p className="text-sm font-semibold text-[#171A18]">
                Unsynced local browser changes found ({localDraftCount})
              </p>
              <p className="text-xs text-[#77736D] mt-0.5">
                Push your earlier browser edits to the live public store so every visitor sees them.
              </p>
            </div>
            <div className="flex items-center gap-2.5 shrink-0">
              <button
                type="button"
                disabled={isSyncingDrafts}
                onClick={async () => {
                  setIsSyncingDrafts(true);
                  try {
                    await syncLocalDraftsToLiveStore();
                  } finally {
                    setIsSyncingDrafts(false);
                  }
                }}
                className="px-4 py-2 rounded-xl bg-[#7A0B24] text-white text-xs font-semibold hover:bg-[#961734] cursor-pointer disabled:opacity-60"
              >
                {isSyncingDrafts ? 'Publishing...' : 'Publish to Live Store'}
              </button>
              <button
                type="button"
                onClick={discardLocalDrafts}
                className="px-3.5 py-2 rounded-xl border border-[#EDE5DB] text-xs font-medium text-[#77736D] hover:text-[#171A18] cursor-pointer"
              >
                Discard
              </button>
            </div>
          </div>
        )}

        {/* Page Header */}
        <div className="pb-6 border-b border-[#EDE5DB] space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#961734] mb-1.5">
                Store &amp; Catalog Studio
              </p>
              <h1 className="font-editorial text-4xl sm:text-5xl font-semibold text-[#171A18]">
                {activeTab === 'social'
                  ? 'Social Media Links & IDs'
                  : activeTab === 'orders'
                    ? `Customer Orders (${ownerOrders.length})`
                    : editingProduct
                      ? 'Edit Product & Pictures'
                      : 'Add Product & Pictures'}
              </h1>
              <p className="text-sm sm:text-base text-[#77736D] mt-1.5">
                {activeTab === 'social'
                  ? 'Add your Facebook, YouTube, TikTok, Instagram, and Pinterest links or profile IDs.'
                  : activeTab === 'orders'
                    ? 'Review Cash on Delivery orders placed by customers across Pakistan.'
                    : editingProduct
                      ? `Updating "${editingProduct.name}" (${editingProduct.sku}). Save changes when ready.`
                      : 'Upload product photos and details to publish live to all visitors, or edit and remove existing items.'}
              </p>
            </div>
            <div className="flex items-center gap-4">
              {activeTab === 'products' && editingProduct && (
                <button
                  type="button"
                  onClick={() => {
                    resetFormToCreate();
                    if (editIdParam) navigate('/add-product');
                  }}
                  className="px-4 py-2 rounded-xl border border-[#EDE5DB] bg-white text-xs font-semibold text-[#171A18] hover:border-[#7A0B24] cursor-pointer"
                >
                  Cancel Edit
                </button>
              )}
              <Link
                to="/shop"
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#7A0B24] hover:underline whitespace-nowrap"
              >
                <span>View Storefront Catalog ({products.length})</span>
                <ExternalLink className="w-4 h-4" />
              </Link>
            </div>
          </div>

          {/* Studio Mode Tabs */}
          <div className="flex flex-wrap gap-2.5">
            <button
              type="button"
              onClick={() => {
                setActiveTab('products');
                if (tabParam) navigate('/owner');
              }}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold border transition-colors cursor-pointer ${
                activeTab === 'products'
                  ? 'bg-[#7A0B24] border-[#7A0B24] text-white'
                  : 'bg-white border-[#EDE5DB] text-[#171A18] hover:border-[#7A0B24]'
              }`}
            >
              <ImagePlus className="w-4 h-4" />
              <span>Products &amp; Pictures</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('social');
                setSocialSavedBanner(false);
                navigate('/owner?tab=social');
              }}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold border transition-colors cursor-pointer ${
                activeTab === 'social'
                  ? 'bg-[#7A0B24] border-[#7A0B24] text-white'
                  : 'bg-white border-[#EDE5DB] text-[#171A18] hover:border-[#7A0B24]'
              }`}
            >
              <Share2 className="w-4 h-4" />
              <span>Social Media Links</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('orders');
                navigate('/owner?tab=orders');
              }}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold border transition-colors cursor-pointer ${
                activeTab === 'orders'
                  ? 'bg-[#7A0B24] border-[#7A0B24] text-white'
                  : 'bg-white border-[#EDE5DB] text-[#171A18] hover:border-[#7A0B24]'
              }`}
            >
              <Package className="w-4 h-4" />
              <span>Customer Orders ({ownerOrders.length})</span>
            </button>
          </div>
        </div>

        {activeTab === 'orders' ? (
          <div className="space-y-6">
            {ownerOrders.length === 0 ? (
              <div className="bg-white border border-[#EDE5DB] rounded-3xl p-12 text-center space-y-3">
                <div className="w-14 h-14 rounded-full bg-[#F1E5D8] text-[#7A0B24] flex items-center justify-center mx-auto">
                  <Package className="w-6 h-6" />
                </div>
                <h2 className="font-editorial text-2xl font-semibold text-[#171A18]">
                  No Customer Orders Yet
                </h2>
                <p className="text-sm text-[#77736D] max-w-md mx-auto">
                  When public shoppers place Cash on Delivery orders, their full name, mobile number, city, complete delivery address, and ordered items appear here privately for you.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {ownerOrders.map((ord) => (
                  <div
                    key={ord.id}
                    className="bg-white border border-[#EDE5DB] rounded-2xl p-5 sm:p-6 space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#F1E5D8]">
                      <div>
                        <div className="flex items-center gap-2.5">
                          <span className="text-base font-bold text-[#171A18]">
                            #{ord.orderNumber}
                          </span>
                          <span className="px-2.5 py-0.5 rounded-md bg-[#F8F0E6] text-[#7A0B24] text-xs font-semibold">
                            {ord.status}
                          </span>
                        </div>
                        <p className="text-xs text-[#77736D] mt-0.5">
                          {new Date(ord.createdAt).toLocaleString()} · Cash on Delivery · All Pakistan Free Delivery
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-2.5">
                        <select
                          aria-label={`Update status for ${ord.orderNumber}`}
                          value={ord.status}
                          onChange={(e) =>
                            void updateOrderStatus(ord.id, e.target.value as OrderStatus)
                          }
                          className="px-3 py-2 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1] text-xs font-semibold text-[#171A18] focus:outline-none focus:border-[#7A0B24] cursor-pointer"
                        >
                          {ORDER_STATUS_OPTIONS.map((st) => (
                            <option key={st} value={st}>
                              {st}
                            </option>
                          ))}
                        </select>

                        {confirmDeleteOrderId === ord.id ? (
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                void deleteOrderRecord(ord.id);
                                setConfirmDeleteOrderId(null);
                              }}
                              className="px-3 py-2 rounded-xl bg-red-700 text-white text-xs font-semibold hover:bg-red-800 cursor-pointer"
                            >
                              Confirm Delete
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteOrderId(null)}
                              className="px-2.5 py-2 text-xs text-[#77736D] hover:text-[#171A18] cursor-pointer"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteOrderId(ord.id)}
                            className="p-2 rounded-xl border border-[#EDE5DB] text-[#77736D] hover:text-red-700 hover:border-red-300 cursor-pointer"
                            aria-label={`Delete order ${ord.orderNumber}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs sm:text-sm">
                      <div className="p-4 rounded-xl bg-[#FFF9F1] border border-[#EDE5DB] space-y-1">
                        <p className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[#961734]">
                          Customer &amp; Delivery Address
                        </p>
                        <p className="font-semibold text-[#171A18]">{ord.customer.fullName}</p>
                        <p className="text-[#77736D] flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-[#7A0B24]" />
                          <span>{ord.customer.phone}</span>
                        </p>
                        <p className="text-[#77736D] flex items-start gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-[#7A0B24] shrink-0 mt-0.5" />
                          <span>
                            {ord.customer.address}, <strong>{ord.customer.city}</strong>
                          </span>
                        </p>
                      </div>

                      <div className="p-4 rounded-xl bg-[#FFF9F1] border border-[#EDE5DB] space-y-2">
                        <p className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[#961734]">
                          Items ({ord.items.reduce((acc, i) => acc + i.quantity, 0)})
                        </p>
                        <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                          {ord.items.map((item) => (
                            <div key={item.key} className="flex items-center justify-between gap-2 text-xs">
                              <span className="text-[#171A18] truncate">
                                {item.quantity}× {item.name}
                                {item.selectedSize ? ` (${item.selectedSize})` : ''}
                                {item.selectedColor ? ` · ${item.selectedColor}` : ''}
                              </span>
                              <span className="font-semibold text-[#171A18] tabular-nums shrink-0">
                                {formatPrice(item.price * item.quantity)}
                              </span>
                            </div>
                          ))}
                        </div>
                        <div className="pt-2 border-t border-[#EDE5DB] flex items-center justify-between text-sm font-bold text-[#7A0B24]">
                          <span>Total COD</span>
                          <span className="tabular-nums">{formatPrice(ord.total)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : activeTab === 'social' ? (
          <div className="space-y-8">
            {socialSavedBanner && (
              <div className="p-5 rounded-2xl bg-white border border-[#7A0B24] shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-[#7A0B24] shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-semibold text-[#171A18]">
                      Your social media links have been saved!
                    </p>
                    <p className="text-xs text-[#77736D] mt-0.5">
                      Updated live across the Footer and Contact page.
                    </p>
                  </div>
                </div>
                <Link
                  to="/contact"
                  className="px-4 py-2 rounded-xl border border-[#EDE5DB] text-xs font-semibold text-[#171A18] hover:border-[#7A0B24] whitespace-nowrap"
                >
                  View Contact Page
                </Link>
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              <form
                onSubmit={handleSaveSocialLinks}
                className="lg:col-span-7 bg-white border border-[#EDE5DB] rounded-2xl p-6 sm:p-8 space-y-5"
              >
                <div>
                  <h2 className="font-editorial text-2xl font-semibold text-[#171A18]">
                    Connect Your Social Accounts
                  </h2>
                  <p className="text-xs sm:text-sm text-[#77736D] mt-1">
                    Paste your full profile URL (e.g. https://instagram.com/yourid) or simply type your @username / ID. Leave a field blank to hide that platform.
                  </p>
                </div>

                {/* Facebook */}
                <div>
                  <label htmlFor="social-facebook" className="flex items-center gap-2 text-xs font-semibold text-[#171A18] mb-1.5">
                    <Facebook className="w-4 h-4 text-[#7A0B24]" />
                    <span>Facebook Link or Page ID</span>
                  </label>
                  <input
                    id="social-facebook"
                    type="text"
                    value={socialDraft.facebook}
                    onChange={(e) => setSocialDraft((prev) => ({ ...prev, facebook: e.target.value }))}
                    placeholder="https://facebook.com/yourpage or yourpage"
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                  />
                </div>

                {/* YouTube */}
                <div>
                  <label htmlFor="social-youtube" className="flex items-center gap-2 text-xs font-semibold text-[#171A18] mb-1.5">
                    <Youtube className="w-4 h-4 text-[#7A0B24]" />
                    <span>YouTube Channel Link or @Handle</span>
                  </label>
                  <input
                    id="social-youtube"
                    type="text"
                    value={socialDraft.youtube}
                    onChange={(e) => setSocialDraft((prev) => ({ ...prev, youtube: e.target.value }))}
                    placeholder="https://youtube.com/@yourchannel or @yourchannel"
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                  />
                </div>

                {/* TikTok */}
                <div>
                  <label htmlFor="social-tiktok" className="flex items-center gap-2 text-xs font-semibold text-[#171A18] mb-1.5">
                    <svg className="w-4 h-4 text-[#7A0B24]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
                      <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    <span>TikTok Profile Link or @Username</span>
                  </label>
                  <input
                    id="social-tiktok"
                    type="text"
                    value={socialDraft.tiktok}
                    onChange={(e) => setSocialDraft((prev) => ({ ...prev, tiktok: e.target.value }))}
                    placeholder="https://tiktok.com/@yourid or @yourid"
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                  />
                </div>

                {/* Instagram */}
                <div>
                  <label htmlFor="social-instagram" className="flex items-center gap-2 text-xs font-semibold text-[#171A18] mb-1.5">
                    <Instagram className="w-4 h-4 text-[#7A0B24]" />
                    <span>Instagram Profile Link or @Username</span>
                  </label>
                  <input
                    id="social-instagram"
                    type="text"
                    value={socialDraft.instagram}
                    onChange={(e) => setSocialDraft((prev) => ({ ...prev, instagram: e.target.value }))}
                    placeholder="https://instagram.com/yourid or @yourid"
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                  />
                </div>

                {/* Pinterest (Optional) */}
                <div>
                  <label htmlFor="social-pinterest" className="flex items-center gap-2 text-xs font-semibold text-[#171A18] mb-1.5">
                    <svg className="w-4 h-4 text-[#7A0B24]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
                      <circle cx="12" cy="12" r="9" />
                      <path d="M10 16l1.5-6M9.5 11.5c0-1.5 1.1-2.5 2.7-2.5 1.5 0 2.3 1 2.3 2.3 0 1.6-1 2.7-2.2 2.7-.6 0-1.1-.3-1.3-.8" strokeLinecap="round" />
                    </svg>
                    <span>Pinterest Link or Username (Optional)</span>
                  </label>
                  <input
                    id="social-pinterest"
                    type="text"
                    value={socialDraft.pinterest}
                    onChange={(e) => setSocialDraft((prev) => ({ ...prev, pinterest: e.target.value }))}
                    placeholder="https://pinterest.com/yourid"
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                  />
                </div>

                <div className="pt-2 flex flex-wrap items-center gap-3">
                  <button
                    type="submit"
                    disabled={isSavingSocial}
                    className="px-7 py-3.5 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] transition-colors cursor-pointer disabled:opacity-60"
                  >
                    {isSavingSocial ? 'Saving...' : 'Save Social Media Links'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      void resetSocialLinks();
                      setSocialSavedBanner(false);
                    }}
                    className="px-5 py-3.5 rounded-xl border border-[#EDE5DB] text-xs sm:text-sm font-semibold text-[#171A18] hover:border-[#7A0B24] cursor-pointer"
                  >
                    Reset to Defaults
                  </button>
                </div>
              </form>

              {/* Live Link Preview */}
              <aside className="lg:col-span-5 bg-white border border-[#EDE5DB] rounded-2xl p-6 space-y-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.12em] text-[#961734] mb-1">
                    Live Storefront Preview
                  </p>
                  <h3 className="font-editorial text-2xl font-semibold text-[#171A18]">
                    Your Social Buttons
                  </h3>
                </div>

                <div className="space-y-3">
                  {(
                    [
                      { key: 'facebook', label: 'Facebook' },
                      { key: 'youtube', label: 'YouTube' },
                      { key: 'tiktok', label: 'TikTok' },
                      { key: 'instagram', label: 'Instagram' },
                      { key: 'pinterest', label: 'Pinterest' },
                    ] as const
                  ).map(({ key, label }) => {
                    const resolved = normalizeSocialUrl(key, socialDraft[key]);
                    return (
                      <div
                        key={key}
                        className="p-3.5 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/70 flex items-center justify-between gap-3"
                      >
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-[#171A18]">{label}</p>
                          <p className="text-xs text-[#77736D] truncate">
                            {resolved || 'Hidden (blank)'}
                          </p>
                        </div>
                        {resolved ? (
                          <a
                            href={resolved}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#7A0B24] text-white text-xs font-semibold hover:bg-[#961734] shrink-0"
                          >
                            <span>Open</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        ) : (
                          <span className="text-[11px] text-[#77736D] shrink-0">Off</span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </aside>
            </div>
          </div>
        ) : (
          <>

        {savedNotice && (
          <div className="p-5 rounded-2xl bg-white border border-[#7A0B24] shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-[#7A0B24] shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-[#171A18]">
                  &ldquo;{savedNotice.product.name}&rdquo;{' '}
                  {savedNotice.mode === 'updated'
                    ? 'has been updated!'
                    : 'has been added to your store!'}
                </p>
                <p className="text-xs text-[#77736D] mt-0.5">
                  Published live to the storefront across Shop, Categories, and Search for all public visitors.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <Link
                to={`/product/${savedNotice.product.slug}`}
                className="px-4 py-2 rounded-xl bg-[#7A0B24] text-white text-xs font-semibold hover:bg-[#961734]"
              >
                View Product Page
              </Link>
              <Link
                to="/shop"
                className="px-4 py-2 rounded-xl border border-[#EDE5DB] text-xs font-semibold text-[#171A18] hover:border-[#7A0B24]"
              >
                Browse Shop
              </Link>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Form: Picture Upload + Product Details */}
          <form onSubmit={handleSubmit} noValidate className="lg:col-span-8 space-y-6">
            {/* 1. Product Picture Upload */}
            <div className="bg-white border border-[#EDE5DB] rounded-2xl p-6 sm:p-8 space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-editorial text-2xl font-semibold text-[#171A18]">
                    1. Product Pictures *
                  </h2>
                  <p className="text-xs text-[#77736D] mt-0.5">
                    Upload up to 6 photos (JPG, PNG, WebP). The first image is used as the primary thumbnail.
                  </p>
                </div>
                <span className="text-xs font-semibold text-[#7A0B24] tabular-nums">
                  {images.length} / 6
                </span>
              </div>

              {/* Dropzone */}
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragging(true);
                }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    fileInputRef.current?.click();
                  }
                }}
                className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-colors ${
                  isDragging
                    ? 'border-[#7A0B24] bg-[#F8F0E6]'
                    : 'border-[#EDE5DB] bg-[#FFF9F1]/70 hover:border-[#7A0B24]/60'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleFileChange}
                  className="hidden"
                />
                <div className="w-12 h-12 rounded-2xl bg-[#F1E5D8] text-[#7A0B24] flex items-center justify-center mx-auto mb-3">
                  <Upload className="w-5 h-5" />
                </div>
                <p className="text-sm font-semibold text-[#171A18]">
                  Click to upload product pictures or drag &amp; drop
                </p>
                <p className="text-xs text-[#77736D] mt-1">
                  Automatically optimized for fast storefront loading
                </p>
              </div>

              {/* Optional Image URL Input */}
              <div className="flex flex-col sm:flex-row gap-2.5">
                <input
                  type="url"
                  value={imageUrlInput}
                  onChange={(e) => setImageUrlInput(e.target.value)}
                  placeholder="Or paste an image URL (https://... or /assets/...)"
                  className="flex-1 px-4 py-2.5 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-xs sm:text-sm focus:outline-none focus:border-[#7A0B24]"
                />
                <button
                  type="button"
                  onClick={handleAddImageUrl}
                  className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl border border-[#7A0B24] text-[#7A0B24] text-xs font-semibold hover:bg-[#F8F0E6] cursor-pointer whitespace-nowrap"
                >
                  <ImagePlus className="w-4 h-4" />
                  <span>Add URL</span>
                </button>
              </div>

              {/* Uploaded Thumbnails */}
              {images.length > 0 && (
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-3 pt-2">
                  {images.map((imgSrc, idx) => (
                    <div
                      key={idx}
                      className={`relative aspect-[4/3] rounded-xl overflow-hidden border-2 bg-[#F8F0E6] group ${
                        idx === 0 ? 'border-[#7A0B24]' : 'border-[#EDE5DB]'
                      }`}
                    >
                      <SafeImage
                        src={imgSrc}
                        alt={`Uploaded product picture ${idx + 1}`}
                        className="w-full h-full object-cover"
                      />
                      {idx === 0 && (
                        <span className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-[#7A0B24] text-white text-[9px] font-semibold">
                          Primary
                        </span>
                      )}
                      {idx !== 0 && (
                        <button
                          type="button"
                          onClick={() => {
                            const next = [...images];
                            const [picked] = next.splice(idx, 1);
                            setImages([picked, ...next]);
                          }}
                          className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-black/70 text-white text-[9px] font-medium opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                        >
                          Set Main
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => setImages((prev) => prev.filter((_, i) => i !== idx))}
                        aria-label="Remove image"
                        className="absolute top-1 right-1 w-6 h-6 rounded-full bg-black/70 text-white flex items-center justify-center hover:bg-black cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 2. Product Details */}
            <div className="bg-white border border-[#EDE5DB] rounded-2xl p-6 sm:p-8 space-y-5">
              <h2 className="font-editorial text-2xl font-semibold text-[#171A18]">
                2. Product Details
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label htmlFor="prod-name" className="block text-xs font-semibold text-[#171A18] mb-1.5">
                    Product Name *
                  </label>
                  <input
                    id="prod-name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Royal Crimson Velvet Shawl"
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                  />
                </div>

                <div>
                  <label htmlFor="prod-category" className="block text-xs font-semibold text-[#171A18] mb-1.5">
                    Category *
                  </label>
                  <select
                    id="prod-category"
                    value={categorySlug}
                    onChange={(e) => setCategorySlug(e.target.value as CategorySlug)}
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat.id} value={cat.slug}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="prod-sub" className="block text-xs font-semibold text-[#171A18] mb-1.5">
                    Collection / Sub-label
                  </label>
                  <input
                    id="prod-sub"
                    type="text"
                    value={subCategory}
                    onChange={(e) => setSubCategory(e.target.value)}
                    placeholder="e.g. Royal Edit, Footwear, Bags"
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                  />
                </div>

                <div>
                  <label htmlFor="prod-price" className="block text-xs font-semibold text-[#171A18] mb-1.5">
                    Sale Price (PKR) *
                  </label>
                  <input
                    id="prod-price"
                    type="number"
                    min={1}
                    step="1"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    placeholder="4500"
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm tabular-nums focus:outline-none focus:border-[#7A0B24]"
                  />
                </div>

                <div>
                  <label htmlFor="prod-orig-price" className="block text-xs font-semibold text-[#171A18] mb-1.5">
                    Original Price (PKR, Optional)
                  </label>
                  <input
                    id="prod-orig-price"
                    type="number"
                    min={0}
                    step="1"
                    value={originalPrice}
                    onChange={(e) => setOriginalPrice(e.target.value)}
                    placeholder="6000"
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm tabular-nums focus:outline-none focus:border-[#7A0B24]"
                  />
                </div>

                <div>
                  <label htmlFor="prod-stock" className="block text-xs font-semibold text-[#171A18] mb-1.5">
                    Available Stock Units
                  </label>
                  <input
                    id="prod-stock"
                    type="number"
                    min={1}
                    value={stock}
                    onChange={(e) => setStock(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm tabular-nums focus:outline-none focus:border-[#7A0B24]"
                  />
                </div>

                <div className="flex items-end gap-5 pb-2">
                  <label className="inline-flex items-center gap-2 text-xs font-medium text-[#171A18] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isNewArrival}
                      onChange={(e) => setIsNewArrival(e.target.checked)}
                      className="accent-[#7A0B24]"
                    />
                    <span>New Arrival</span>
                  </label>
                  <label className="inline-flex items-center gap-2 text-xs font-medium text-[#171A18] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isBestSeller}
                      onChange={(e) => setIsBestSeller(e.target.checked)}
                      className="accent-[#7A0B24]"
                    />
                    <span>Best Seller</span>
                  </label>
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="prod-short" className="block text-xs font-semibold text-[#171A18] mb-1.5">
                    Short Summary (1 line)
                  </label>
                  <input
                    id="prod-short"
                    type="text"
                    value={shortDescription}
                    onChange={(e) => setShortDescription(e.target.value)}
                    placeholder="Hand-loomed wool and silk shawl in deep royal crimson."
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="prod-desc" className="block text-xs font-semibold text-[#171A18] mb-1.5">
                    Full Product Description *
                  </label>
                  <textarea
                    id="prod-desc"
                    rows={4}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Describe craftsmanship, fit, texture, dimensions, and styling notes..."
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                  />
                </div>
              </div>

              {/* Sizes */}
              <div className="pt-2 border-t border-[#F1E5D8] space-y-2.5">
                <p className="text-xs font-semibold uppercase tracking-[0.08em] text-[#171A18]">
                  Available Sizes
                </p>
                <div className="flex flex-wrap gap-2">
                  {Array.from(new Set([...PRESET_SIZES, ...selectedSizes])).map((sz) => {
                    const active = selectedSizes.includes(sz);
                    return (
                      <button
                        key={sz}
                        type="button"
                        onClick={() => toggleSize(sz)}
                        className={`px-3 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer transition-colors ${
                          active
                            ? 'bg-[#7A0B24] border-[#7A0B24] text-white'
                            : 'bg-[#FFF9F1] border-[#EDE5DB] text-[#171A18] hover:border-[#7A0B24]'
                        }`}
                      >
                        {sz}
                      </button>
                    );
                  })}
                </div>
                <div className="flex gap-2 max-w-xs pt-1">
                  <input
                    type="text"
                    value={customSizeInput}
                    onChange={(e) => setCustomSizeInput(e.target.value)}
                    placeholder="Add custom size (e.g. EU 42)"
                    className="flex-1 px-3 py-2 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-xs focus:outline-none focus:border-[#7A0B24]"
                  />
                  <button
                    type="button"
                    onClick={handleAddCustomSize}
                    className="px-3 py-2 rounded-xl border border-[#EDE5DB] text-xs font-semibold text-[#171A18] hover:border-[#7A0B24] cursor-pointer"
                  >
                    Add
                  </button>
                </div>
              </div>

              {/* Colors */}
              <div className="pt-2 border-t border-[#F1E5D8] space-y-2.5">
                <p className="text-xs font-semibold uppercase tracking-[0.08em] text-[#171A18]">
                  Available Color Swatches
                </p>
                <div className="flex flex-wrap gap-2">
                  {colors.map((clr, idx) => (
                    <span
                      key={clr.name + idx}
                      className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border border-[#EDE5DB] bg-[#FFF9F1] text-xs font-medium"
                    >
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-black/15"
                        style={{ backgroundColor: clr.hex }}
                      />
                      <span>{clr.name}</span>
                      <button
                        type="button"
                        onClick={() => setColors((prev) => prev.filter((_, i) => i !== idx))}
                        aria-label={`Remove ${clr.name}`}
                        className="text-[#77736D] hover:text-[#171A18] cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </span>
                  ))}
                </div>
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <input
                    type="color"
                    value={colorHexInput}
                    onChange={(e) => setColorHexInput(e.target.value)}
                    aria-label="Pick color swatch"
                    className="w-9 h-9 rounded-lg border border-[#EDE5DB] cursor-pointer bg-white p-0.5"
                  />
                  <input
                    type="text"
                    value={colorNameInput}
                    onChange={(e) => setColorNameInput(e.target.value)}
                    placeholder="Color name (e.g. Royal Gold)"
                    className="flex-1 min-w-[160px] max-w-xs px-3 py-2 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-xs focus:outline-none focus:border-[#7A0B24]"
                  />
                  <button
                    type="button"
                    onClick={handleAddColor}
                    className="inline-flex items-center gap-1 px-3.5 py-2 rounded-xl border border-[#EDE5DB] text-xs font-semibold text-[#171A18] hover:border-[#7A0B24] cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Color</span>
                  </button>
                </div>
              </div>

              {/* Materials & Care */}
              <div className="pt-2 border-t border-[#F1E5D8]">
                <label htmlFor="prod-care" className="block text-xs font-semibold text-[#171A18] mb-1.5">
                  Materials &amp; Care Highlights (one per line)
                </label>
                <textarea
                  id="prod-care"
                  rows={3}
                  value={careNotes}
                  onChange={(e) => setCareNotes(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-xs sm:text-sm focus:outline-none focus:border-[#7A0B24]"
                />
              </div>

              {error && (
                <p role="alert" className="text-xs text-red-700 flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{error}</span>
                </p>
              )}

              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="submit"
                  disabled={isSavingProduct}
                  className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] active:scale-[0.99] transition-all cursor-pointer disabled:opacity-60"
                >
                  {isSavingProduct
                    ? 'Publishing...'
                    : editingProduct
                      ? 'Save Product Changes'
                      : 'Publish Product to Store'}
                </button>
                {editingProduct && (
                  <button
                    type="button"
                    onClick={() => {
                      resetFormToCreate();
                      if (editIdParam) navigate('/add-product');
                    }}
                    className="w-full sm:w-auto px-6 py-3.5 rounded-xl border border-[#EDE5DB] text-sm font-semibold text-[#171A18] hover:border-[#7A0B24] cursor-pointer"
                  >
                    Cancel Edit
                  </button>
                )}
              </div>
            </div>
          </form>

          {/* Right Live Preview Card */}
          <aside className="lg:col-span-4 lg:sticky lg:top-24 space-y-4">
            <p className="text-xs font-semibold uppercase tracking-[0.1em] text-[#77736D]">
              Live Storefront Card Preview
            </p>
            <div className="bg-white border border-[#EDE5DB] rounded-2xl overflow-hidden shadow-sm">
              <div className="relative aspect-[4/3] bg-[#F8F0E6] overflow-hidden flex items-center justify-center">
                {images[0] ? (
                  <SafeImage
                    src={images[0]}
                    alt={name || 'Product preview'}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="text-center p-6 text-[#77736D]">
                    <ImagePlus className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p className="text-xs">Upload a product picture to preview</p>
                  </div>
                )}

                {computedDiscount ? (
                  <span className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-[#E07A3A] text-white text-[11px] font-semibold tabular-nums">
                    -{computedDiscount}%
                  </span>
                ) : isNewArrival ? (
                  <span className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-[#7A0B24] text-white text-[11px] font-semibold">
                    New
                  </span>
                ) : null}
              </div>

              <div className="p-5 space-y-2">
                <p className="text-[11px] uppercase tracking-[0.08em] text-[#77736D] font-medium">
                  {previewCategoryLabel}
                </p>
                <h3 className="text-base font-semibold text-[#171A18] truncate">
                  {name.trim() || 'Your Product Name'}
                </h3>
                <div className="flex items-center gap-1.5 text-xs text-[#77736D]">
                  <Star className="w-3.5 h-3.5 text-[#EAB96B] fill-[#EAB96B]" />
                  <span className="font-semibold text-[#171A18]">5.0</span>
                  <span>·</span>
                  <span>New listing</span>
                </div>
                <div className="pt-3 border-t border-[#F1E5D8] flex items-center justify-between">
                  <div className="flex items-baseline gap-2">
                    <span className="text-lg font-bold text-[#171A18] tabular-nums">
                      {parsedPrice > 0 ? formatPrice(parsedPrice) : formatPrice(0)}
                    </span>
                    {parsedOriginal > parsedPrice && parsedPrice > 0 && (
                      <span className="text-xs text-[#77736D] line-through tabular-nums">
                        {formatPrice(parsedOriginal)}
                      </span>
                    )}
                  </div>
                  <span className="px-3.5 py-2 rounded-lg bg-[#7A0B24] text-white text-xs font-semibold">
                    Add
                  </span>
                </div>
              </div>
            </div>
          </aside>
        </div>

        {/* All Store Products Management (Pre-installed + Added Later) */}
        <section className="pt-8 border-t border-[#EDE5DB] space-y-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#961734] mb-1">
                Inventory Control
              </p>
              <h2 className="font-editorial text-3xl font-semibold text-[#171A18]">
                Manage Store Products ({products.length})
              </h2>
              <p className="text-xs sm:text-sm text-[#77736D] mt-1">
                Edit details &amp; photos or delete any product—whether pre-installed or added later.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <div className="relative">
                <Search className="w-4 h-4 text-[#77736D] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="search"
                  value={manageSearch}
                  onChange={(e) => setManageSearch(e.target.value)}
                  placeholder="Filter products..."
                  aria-label="Filter managed products"
                  className="pl-9 pr-3 py-2 rounded-xl bg-white border border-[#EDE5DB] text-xs sm:text-sm focus:outline-none focus:border-[#7A0B24]"
                />
              </div>

              {(
                [
                  { id: 'all', label: `All (${products.length})` },
                  { id: 'custom', label: `Added Later (${customProducts.length})` },
                  { id: 'builtin', label: `Pre-installed (${products.length - customProducts.length})` },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setManageFilter(tab.id)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
                    manageFilter === tab.id
                      ? 'bg-[#7A0B24] border-[#7A0B24] text-white'
                      : 'bg-white border-[#EDE5DB] text-[#171A18] hover:border-[#7A0B24]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {managedProducts.length === 0 ? (
            <div className="bg-white border border-[#EDE5DB] rounded-2xl p-8 text-center text-sm text-[#77736D]">
              No products match this view.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {managedProducts.map((item) => {
                const isCustom = customIdSet.has(item.id);
                const isConfirming = confirmDeleteId === item.id;
                return (
                  <div
                    key={item.id}
                    className="bg-white border border-[#EDE5DB] rounded-2xl p-4 flex items-center gap-4"
                  >
                    <SafeImage
                      src={item.image}
                      alt={item.imageAlt}
                      className="w-20 h-20 rounded-xl object-cover bg-[#F8F0E6] shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                            isCustom
                              ? 'bg-[#7A0B24] text-white'
                              : 'bg-[#F1E5D8] text-[#171A18]'
                          }`}
                        >
                          {isCustom ? 'Added' : 'Pre-installed'}
                        </span>
                        <span className="text-[11px] text-[#77736D] truncate">
                          {item.categoryName}
                        </span>
                      </div>

                      <Link
                        to={`/product/${item.slug}`}
                        className="block text-sm font-semibold text-[#171A18] hover:text-[#7A0B24] truncate"
                      >
                        {item.name}
                      </Link>
                      <p className="text-sm font-bold text-[#7A0B24] tabular-nums mt-0.5">
                        {formatPrice(item.price)}
                      </p>

                      <div className="flex flex-wrap items-center gap-3 mt-2">
                        <Link
                          to={`/product/${item.slug}`}
                          className="text-xs font-semibold text-[#7A0B24] hover:underline"
                        >
                          View
                        </Link>
                        <button
                          type="button"
                          onClick={() => {
                            populateFormForEdit(item);
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                          }}
                          className="inline-flex items-center gap-1 text-xs font-semibold text-[#171A18] hover:text-[#7A0B24] cursor-pointer"
                        >
                          <Pencil className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                        {isConfirming ? (
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                void deleteProduct(item.id);
                                setConfirmDeleteId(null);
                              }}
                              className="px-2.5 py-1 rounded-md bg-red-700 text-white text-[11px] font-semibold hover:bg-red-800 cursor-pointer"
                            >
                              Confirm Delete
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(null)}
                              className="text-[11px] text-[#77736D] hover:text-[#171A18] cursor-pointer"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(item.id)}
                            className="inline-flex items-center gap-1 text-xs text-[#77736D] hover:text-red-700 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Delete</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Deleted Pre-installed Products Recovery */}
          {deletedDefaultProducts.length > 0 && (
            <div className="bg-white border border-[#EDE5DB] rounded-2xl p-5 sm:p-6 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-editorial text-xl font-semibold text-[#171A18]">
                    Removed Pre-installed Products ({deletedDefaultProducts.length})
                  </h3>
                  <p className="text-xs text-[#77736D]">
                    These original catalog items are hidden from the store. You can restore them anytime.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => void restoreAllDefaultProducts()}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-[#7A0B24] text-[#7A0B24] text-xs font-semibold hover:bg-[#F8F0E6] cursor-pointer whitespace-nowrap"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restore All</span>
                </button>
              </div>

              <div className="flex flex-wrap gap-2.5">
                {deletedDefaultProducts.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => void restoreDefaultProduct(item.id)}
                    className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#FFF9F1] border border-[#EDE5DB] text-xs font-medium text-[#171A18] hover:border-[#7A0B24] cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-[#7A0B24]" />
                    <span>Restore {item.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </section>
          </>
        )}
      </div>
    </div>
  );
}
