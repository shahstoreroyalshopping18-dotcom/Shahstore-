import { CheckCircle2, Package, Search } from 'lucide-react';
import { FormEvent, useState } from 'react';
import { SafeImage } from '../components/common/SafeImage';
import { formatPrice, STORE_CONFIG } from '../config/storeConfig';
import { useStore } from '../context/StoreContext';
import { Link } from '../router/RouterContext';
import { localStoreAdapter } from '../services/storeAdapter';
import { Order } from '../types/ecommerce';

export function OrderConfirmationPage() {
  const { lastOrder, orders } = useStore();
  const [lookupInput, setLookupInput] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(lastOrder);
  const [lookupError, setLookupError] = useState('');

  const handleLookup = (e: FormEvent) => {
    e.preventDefault();
    if (!lookupInput.trim()) return;
    const found = localStoreAdapter.getOrderByNumber(lookupInput);
    if (!found) {
      setLookupError(`No local demonstration order found for "${lookupInput.trim()}".`);
    } else {
      setLookupError('');
      setSelectedOrder(found);
    }
  };

  const activeOrder = selectedOrder ?? orders[0] ?? null;

  return (
    <div className="bg-[#FFF9F1] min-h-[75vh] py-12 sm:py-16">
      <div className="max-w-[1040px] mx-auto px-4 sm:px-6 lg:px-10 space-y-8">
        {/* Order Lookup Bar */}
        <div className="bg-white border border-[#EDE5DB] rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-sans text-sm font-semibold text-[#171A18]">
              Track Your Order
            </h2>
            <p className="text-xs text-[#77736D]">
              Look up orders placed in this browser session (e.g., SHAH-123456).
            </p>
          </div>
          <form onSubmit={handleLookup} className="flex gap-2 w-full sm:w-auto">
            <input
              type="text"
              value={lookupInput}
              onChange={(e) => setLookupInput(e.target.value)}
              placeholder="Order # (e.g. SHAH-123456)"
              className="flex-1 sm:w-52 px-3.5 py-2 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1] text-xs focus:outline-none focus:border-[#7A0B24]"
            />
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#7A0B24] text-white text-xs font-semibold hover:bg-[#961734] cursor-pointer"
            >
              <Search className="w-3.5 h-3.5" />
              <span>Lookup</span>
            </button>
          </form>
        </div>

        {lookupError && (
          <p className="text-xs text-red-700 px-2">{lookupError}</p>
        )}

        {!activeOrder ? (
          <div className="bg-white border border-[#EDE5DB] rounded-3xl p-12 text-center">
            <div className="w-14 h-14 rounded-full bg-[#F1E5D8] text-[#7A0B24] flex items-center justify-center mx-auto mb-4">
              <Package className="w-6 h-6" />
            </div>
            <h1 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#171A18] mb-2">
              No Orders Placed Yet
            </h1>
            <p className="text-sm text-[#77736D] max-w-md mx-auto mb-6">
              Complete checkout with items in your bag to receive your order confirmation and tracking reference.
            </p>
            <Link
              to="/shop"
              className="inline-flex px-6 py-3 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734]"
            >
              Shop Collection
            </Link>
          </div>
        ) : (
          <div className="bg-white border border-[#EDE5DB] rounded-3xl p-6 sm:p-10 space-y-8 shadow-sm">
            {/* Header Status */}
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-6 border-b border-[#F1E5D8]">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.12em] text-[#961734]">
                  <CheckCircle2 className="w-4 h-4 text-[#7A0B24]" />
                  <span>{activeOrder.status}</span>
                </div>
                <h1 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#171A18]">
                  Order #{activeOrder.orderNumber}
                </h1>
                <p className="text-xs text-[#77736D]">
                  Placed {new Date(activeOrder.createdAt).toLocaleString()} · Cash on Delivery
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-[#F8F0E6] border border-[#EDE5DB] text-xs text-[#171A18] max-w-xs">
                Thank you for shopping with {STORE_CONFIG.brandName}. Your Cash on Delivery order has been received with All Pakistan Free Delivery.
              </div>
            </div>

            {/* Customer & Shipping Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-sm">
              <div className="p-5 rounded-2xl bg-[#FFF9F1] border border-[#EDE5DB] space-y-1.5">
                <h3 className="font-sans text-xs font-semibold uppercase tracking-[0.08em] text-[#77736D] mb-2">
                  Customer Information
                </h3>
                <p className="font-semibold text-[#171A18]">{activeOrder.customer.fullName}</p>
                <p className="text-[#77736D]">Mobile: {activeOrder.customer.phone}</p>
                {activeOrder.customer.email && (
                  <p className="text-[#77736D]">{activeOrder.customer.email}</p>
                )}
              </div>

              <div className="p-5 rounded-2xl bg-[#FFF9F1] border border-[#EDE5DB] space-y-1.5">
                <h3 className="font-sans text-xs font-semibold uppercase tracking-[0.08em] text-[#77736D] mb-2">
                  Delivery Address &amp; Payment
                </h3>
                <p className="text-[#171A18]">{activeOrder.customer.address}</p>
                <p className="text-[#77736D]">
                  {activeOrder.customer.city}
                  {activeOrder.customer.postalCode ? `, ${activeOrder.customer.postalCode}` : ''}
                </p>
                <p className="text-xs text-[#961734] font-medium pt-1">
                  Est. Delivery: {STORE_CONFIG.shipping.estimatedDeliveryDays} · All Pakistan Free Delivery (COD)
                </p>
              </div>
            </div>

            {/* Purchased Items */}
            <div>
              <h3 className="font-sans text-xs font-semibold uppercase tracking-[0.08em] text-[#77736D] mb-3">
                Items in Order
              </h3>
              <div className="divide-y divide-[#F1E5D8] border border-[#EDE5DB] rounded-2xl overflow-hidden">
                {activeOrder.items.map((item) => (
                  <div key={item.key} className="p-4 flex items-center gap-4 bg-white">
                    <SafeImage
                      src={item.image}
                      alt={item.imageAlt}
                      className="w-16 h-16 rounded-xl object-cover bg-[#F8F0E6] shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-[#171A18]">{item.name}</p>
                      <p className="text-xs text-[#77736D]">
                        Qty {item.quantity}
                        {item.selectedSize ? ` · ${item.selectedSize}` : ''}
                        {item.selectedColor ? ` · ${item.selectedColor}` : ''}
                      </p>
                    </div>
                    <span className="text-sm font-bold text-[#171A18] tabular-nums">
                      {formatPrice(item.price * item.quantity)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Totals & Recent Orders Switcher */}
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 pt-4 border-t border-[#F1E5D8]">
              <div className="flex flex-wrap gap-3">
                <Link
                  to="/shop"
                  className="px-6 py-3 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734]"
                >
                  Continue Shopping
                </Link>
                {orders.length > 1 && (
                  <select
                    aria-label="Switch recent local order"
                    value={activeOrder.orderNumber}
                    onChange={(e) => {
                      const match = orders.find((o) => o.orderNumber === e.target.value);
                      if (match) setSelectedOrder(match);
                    }}
                    className="px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1] text-xs font-medium cursor-pointer"
                  >
                    {orders.map((ord) => (
                      <option key={ord.id} value={ord.orderNumber}>
                        #{ord.orderNumber} ({formatPrice(ord.total)})
                      </option>
                    ))}
                  </select>
                )}
              </div>

              <div className="w-full sm:w-64 space-y-2 text-sm">
                <div className="flex justify-between text-[#77736D]">
                  <span>Subtotal</span>
                  <span className="tabular-nums">{formatPrice(activeOrder.subtotal)}</span>
                </div>
                <div className="flex justify-between text-[#77736D]">
                  <span>All Pakistan Delivery</span>
                  <span className="font-semibold text-[#7A0B24] tabular-nums">
                    {activeOrder.shippingCost === 0
                      ? 'Free'
                      : formatPrice(activeOrder.shippingCost)}
                  </span>
                </div>
                <div className="flex justify-between text-base font-bold text-[#171A18] pt-2 border-t border-[#EDE5DB]">
                  <span>Total</span>
                  <span className="tabular-nums">{formatPrice(activeOrder.total)}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
