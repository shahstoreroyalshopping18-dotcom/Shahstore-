import { STORE_CONFIG } from '../config/storeConfig';

type PolicyType = 'privacy' | 'terms' | 'shipping';

interface PolicyPageProps {
  type: PolicyType;
}

export function PolicyPage({ type }: PolicyPageProps) {
  const content: Record<
    PolicyType,
    { eyebrow: string; title: string; updated: string; sections: { heading: string; body: string }[] }
  > = {
    privacy: {
      eyebrow: 'Legal & Privacy',
      title: 'Privacy & Cookie Policy',
      updated: STORE_CONFIG.policies.privacyUpdated,
      sections: [
        {
          heading: '1. Local Storage & Browser Preferences',
          body: `${STORE_CONFIG.brandName} uses your browser's localStorage solely to preserve your shopping bag, wishlist selections, and demonstration checkout records across page refreshes. No tracking pixels or unauthorized third-party ad brokers are loaded.`,
        },
        {
          heading: '2. Customer Contact Information',
          body: 'When connected to a production backend (Firebase or Supabase), checkout details such as name, shipping address, email, and phone number are used exclusively for order fulfillment, courier updates, and client care.',
        },
        {
          heading: '3. Data Inquiries',
          body: `To request data access or deletion once a live store backend is active, contact ${STORE_CONFIG.contact.email}.`,
        },
      ],
    },
    terms: {
      eyebrow: 'Legal Agreement',
      title: 'Terms & Conditions',
      updated: STORE_CONFIG.policies.termsUpdated,
      sections: [
        {
          heading: '1. Storefront & Pricing',
          body: `All product prices on ${STORE_CONFIG.brandName} are displayed in ${STORE_CONFIG.currency.code} and are subject to availability. Promotional seasonal markdowns apply while curated inventory lasts.`,
        },
        {
          heading: '2. Cash on Delivery Payment',
          body: 'All orders placed through Shah Store Royal Shopping are settled exclusively via Cash on Delivery (COD) at the time of courier delivery.',
        },
        {
          heading: '3. Intellectual Property',
          body: `All brand marks, product photography, editorial copy, and layout designs are owned by ${STORE_CONFIG.legalEntity}.`,
        },
      ],
    },
    shipping: {
      eyebrow: 'Delivery & Care',
      title: 'Shipping & Returns',
      updated: STORE_CONFIG.policies.termsUpdated,
      sections: [
        {
          heading: '1. All Pakistan Free Delivery',
          body: `Every order placed with ${STORE_CONFIG.brandName} includes completely free delivery across all cities and regions of Pakistan (${STORE_CONFIG.shipping.estimatedDeliveryDays}), with no minimum order amount required.`,
        },
        {
          heading: '2. 30-Day Returns & Exchanges',
          body: `We offer hassle-free returns and size exchanges within ${STORE_CONFIG.policies.returnWindowDays} days of delivery. Items must be unworn, unwashed, and accompanied by original tags and dust bags.`,
        },
        {
          heading: '3. 12-Month Craftsmanship Guarantee',
          body: `Hardware, stitching, and structural defects are covered under our ${STORE_CONFIG.policies.warrantyMonths}-month studio craftsmanship guarantee.`,
        },
      ],
    },
  };

  const doc = content[type];

  return (
    <div className="bg-[#FFF9F1] py-12 sm:py-16">
      <div className="max-w-[820px] mx-auto px-4 sm:px-6 space-y-8">
        <div className="pb-6 border-b border-[#EDE5DB]">
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#961734] mb-1.5">
            {doc.eyebrow}
          </p>
          <h1 className="font-editorial text-4xl sm:text-5xl font-semibold text-[#171A18]">
            {doc.title}
          </h1>
          <p className="text-xs text-[#77736D] mt-2">Last updated: {doc.updated}</p>
        </div>

        <div className="bg-white border border-[#EDE5DB] rounded-3xl p-6 sm:p-10 space-y-6">
          {doc.sections.map((sec) => (
            <section key={sec.heading} className="space-y-2">
              <h2 className="font-editorial text-2xl font-semibold text-[#171A18]">
                {sec.heading}
              </h2>
              <p className="text-sm sm:text-base text-[#77736D] leading-relaxed">
                {sec.body}
              </p>
            </section>
          ))}
        </div>
      </div>
    </div>
  );
}
