import { BestSellersSection } from '../components/home/BestSellersSection';
import { CategoryShowcase } from '../components/home/CategoryShowcase';
import { HeroSection } from '../components/home/HeroSection';
import { NewsletterSection } from '../components/home/NewsletterSection';
import { PromotionalBanners } from '../components/home/PromotionalBanners';
import { TestimonialsSection } from '../components/home/TestimonialsSection';
import { TrustStrip } from '../components/home/TrustStrip';

export function HomePage() {
  return (
    <div>
      <HeroSection />
      <TrustStrip />
      <CategoryShowcase />
      <BestSellersSection />
      <PromotionalBanners />
      <TestimonialsSection />
      <NewsletterSection />
    </div>
  );
}
