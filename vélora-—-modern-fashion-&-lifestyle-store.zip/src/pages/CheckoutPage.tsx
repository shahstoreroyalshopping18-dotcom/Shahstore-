import { AlertCircle, Banknote, ShieldCheck } from 'lucide-react';
import { FormEvent, useState } from 'react';
import { SafeImage } from '../components/common/SafeImage';
import { formatPrice, STORE_CONFIG } from '../config/storeConfig';
import { useStore } from '../context/StoreContext';
import { Link, useRouter } from '../router/RouterContext';
import { CustomerInfo } from '../types/ecommerce';

export function CheckoutPage() {
  const { cart, subtotal, shippingCost, total, placeDemoOrder } = useStore();
  const { navigate } = useRouter();

  const [form, setForm] = useState<CustomerInfo>({
    fullName: '',
    phone: '',
    city: '',
    address: '',
  });

  const [errors, setErrors] = useState<Partial<Record<keyof CustomerInfo, string>>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');

  if (cart.length === 0) {
    return (
      <div className="bg-[#FFF9F1] py-20 px-4 text-center">
        <div className="max-w-lg mx-auto bg-white border border-[#EDE5DB] rounded-3xl p-10">
          <h1 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#171A18] mb-2">
            No items in your bag
          </h1>
          <p className="text-sm text-[#77736D] mb-6">
            Add products to your shopping bag before proceeding to checkout.
          </p>
          <Link
            to="/shop"
            className="inline-flex px-6 py-3 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734]"
          >
            Browse Collection
          </Link>
        </div>
      </div>
    );
  }

  const validate = (): boolean => {
    const nextErrors: Partial<Record<keyof CustomerInfo, string>> = {};
    if (!form.fullName.trim()) nextErrors.fullName = 'Full name is required.';
    if (!form.phone.trim() || form.phone.trim().length < 7)
      nextErrors.phone = 'Enter a valid mobile number.';
    if (!form.city.trim()) nextErrors.city = 'City is required.';
    if (!form.address.trim()) nextErrors.address = 'Complete delivery address is required.';
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!validate() || isSubmitting) return;
    setSubmitError('');
    setIsSubmitting(true);
    try {
      await placeDemoOrder(form, 'cod');
      navigate('/order-confirmation');
    } catch {
      setSubmitError('Unable to record your order right now. Please check your connection and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const updateField = (field: keyof CustomerInfo, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  return (
    <div className="bg-[#FFF9F1] py-10 sm:py-14">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10">
        <div className="pb-8 border-b border-[#EDE5DB] mb-8">
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#961734] mb-1.5">
            Protected Checkout
          </p>
          <h1 className="font-editorial text-4xl sm:text-5xl font-semibold text-[#171A18]">
            Shipping &amp; Payment
          </h1>
        </div>

        <form onSubmit={handleSubmit} noValidate className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Form */}
          <div className="lg:col-span-7 space-y-6">
            {/* Customer & Delivery Details */}
            <div className="bg-white border border-[#EDE5DB] rounded-2xl p-6 sm:p-8 space-y-5">
              <h2 className="font-editorial text-2xl font-semibold text-[#171A18]">
                Contact &amp; Delivery Address
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label htmlFor="checkout-name" className="block text-xs font-semibold text-[#171A18] mb-1.5">
                    Full Name *
                  </label>
                  <input
                    id="checkout-name"
                    type="text"
                    value={form.fullName}
                    onChange={(e) => updateField('fullName', e.target.value)}
                    placeholder="Enter your full name"
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                  />
                  {errors.fullName && (
                    <p className="mt-1 text-xs text-red-700 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      {errors.fullName}
                    </p>
                  )}
                </div>

                <div>
                  <label htmlFor="checkout-phone" className="block text-xs font-semibold text-[#171A18] mb-1.5">
                    Mobile Number *
                  </label>
                  <input
                    id="checkout-phone"
                    type="tel"
                    value={form.phone}
                    onChange={(e) => updateField('phone', e.target.value)}
                    placeholder="e.g. 0300 1234567"
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                  />
                  {errors.phone && (
                    <p className="mt-1 text-xs text-red-700 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      {errors.phone}
                    </p>
                  )}
                </div>

                <div>
                  <label htmlFor="checkout-city" className="block text-xs font-semibold text-[#171A18] mb-1.5">
                    City *
                  </label>
                  <input
                    id="checkout-city"
                    type="text"
                    value={form.city}
                    onChange={(e) => updateField('city', e.target.value)}
                    placeholder="Enter your city"
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                  />
                  {errors.city && (
                    <p className="mt-1 text-xs text-red-700 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      {errors.city}
                    </p>
                  )}
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="checkout-address" className="block text-xs font-semibold text-[#171A18] mb-1.5">
                    Complete Delivery Address *
                  </label>
                  <textarea
                    id="checkout-address"
                    rows={3}
                    value={form.address}
                    onChange={(e) => updateField('address', e.target.value)}
                    placeholder="House / flat number, street, sector or area, and nearby landmark"
                    className="w-full px-4 py-3 rounded-xl border border-[#EDE5DB] bg-[#FFF9F1]/60 text-sm focus:outline-none focus:border-[#7A0B24]"
                  />
                  {errors.address && (
                    <p className="mt-1 text-xs text-red-700 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      {errors.address}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Payment Selection: Cash on Delivery Only */}
            <div className="bg-white border border-[#EDE5DB] rounded-2xl p-6 sm:p-8 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-editorial text-2xl font-semibold text-[#171A18]">
                  Payment Method
                </h2>
                <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#7A0B24]">
                  <Banknote className="w-4 h-4" />
                  <span>COD Only</span>
                </span>
              </div>

              <div className="space-y-3">
                {STORE_CONFIG.supportedPaymentMethods.map((method) => (
                  <div
                    key={method.id}
                    className="flex items-start gap-3.5 p-4 rounded-xl border border-[#7A0B24] bg-[#F8F0E6]/70"
                  >
                    <input
                      type="radio"
                      name="paymentMethod"
                      value={method.id}
                      checked
                      readOnly
                      className="mt-1 accent-[#7A0B24]"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <Banknote className="w-4 h-4 text-[#7A0B24]" />
                        <span className="text-sm font-semibold text-[#171A18]">
                          {method.label}
                        </span>
                      </div>
                      <p className="text-xs text-[#77736D] mt-1 leading-relaxed">
                        {method.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Order Summary */}
          <aside className="lg:col-span-5 bg-white border border-[#EDE5DB] rounded-2xl p-6 sm:p-8 space-y-5 lg:sticky lg:top-24">
            <h2 className="font-editorial text-2xl font-semibold text-[#171A18]">
              Order Summary ({cart.reduce((a, b) => a + b.quantity, 0)})
            </h2>

            <div className="divide-y divide-[#F1E5D8] max-h-80 overflow-y-auto pr-1">
              {cart.map((item) => (
                <div key={item.key} className="py-3 flex items-center gap-3.5">
                  <SafeImage
                    src={item.image}
                    alt={item.imageAlt}
                    className="w-14 h-14 rounded-lg object-cover bg-[#F8F0E6] shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-[#171A18] truncate">
                      {item.name}
                    </p>
                    <p className="text-xs text-[#77736D]">
                      Qty {item.quantity}
                      {item.selectedSize ? ` · ${item.selectedSize}` : ''}
                      {item.selectedColor ? ` · ${item.selectedColor}` : ''}
                    </p>
                  </div>
                  <span className="text-sm font-semibold text-[#171A18] tabular-nums">
                    {formatPrice(item.price * item.quantity)}
                  </span>
                </div>
              ))}
            </div>

            <div className="pt-4 border-t border-[#EDE5DB] space-y-2.5 text-sm">
              <div className="flex justify-between text-[#77736D]">
                <span>Subtotal</span>
                <span className="font-medium text-[#171A18] tabular-nums">
                  {formatPrice(subtotal)}
                </span>
              </div>
              <div className="flex justify-between text-[#77736D]">
                <span>All Pakistan Delivery ({STORE_CONFIG.shipping.estimatedDeliveryDays})</span>
                <span className="font-semibold text-[#7A0B24] tabular-nums">
                  {shippingCost === 0 ? 'Free' : formatPrice(shippingCost)}
                </span>
              </div>
              <div className="flex justify-between text-lg font-bold text-[#171A18] pt-3 border-t border-[#EDE5DB]">
                <span>Total Amount</span>
                <span className="tabular-nums">{formatPrice(total)}</span>
              </div>
            </div>

            {submitError && (
              <p role="alert" className="text-xs text-red-700 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{submitError}</span>
              </p>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 px-6 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] active:scale-[0.99] transition-all cursor-pointer disabled:opacity-60"
            >
              {isSubmitting ? 'Placing Order...' : 'Place Cash on Delivery Order'}
            </button>

            <div className="flex items-center justify-center gap-2 text-xs text-[#77736D]">
              <ShieldCheck className="w-4 h-4 text-[#7A0B24]" />
              <span>Pay cash directly upon delivery across Pakistan</span>
            </div>
          </aside>
        </form>
      </div>
    </div>
  );
}
