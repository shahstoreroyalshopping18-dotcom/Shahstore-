import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { STORE_CONFIG } from '../config/storeConfig';

interface RouterContextValue {
  pathname: string;
  search: string;
  searchParams: URLSearchParams;
  navigate: (to: string) => void;
}

const RouterContext = createContext<RouterContextValue | undefined>(undefined);

const PAGE_META: Record<string, { title: string; description: string }> = {
  '/': {
    title: `${STORE_CONFIG.brandName} — Modern Fashion, Accessories & Lifestyle`,
    description:
      'Explore thoughtfully selected fashion, accessories, footwear, beauty, and home living essentials designed for modern living.',
  },
  '/shop': {
    title: `Shop Collection — ${STORE_CONFIG.brandName}`,
    description:
      'Browse the complete Shah Store Royal Shopping catalog with category, price, and seasonal sale filters.',
  },
  '/add-product': {
    title: `Owner Studio — ${STORE_CONFIG.brandName}`,
    description: `Private store management portal for ${STORE_CONFIG.brandName}.`,
  },
  '/owner': {
    title: `Owner Studio — ${STORE_CONFIG.brandName}`,
    description: `Private store management portal for ${STORE_CONFIG.brandName}.`,
  },
  '/admin': {
    title: `Owner Studio — ${STORE_CONFIG.brandName}`,
    description: `Private store management portal for ${STORE_CONFIG.brandName}.`,
  },
  '/categories': {
    title: `Categories — ${STORE_CONFIG.brandName}`,
    description:
      'Shop across Women, Men, Accessories, Footwear, Beauty, and Home & Living collections.',
  },
  '/wishlist': {
    title: `Saved Wishlist — ${STORE_CONFIG.brandName}`,
    description: 'View and manage your saved Shah Store Royal Shopping favorites.',
  },
  '/cart': {
    title: `Shopping Bag — ${STORE_CONFIG.brandName}`,
    description: 'Review your selected pieces and proceed to checkout.',
  },
  '/checkout': {
    title: `Checkout — ${STORE_CONFIG.brandName}`,
    description: 'Complete shipping details and select your payment method.',
  },
  '/order-confirmation': {
    title: `Order Record — ${STORE_CONFIG.brandName}`,
    description: 'View your demonstration order summary and tracking reference.',
  },
  '/about': {
    title: `About Us — ${STORE_CONFIG.brandName}`,
    description: 'Discover the design philosophy and material standards behind Shah Store Royal Shopping.',
  },
  '/contact': {
    title: `Contact Us — ${STORE_CONFIG.brandName}`,
    description: 'Reach our concierge team for sizing, styling, or order assistance.',
  },
  '/faq': {
    title: `FAQ & Order Lookup — ${STORE_CONFIG.brandName}`,
    description: 'Answers on shipping, returns, sizing, and order status.',
  },
  '/blog': {
    title: `Journal & Style Edit — ${STORE_CONFIG.brandName}`,
    description: 'Editorial essays on capsule wardrobes, leather care, and tactile living.',
  },
  '/privacy-policy': {
    title: `Privacy Policy — ${STORE_CONFIG.brandName}`,
    description: 'How Shah Store Royal Shopping handles customer information and local browser preferences.',
  },
  '/terms-and-conditions': {
    title: `Terms & Conditions — ${STORE_CONFIG.brandName}`,
    description: 'Terms governing use of the Shah Store Royal Shopping storefront and services.',
  },
  '/shipping-and-returns': {
    title: `Shipping & Returns — ${STORE_CONFIG.brandName}`,
    description: 'All Pakistan free delivery, delivery windows, and 30-day returns.',
  },
};

export function RouterProvider({ children }: { children: React.ReactNode }) {
  const [locationState, setLocationState] = useState(() => ({
    pathname: window.location.pathname || '/',
    search: window.location.search || '',
  }));

  useEffect(() => {
    const onPopState = () => {
      setLocationState({
        pathname: window.location.pathname || '/',
        search: window.location.search || '',
      });
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  useEffect(() => {
    const cleanPath =
      locationState.pathname.length > 1
        ? locationState.pathname.replace(/\/+$/, '')
        : locationState.pathname;
    const meta = PAGE_META[cleanPath];
    if (meta) {
      document.title = meta.title;
      const descEl = document.querySelector('meta[name="description"]');
      if (descEl) descEl.setAttribute('content', meta.description);
    }
  }, [locationState.pathname]);

  const navigate = useCallback((to: string) => {
    const url = new URL(to, window.location.origin);
    window.history.pushState({}, '', url.pathname + url.search);
    setLocationState({
      pathname: url.pathname,
      search: url.search,
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const searchParams = new URLSearchParams(locationState.search);

  return (
    <RouterContext.Provider
      value={{
        pathname: locationState.pathname,
        search: locationState.search,
        searchParams,
        navigate,
      }}
    >
      {children}
    </RouterContext.Provider>
  );
}

export function useRouter(): RouterContextValue {
  const ctx = useContext(RouterContext);
  if (!ctx) {
    throw new Error('useRouter must be used within a RouterProvider');
  }
  return ctx;
}

interface LinkProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  to: string;
}

export function Link({ to, onClick, children, ...rest }: LinkProps) {
  const { navigate } = useRouter();

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (
      e.metaKey ||
      e.ctrlKey ||
      e.shiftKey ||
      e.altKey ||
      e.button !== 0
    ) {
      return;
    }
    e.preventDefault();
    onClick?.(e);
    navigate(to);
  };

  return (
    <a href={to} onClick={handleClick} {...rest}>
      {children}
    </a>
  );
}
