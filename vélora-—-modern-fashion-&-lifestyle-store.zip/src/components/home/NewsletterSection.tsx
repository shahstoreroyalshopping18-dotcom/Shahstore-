import { AlertCircle, CheckCircle2 } from 'lucide-react';
import { FormEvent, useState } from 'react';
import { localStoreAdapter } from '../../services/storeAdapter';

export function NewsletterSection() {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'error' | 'success'>('idle');
  const [message, setMessage] = useState('');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmed = email.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!trimmed || !emailRegex.test(trimmed)) {
      setStatus('error');
      setMessage('Please enter a valid email address.');
      return;
    }

    localStoreAdapter.saveNewsletterSubscriber({
      email: trimmed,
      subscribedAt: new Date().toISOString(),
      source: 'homepage_newsletter',
    });

    setStatus('success');
    setMessage(
      'Subscribed locally in this demonstration storefront. Connect an email provider in production to sync signups.'
    );
    setEmail('');
  };

  return (
    <section className="py-12 sm:py-16 bg-[#FFF9F1]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10">
        <div className="rounded-3xl bg-[#7A0B24] text-white p-7 sm:p-10 lg:p-12 flex flex-col lg:flex-row lg:items-center justify-between gap-8 shadow-[0_18px_46px_rgba(7,63,56,0.16)]">
          <div className="max-w-lg space-y-2">
            <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-white">
              Subscribe to Our Newsletter
            </h2>
            <p className="text-sm sm:text-base text-white/80 leading-relaxed">
              Get exclusive updates, new arrivals, and special offers.
            </p>
          </div>

          <div className="w-full max-w-lg">
            <form
              onSubmit={handleSubmit}
              noValidate
              className="flex flex-col sm:flex-row gap-3"
            >
              <label htmlFor="newsletter-email" className="sr-only">
                Email address
              </label>
              <input
                id="newsletter-email"
                type="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (status !== 'idle') setStatus('idle');
                }}
                placeholder="Enter your email address"
                className="flex-1 px-4 py-3.5 rounded-xl bg-white text-[#171A18] placeholder:text-[#77736D] text-sm focus:outline-none focus:ring-2 focus:ring-[#EAB96B]"
              />
              <button
                type="submit"
                className="px-7 py-3.5 rounded-xl bg-[#EAB96B] text-[#171A18] text-sm font-semibold hover:bg-[#f2c882] active:scale-[0.99] transition-all whitespace-nowrap shrink-0 cursor-pointer"
              >
                Subscribe
              </button>
            </form>

            {status === 'error' && (
              <p role="alert" className="mt-2.5 flex items-center gap-1.5 text-xs text-[#FCD5B5]">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{message}</span>
              </p>
            )}

            {status === 'success' && (
              <p role="status" className="mt-2.5 flex items-center gap-1.5 text-xs text-[#EAB96B]">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{message}</span>
              </p>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
