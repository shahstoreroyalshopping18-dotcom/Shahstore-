import { ArrowRight } from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { Link } from '../../router/RouterContext';
import { ProductCard } from '../common/ProductCard';

export function BestSellersSection() {
  const { products } = useStore();
  const bestSellers = products.filter((p) => p.isBestSeller).slice(0, 5);

  return (
    <section className="py-12 sm:py-16 bg-[#F8F0E6]/60 border-y border-[#EDE5DB]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8 sm:mb-10">
          <div>
            <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#171A18]">
              Our Best Sellers
            </h2>
            <p className="text-sm sm:text-base text-[#77736D] mt-1">
              Customer favorites, selected just for you.
            </p>
          </div>
          <Link
            to="/shop?sort=bestselling"
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#7A0B24] hover:text-[#961734] transition-colors whitespace-nowrap shrink-0"
          >
            <span>View All Products</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        {/* 5 cards on xl desktop */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-5">
          {bestSellers.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
}
