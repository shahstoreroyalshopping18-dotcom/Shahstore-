import { Headphones, RotateCcw, ShieldCheck, Truck } from 'lucide-react';
import { STORE_CONFIG } from '../../config/storeConfig';

const BENEFITS = [
  {
    icon: Truck,
    title: 'All Pakistan Free Delivery',
    subtitle: 'Free delivery nationwide on every order.',
  },
  {
    icon: ShieldCheck,
    title: 'Secure Payments',
    subtitle: 'Protected checkout.',
  },
  {
    icon: RotateCcw,
    title: 'Easy Returns',
    subtitle: `${STORE_CONFIG.policies.returnWindowDays}-day return policy.`,
  },
  {
    icon: Headphones,
    title: 'Customer Support',
    subtitle: 'Here to help.',
  },
];

export function TrustStrip() {
  return (
    <section aria-label="Service Benefits" className="pb-12 sm:pb-16 bg-[#FFF9F1]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10">
        <div className="bg-white border border-[#EDE5DB] rounded-2xl shadow-[0_8px_30px_rgba(23,26,24,0.04)] grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 lg:divide-x divide-[#EDE5DB]">
          {BENEFITS.map((benefit, idx) => {
            const Icon = benefit.icon;
            return (
              <div
                key={benefit.title}
                className={`flex items-center gap-3.5 p-5 sm:p-6 ${
                  idx % 2 === 1 ? 'border-l border-[#EDE5DB] lg:border-l-0' : ''
                }`}
              >
                <div className="w-11 h-11 rounded-xl bg-[#F8F0E6] text-[#7A0B24] flex items-center justify-center shrink-0">
                  <Icon className="w-5 h-5" strokeWidth={1.75} />
                </div>
                <div className="min-w-0">
                  <h2 className="font-sans text-sm font-semibold text-[#171A18]">
                    {benefit.title}
                  </h2>
                  <p className="text-xs text-[#77736D] mt-0.5">
                    {benefit.subtitle}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
