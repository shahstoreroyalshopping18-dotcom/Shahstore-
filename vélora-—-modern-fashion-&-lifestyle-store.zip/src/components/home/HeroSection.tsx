import { ArrowRight, ShoppingBag, Sparkles, Star } from 'lucide-react';
import { formatPrice } from '../../config/storeConfig';
import { useStore } from '../../context/StoreContext';
import { Link } from '../../router/RouterContext';
import { BrandLogo } from '../common/BrandLogo';
import { SafeImage } from '../common/SafeImage';

const CUSTOMER_AVATARS = [
  {
    src: '/src/assets/images/customer_portrait_one_1794832188320.jpg',
    alt: 'Shah Store Royal Shopping customer portrait one',
  },
  {
    src: '/src/assets/images/customer_portrait_two_1794832188411.jpg',
    alt: 'Shah Store Royal Shopping customer portrait two',
  },
  {
    src: '/src/assets/images/customer_portrait_three_1794832189329.jpg',
    alt: 'Shah Store Royal Shopping customer portrait three',
  },
];

export function HeroSection() {
  const { products, addToCart } = useStore();
  const phoneFeatured = products.slice(0, 2);

  return (
    <section className="relative overflow-hidden bg-[#FFF9F1] pt-8 pb-12 sm:pt-12 sm:pb-16 lg:pt-14 lg:pb-20">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          {/* Left Column: Editorial Copy & CTAs */}
          <div className="lg:col-span-6 space-y-6 lg:pr-6">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#961734]">
              The Art of Modern Living
            </p>

            <h1 className="font-editorial text-[2.65rem] sm:text-[3.4rem] lg:text-[4rem] font-semibold leading-[1.05] tracking-tight text-[#171A18]">
              Discover{' '}
              <span className="text-[#7A0B24] italic font-medium">Your Style.</span>{' '}
              Define{' '}
              <span className="text-[#7A0B24]">Your World.</span>
            </h1>

            <p className="text-base sm:text-lg text-[#77736D] leading-relaxed max-w-xl">
              Explore thoughtfully selected fashion, accessories, and lifestyle essentials designed to make every moment feel special.
            </p>

            {/* Primary & Secondary CTAs */}
            <div className="flex flex-wrap items-center gap-3.5 pt-1">
              <Link
                to="/shop"
                className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] active:scale-[0.99] transition-all duration-150 shadow-sm whitespace-nowrap"
              >
                <span>Shop Now</span>
                <ArrowRight className="w-4 h-4" />
              </Link>

              <Link
                to="/categories"
                className="inline-flex items-center justify-center px-7 py-3.5 rounded-xl border border-[#7A0B24]/30 bg-white/70 text-[#7A0B24] text-sm font-semibold hover:bg-[#F1E5D8] hover:border-[#7A0B24] transition-all duration-150 whitespace-nowrap"
              >
                Explore Collection
              </Link>
            </div>

            {/* Social Proof Row */}
            <div className="pt-4 flex flex-wrap items-center gap-4">
              <div className="flex -space-x-2.5 shrink-0">
                {CUSTOMER_AVATARS.map((avatar, idx) => (
                  <SafeImage
                    key={idx}
                    src={avatar.src}
                    alt={avatar.alt}
                    loading="eager"
                    className="w-10 h-10 rounded-full object-cover border-2 border-[#FFF9F1] shadow-sm"
                  />
                ))}
              </div>
              <div className="text-xs sm:text-sm">
                <div className="flex items-center gap-1.5 font-semibold text-[#171A18]">
                  <span>10K+ Happy Customers</span>
                  <span className="inline-flex items-center text-[#EAB96B]" aria-label="4.9 out of 5 stars">
                    <Star className="w-3.5 h-3.5 fill-[#EAB96B]" />
                    <span className="ml-0.5 text-xs text-[#171A18] tabular-nums">4.9</span>
                  </span>
                </div>
                <p className="text-xs text-[#77736D]">
                  Curated essentials across apparel, leather goods, beauty &amp; home
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Layered Fashion Editorial & Floating Smartphone Mockup */}
          <div className="lg:col-span-6 relative flex items-center justify-center lg:justify-end">
            <div className="relative w-full max-w-[540px] mx-auto lg:mx-0">
              {/* Soft Beige Circular Backdrop */}
              <div
                aria-hidden="true"
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] sm:w-[420px] sm:h-[420px] rounded-full bg-[#F1E5D8]"
              />

              {/* Subtle Decorative Sparkle Elements */}
              <svg
                aria-hidden="true"
                className="hidden sm:block absolute -top-3 left-8 w-7 h-7 text-[#EAB96B]"
                viewBox="0 0 24 24"
                fill="currentColor"
              >
                <path d="M12 1L14.5 9.5L23 12L14.5 14.5L12 23L9.5 14.5L1 12L9.5 9.5L12 1Z" />
              </svg>
              <svg
                aria-hidden="true"
                className="hidden sm:block absolute bottom-10 -left-4 w-5 h-5 text-[#7A0B24]/50"
                viewBox="0 0 24 24"
                fill="currentColor"
              >
                <path d="M12 2L13.8 10.2L22 12L13.8 13.8L12 22L10.2 13.8L2 12L10.2 10.2L12 2Z" />
              </svg>

              {/* Editorial Handwritten-Style Accent Caption */}
              <div className="hidden sm:block relative z-20 mb-2 pl-6">
                <span className="font-editorial italic text-xl text-[#7A0B24] tracking-wide">
                  Autumn / Winter Atelier Edit
                </span>
              </div>

              {/* Main Editorial Model Container */}
              <div className="relative z-10 sm:pr-20 lg:pr-24">
                <div className="relative aspect-[3/4] max-h-[540px] w-full rounded-[28px] overflow-hidden shadow-[0_24px_60px_rgba(7,63,56,0.16)] border border-[#EDE5DB] bg-[#F8F0E6]">
                  <SafeImage
                    src="/src/assets/images/hero_fashion_model_1794832180493.jpg"
                    alt="Fashion model wearing a tailored deep forest-green wool coat and cream silk blouse"
                    loading="eager"
                    className="w-full h-full object-cover object-top"
                  />

                  {/* Subtle Floating Promotional Badge */}
                  <Link
                    to="/shop?filter=sale"
                    className="absolute bottom-4 left-4 right-4 sm:right-auto bg-[#FFF9F1]/95 backdrop-blur-sm border border-[#EDE5DB] rounded-2xl px-4 py-3 shadow-lg flex items-center gap-3 hover:border-[#7A0B24] transition-colors"
                  >
                    <div className="w-9 h-9 rounded-xl bg-[#7A0B24] text-[#EAB96B] flex items-center justify-center shrink-0">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[#961734]">
                        Seasonal Edit
                      </p>
                      <p className="text-xs sm:text-sm font-semibold text-[#171A18] truncate">
                        Up to 70% Off Selected Pieces
                      </p>
                    </div>
                  </Link>
                </div>

                {/* Floating Smartphone Mockup (Desktop & Tablet) */}
                <div
                  aria-label="Miniature Shah Store Royal Shopping mobile storefront preview"
                  className="hidden sm:flex flex-col absolute right-0 bottom-6 w-[198px] lg:w-[216px] rounded-[30px] border-[6px] border-[#171A18] bg-[#FFF9F1] shadow-[0_24px_50px_rgba(23,26,24,0.28)] overflow-hidden z-20"
                >
                  {/* Phone Speaker Notch */}
                  <div className="flex justify-center pt-2 pb-1 bg-white">
                    <div className="w-14 h-1.5 rounded-full bg-[#171A18]/20" />
                  </div>

                  {/* Phone App Header */}
                  <div className="px-3 py-2 bg-white border-b border-[#EDE5DB] flex items-center justify-between">
                    <BrandLogo variant="dark" size="sm" />
                    <span className="w-6 h-6 rounded-full bg-[#7A0B24] text-white flex items-center justify-center">
                      <ShoppingBag className="w-3 h-3" />
                    </span>
                  </div>

                  {/* Mini Category Shortcuts */}
                  <div className="px-3 pt-2.5 pb-1.5 flex items-center gap-1.5 overflow-hidden">
                    <Link
                      to="/shop?category=women"
                      className="px-2 py-1 rounded-md bg-[#7A0B24] text-white text-[10px] font-medium whitespace-nowrap"
                    >
                      Women
                    </Link>
                    <Link
                      to="/shop?category=men"
                      className="px-2 py-1 rounded-md bg-[#F1E5D8] text-[#171A18] text-[10px] font-medium whitespace-nowrap"
                    >
                      Men
                    </Link>
                    <Link
                      to="/shop?category=footwear"
                      className="px-2 py-1 rounded-md bg-[#F1E5D8] text-[#171A18] text-[10px] font-medium whitespace-nowrap"
                    >
                      Shoes
                    </Link>
                  </div>

                  {/* Mini Featured Products */}
                  <div className="p-2.5 space-y-2">
                    {phoneFeatured.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center gap-2 p-1.5 rounded-xl bg-white border border-[#EDE5DB]"
                      >
                        <Link to={`/product/${item.slug}`} className="w-11 h-11 rounded-lg overflow-hidden shrink-0 bg-[#F8F0E6]">
                          <SafeImage
                            src={item.image}
                            alt={item.imageAlt}
                            className="w-full h-full object-cover"
                          />
                        </Link>
                        <div className="min-w-0 flex-1">
                          <Link
                            to={`/product/${item.slug}`}
                            className="block text-[10px] font-semibold text-[#171A18] truncate hover:text-[#7A0B24]"
                          >
                            {item.name}
                          </Link>
                          <div className="flex items-center justify-between mt-0.5">
                            <span className="text-[10px] font-bold text-[#7A0B24] tabular-nums">
                              {formatPrice(item.price)}
                            </span>
                            <button
                              type="button"
                              onClick={() => addToCart(item)}
                              className="px-1.5 py-0.5 rounded bg-[#7A0B24] text-white text-[9px] font-semibold hover:bg-[#961734] cursor-pointer"
                            >
                              Add
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
