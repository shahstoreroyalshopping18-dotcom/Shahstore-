import { ArrowRight } from 'lucide-react';
import { CATEGORIES } from '../../data/categories';
import { Link } from '../../router/RouterContext';
import { SafeImage } from '../common/SafeImage';

export function CategoryShowcase() {
  return (
    <section className="py-12 sm:py-16 bg-[#FFF9F1]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8 sm:mb-10">
          <div>
            <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#171A18]">
              Shop by Category
            </h2>
            <p className="text-sm sm:text-base text-[#77736D] mt-1">
              Find exactly what you need.
            </p>
          </div>
          <Link
            to="/categories"
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#7A0B24] hover:text-[#961734] transition-colors whitespace-nowrap shrink-0"
          >
            <span>View All Categories</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        {/* 6 Category Cards: 6 col desktop, 3 tablet, 2 mobile */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-5">
          {CATEGORIES.map((category) => (
            <Link
              key={category.id}
              to={`/shop?category=${category.slug}`}
              className="group flex flex-col bg-[#F8F0E6] border border-[#EDE5DB] rounded-2xl overflow-hidden hover:border-[#7A0B24]/40 hover:shadow-[0_12px_28px_rgba(7,63,56,0.08)] hover:-translate-y-0.5 transition-all duration-200"
            >
              <div className="aspect-[4/3] overflow-hidden bg-[#F1E5D8]">
                <SafeImage
                  src={category.image}
                  alt={category.imageAlt}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-105"
                />
              </div>
              <div className="p-3.5 sm:p-4 flex flex-col flex-1">
                <h3 className="font-sans text-sm sm:text-base font-semibold text-[#171A18] group-hover:text-[#7A0B24] transition-colors">
                  {category.name}
                </h3>
                <p className="text-xs text-[#77736D] mt-1 line-clamp-2 leading-relaxed">
                  {category.description}
                </p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
