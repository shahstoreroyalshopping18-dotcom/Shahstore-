import { ArrowRight } from 'lucide-react';
import { Link } from '../../router/RouterContext';
import { SafeImage } from '../common/SafeImage';

export function PromotionalBanners() {
  return (
    <section className="py-12 sm:py-16 bg-[#FFF9F1]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Banner 1: Seasonal Sale (Deep Forest Green) */}
          <div className="group relative rounded-3xl bg-[#7A0B24] text-white overflow-hidden p-7 sm:p-9 lg:p-10 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-[0_14px_40px_rgba(7,63,56,0.14)]">
            <div className="relative z-10 max-w-xs space-y-3 text-center sm:text-left">
              <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#EAB96B]">
                Summer Sale
              </p>
              <h2 className="font-editorial text-3xl sm:text-4xl font-semibold leading-tight text-white">
                Up To 70% Off
              </h2>
              <p className="text-sm text-white/80 leading-relaxed">
                Discover exceptional styles at exclusive prices across seasonal footwear and apparel.
              </p>
              <div className="pt-2">
                <Link
                  to="/shop?filter=sale"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#EAB96B] text-[#171A18] text-sm font-semibold hover:bg-[#f1c783] transition-colors whitespace-nowrap"
                >
                  <span>Shop Sale</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>

            <div className="relative z-10 w-full sm:w-56 md:w-64 aspect-[4/3] rounded-2xl overflow-hidden shrink-0 shadow-lg border border-white/10">
              <SafeImage
                src="/src/assets/images/banner_sale_sneaker_1794832187061.jpg"
                alt="Heritage Court Sneaker in cream suede and forest green leather"
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
            </div>
          </div>

          {/* Banner 2: New Arrivals (Warm Beige) */}
          <div className="group relative rounded-3xl bg-[#F1E5D8] text-[#171A18] border border-[#EDE5DB] overflow-hidden p-7 sm:p-9 lg:p-10 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-[0_12px_34px_rgba(23,26,24,0.05)]">
            <div className="relative z-10 max-w-xs space-y-3 text-center sm:text-left">
              <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#961734]">
                New Arrivals
              </p>
              <h2 className="font-editorial text-3xl sm:text-4xl font-semibold leading-tight text-[#171A18]">
                Step Into Style.
              </h2>
              <p className="text-sm text-[#77736D] leading-relaxed">
                Explore sculpted calfskin handbags, fine cashmere knits, and signature fragrances.
              </p>
              <div className="pt-2">
                <Link
                  to="/shop?filter=new"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] transition-colors whitespace-nowrap"
                >
                  <span>Explore New Arrivals</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>

            <div className="relative z-10 w-full sm:w-56 md:w-64 aspect-[4/3] rounded-2xl overflow-hidden shrink-0 shadow-md border border-[#EDE5DB]">
              <SafeImage
                src="/src/assets/images/banner_arrivals_handbag_1794832187509.jpg"
                alt="Emerald Clasp Crossbody Bag resting on a warm travertine pedestal"
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
