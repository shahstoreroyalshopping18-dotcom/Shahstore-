import { ChevronLeft, ChevronRight, Star } from 'lucide-react';
import { useState } from 'react';
import { DISPLAY_NAME_MAP, SAMPLE_REVIEWS } from '../../data/reviews';
import { SafeImage } from '../common/SafeImage';

export function TestimonialsSection() {
  const [activeIndex, setActiveIndex] = useState(0);

  const prev = () =>
    setActiveIndex((i) => (i - 1 + SAMPLE_REVIEWS.length) % SAMPLE_REVIEWS.length);
  const next = () => setActiveIndex((i) => (i + 1) % SAMPLE_REVIEWS.length);

  return (
    <section className="py-12 sm:py-16 bg-[#F8F0E6]/60 border-t border-[#EDE5DB]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8 sm:mb-10">
          <div>
            <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#171A18]">
              What Our Customers Say
            </h2>
            <p className="text-sm sm:text-base text-[#77736D] mt-1">
              Real stories. Real happiness. <span className="text-xs">(Editable sample customer stories)</span>
            </p>
          </div>

          {/* Carousel Controls (prominent on mobile/tablet) */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              type="button"
              onClick={prev}
              aria-label="Previous testimonial"
              className="w-10 h-10 rounded-full border border-[#EDE5DB] bg-white flex items-center justify-center text-[#171A18] hover:border-[#7A0B24] cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={next}
              aria-label="Next testimonial"
              className="w-10 h-10 rounded-full border border-[#EDE5DB] bg-white flex items-center justify-center text-[#171A18] hover:border-[#7A0B24] cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Desktop: 3 cards simultaneously */}
        <div className="hidden lg:grid lg:grid-cols-3 gap-6">
          {SAMPLE_REVIEWS.map((review) => {
            const displayName = DISPLAY_NAME_MAP[review.authorName] ?? review.authorName;
            return (
              <article
                key={review.id}
                className="bg-white border border-[#EDE5DB] rounded-2xl p-6 sm:p-7 flex flex-col justify-between shadow-[0_6px_24px_rgba(23,26,24,0.04)]"
              >
                <div>
                  <div className="flex items-center gap-1 mb-4" aria-label={`${review.rating} out of 5 stars`}>
                    {Array.from({ length: review.rating }).map((_, idx) => (
                      <Star key={idx} className="w-4 h-4 text-[#EAB96B] fill-[#EAB96B]" />
                    ))}
                  </div>
                  <p className="text-sm sm:text-base text-[#171A18] leading-relaxed">
                    &ldquo;{review.quote}&rdquo;
                  </p>
                </div>

                <div className="flex items-center gap-3.5 mt-6 pt-5 border-t border-[#F1E5D8]">
                  <SafeImage
                    src={review.authorAvatar}
                    alt={displayName}
                    loading="lazy"
                    className="w-12 h-12 rounded-full object-cover shrink-0 border border-[#EDE5DB]"
                  />
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-[#171A18] truncate">
                      {displayName}
                    </p>
                    <p className="text-xs text-[#77736D] truncate">
                      {review.purchasedItem} · {review.authorLocation}
                    </p>
                  </div>
                </div>
              </article>
            );
          })}
        </div>

        {/* Mobile / Tablet Carousel: 1 card at a time */}
        <div className="lg:hidden">
          {(() => {
            const review = SAMPLE_REVIEWS[activeIndex];
            const displayName = DISPLAY_NAME_MAP[review.authorName] ?? review.authorName;
            return (
              <article className="bg-white border border-[#EDE5DB] rounded-2xl p-6 shadow-sm">
                <div className="flex items-center gap-1 mb-4">
                  {Array.from({ length: review.rating }).map((_, idx) => (
                    <Star key={idx} className="w-4 h-4 text-[#EAB96B] fill-[#EAB96B]" />
                  ))}
                </div>
                <p className="text-base text-[#171A18] leading-relaxed">
                  &ldquo;{review.quote}&rdquo;
                </p>
                <div className="flex items-center gap-3.5 mt-6 pt-5 border-t border-[#F1E5D8]">
                  <SafeImage
                    src={review.authorAvatar}
                    alt={displayName}
                    className="w-12 h-12 rounded-full object-cover shrink-0 border border-[#EDE5DB]"
                  />
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-[#171A18] truncate">
                      {displayName}
                    </p>
                    <p className="text-xs text-[#77736D] truncate">
                      {review.purchasedItem} · {review.authorLocation}
                    </p>
                  </div>
                </div>
              </article>
            );
          })()}

          <div className="flex justify-center gap-2 mt-4">
            {SAMPLE_REVIEWS.map((r, idx) => (
              <button
                key={r.id}
                type="button"
                onClick={() => setActiveIndex(idx)}
                aria-label={`View testimonial ${idx + 1}`}
                className={`h-2 rounded-full transition-all cursor-pointer ${
                  idx === activeIndex ? 'w-6 bg-[#7A0B24]' : 'w-2 bg-[#EDE5DB]'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
