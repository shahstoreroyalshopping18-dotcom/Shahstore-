import { CheckCircle2 } from 'lucide-react';
import { useStore } from '../../context/StoreContext';

export function ToastNotification() {
  const { toastMessage } = useStore();

  if (!toastMessage) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl bg-[#7A0B24] text-white text-sm font-medium shadow-lg border border-[#961734]"
    >
      <CheckCircle2 className="w-4 h-4 text-[#EAB96B] shrink-0" />
      <span>{toastMessage}</span>
    </div>
  );
}
