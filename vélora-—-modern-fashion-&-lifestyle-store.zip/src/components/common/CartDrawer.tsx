import { ArrowRight, Minus, Plus, ShoppingBag, Trash2, X } from 'lucide-react';
import { useEffect } from 'react';
import { formatPrice, STORE_CONFIG } from '../../config/storeConfig';
import { useStore } from '../../context/StoreContext';
import { Link, useRouter } from '../../router/RouterContext';
import { SafeImage } from './SafeImage';

export function CartDrawer() {
  const {
    cart,
    cartCount,
    subtotal,
    shippingCost,
    total,
    amountToFreeShipping,
    isCartDrawerOpen,
    setIsCartDrawerOpen,
    updateQuantity,
    removeFromCart,
  } = useStore();
  const { navigate } = useRouter();

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isCartDrawerOpen) {
        setIsCartDrawerOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isCartDrawerOpen, setIsCartDrawerOpen]);

  if (!isCartDrawerOpen) return null;

  const freeShippingProgress =
    STORE_CONFIG.shipping.freeShippingThreshold <= 0
      ? 100
      : Math.min(
          100,
          Math.round((subtotal / STORE_CONFIG.shipping.freeShippingThreshold) * 100)
        );

  const goTo = (path: string) => {
    setIsCartDrawerOpen(false);
    navigate(path);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end"
      role="dialog"
      aria-modal="true"
      aria-label="Shopping Bag"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-[#171A18]/45 backdrop-blur-[2px] transition-opacity"
        onClick={() => setIsCartDrawerOpen(false)}
      />

      {/* Drawer Panel */}
      <aside className="relative z-10 w-full max-w-md bg-[#FFF9F1] h-full flex flex-col shadow-2xl border-l border-[#EDE5DB]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#EDE5DB] bg-white">
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="w-5 h-5 text-[#7A0B24]" strokeWidth={1.75} />
            <h2 className="font-editorial text-2xl font-semibold text-[#171A18]">
              Your Bag ({cartCount})
            </h2>
          </div>
          <button
            type="button"
            onClick={() => setIsCartDrawerOpen(false)}
            aria-label="Close shopping bag"
            className="w-10 h-10 rounded-full flex items-center justify-center text-[#171A18] hover:bg-[#F8F0E6] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Shipping Progress */}
        {cart.length > 0 && (
          <div className="px-6 py-3 bg-[#F8F0E6] border-b border-[#EDE5DB]">
            <p className="text-xs text-[#171A18] font-medium mb-1.5">
              {amountToFreeShipping === 0
                ? 'All Pakistan Free Delivery applied to your order.'
                : `Add ${formatPrice(amountToFreeShipping)} more for free delivery.`}
            </p>
            <div className="w-full h-1.5 bg-[#EDE5DB] rounded-full overflow-hidden">
              <div
                className="h-full bg-[#7A0B24] transition-all duration-300"
                style={{ width: `${freeShippingProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Items */}
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-4">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-12">
              <div className="w-16 h-16 rounded-full bg-[#F1E5D8] flex items-center justify-center text-[#7A0B24] mb-4">
                <ShoppingBag className="w-7 h-7" strokeWidth={1.5} />
              </div>
              <h3 className="font-editorial text-2xl font-semibold text-[#171A18] mb-1">
                Your bag is currently empty
              </h3>
              <p className="text-sm text-[#77736D] max-w-xs mb-6">
                Explore our seasonal pieces, leather goods, and home living essentials.
              </p>
              <button
                type="button"
                onClick={() => goTo('/shop')}
                className="px-6 py-3 rounded-lg bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] transition-colors cursor-pointer"
              >
                Explore Collection
              </button>
            </div>
          ) : (
            cart.map((item) => (
              <div
                key={item.key}
                className="flex gap-4 p-3.5 bg-white rounded-xl border border-[#EDE5DB]"
              >
                <Link
                  to={`/product/${item.slug}`}
                  onClick={() => setIsCartDrawerOpen(false)}
                  className="w-20 h-20 rounded-lg overflow-hidden bg-[#F8F0E6] shrink-0"
                >
                  <SafeImage
                    src={item.image}
                    alt={item.imageAlt}
                    className="w-full h-full object-cover"
                  />
                </Link>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <Link
                      to={`/product/${item.slug}`}
                      onClick={() => setIsCartDrawerOpen(false)}
                      className="text-sm font-semibold text-[#171A18] hover:text-[#7A0B24] truncate"
                    >
                      {item.name}
                    </Link>
                    <button
                      type="button"
                      onClick={() => removeFromCart(item.key)}
                      aria-label={`Remove ${item.name}`}
                      className="text-[#77736D] hover:text-[#171A18] p-1 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {(item.selectedSize || item.selectedColor) && (
                    <p className="text-xs text-[#77736D] mt-0.5">
                      {[item.selectedSize, item.selectedColor].filter(Boolean).join(' · ')}
                    </p>
                  )}

                  <div className="flex items-center justify-between mt-3">
                    <div className="inline-flex items-center border border-[#EDE5DB] rounded-lg bg-[#FFF9F1]">
                      <button
                        type="button"
                        onClick={() => updateQuantity(item.key, item.quantity - 1)}
                        aria-label={`Decrease quantity of ${item.name}`}
                        className="w-8 h-8 flex items-center justify-center text-[#171A18] hover:bg-[#F1E5D8] rounded-l-lg cursor-pointer"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-8 text-center text-xs font-semibold tabular-nums">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => updateQuantity(item.key, item.quantity + 1)}
                        aria-label={`Increase quantity of ${item.name}`}
                        className="w-8 h-8 flex items-center justify-center text-[#171A18] hover:bg-[#F1E5D8] rounded-r-lg cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <span className="text-sm font-bold text-[#171A18] tabular-nums">
                      {formatPrice(item.price * item.quantity)}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Totals */}
        {cart.length > 0 && (
          <div className="p-6 bg-white border-t border-[#EDE5DB] space-y-4">
            <div className="space-y-2 text-sm">
              <div className="flex justify-between text-[#77736D]">
                <span>Subtotal</span>
                <span className="font-medium text-[#171A18] tabular-nums">
                  {formatPrice(subtotal)}
                </span>
              </div>
              <div className="flex justify-between text-[#77736D]">
                <span>All Pakistan Delivery</span>
                <span className="font-semibold text-[#7A0B24] tabular-nums">
                  {shippingCost === 0 ? 'Free' : formatPrice(shippingCost)}
                </span>
              </div>
              <div className="flex justify-between text-base font-bold text-[#171A18] pt-2 border-t border-[#EDE5DB]">
                <span>Total</span>
                <span className="tabular-nums">{formatPrice(total)}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => goTo('/cart')}
                className="px-4 py-3 rounded-lg border border-[#7A0B24] text-[#7A0B24] text-sm font-semibold hover:bg-[#F8F0E6] transition-colors cursor-pointer"
              >
                View Bag
              </button>
              <button
                type="button"
                onClick={() => goTo('/checkout')}
                className="inline-flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] transition-colors cursor-pointer"
              >
                <span>Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </aside>
    </div>
  );
}
