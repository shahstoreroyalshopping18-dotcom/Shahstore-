import { STORE_CONFIG } from '../../config/storeConfig';

interface BrandLogoProps {
  variant?: 'dark' | 'light';
  size?: 'sm' | 'md';
  allowWrap?: boolean;
}

export function BrandLogo({ variant = 'dark', size = 'md', allowWrap = false }: BrandLogoProps) {
  const isLight = variant === 'light';
  const textColor = isLight ? 'text-white' : 'text-[#7A0B24]';

  const emblemBoxSize =
    size === 'sm' ? 'w-7 h-7 rounded-lg p-0.5' : 'w-10 h-10 rounded-xl p-0.5';

  return (
    <span className={`inline-flex items-center gap-2.5 select-none ${allowWrap ? '' : 'whitespace-nowrap shrink-0'}`}>
      <span
        className={`inline-flex items-center justify-center shrink-0 overflow-hidden bg-white border ${
          isLight ? 'border-white/25 shadow-sm' : 'border-[#EDE5DB] shadow-xs'
        } ${emblemBoxSize}`}
      >
        <img
          src={STORE_CONFIG.logoUrl}
          alt={`${STORE_CONFIG.brandName} logo`}
          className="w-full h-full object-contain"
        />
      </span>
      <span
        className={`font-editorial font-semibold tracking-[0.04em] leading-tight ${
          size === 'sm'
            ? 'text-xs sm:text-sm max-w-[130px] truncate'
            : allowWrap
              ? 'text-lg lg:text-xl whitespace-normal'
              : 'text-base sm:text-lg xl:text-xl max-w-[155px] sm:max-w-none truncate'
        } ${textColor}`}
      >
        {STORE_CONFIG.brandName}
      </span>
    </span>
  );
}
