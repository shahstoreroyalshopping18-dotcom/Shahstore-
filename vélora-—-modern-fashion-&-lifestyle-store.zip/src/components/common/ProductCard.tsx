import { Heart, Pencil, ShoppingBag, Star, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import { formatPrice } from '../../config/storeConfig';
import { useFirebase } from '../../context/FirebaseContext';
import { useStore } from '../../context/StoreContext';
import { Link, useRouter } from '../../router/RouterContext';
import { Product } from '../../types/ecommerce';
import { SafeImage } from './SafeImage';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { isAdmin } = useFirebase();
  const { addToCart, isInWishlist, toggleWishlist, deleteProduct } = useStore();
  const { navigate } = useRouter();
  const wishlisted = isInWishlist(product.id);
  const [confirmingDelete, setConfirmingDelete] = useState(false);

  useEffect(() => {
    if (!confirmingDelete) return;
    const timer = window.setTimeout(() => setConfirmingDelete(false), 3500);
    return () => window.clearTimeout(timer);
  }, [confirmingDelete]);

  return (
    <article className="group flex flex-col bg-white border border-[#EDE5DB] rounded-2xl overflow-hidden shadow-[0_4px_20px_rgba(23,26,24,0.04)] hover:shadow-[0_14px_34px_rgba(7,63,56,0.10)] hover:-translate-y-0.5 transition-all duration-200">
      {/* Upper Media Frame */}
      <div className="relative aspect-[4/3] bg-[#F8F0E6] overflow-hidden">
        <Link
          to={`/product/${product.slug}`}
          className="block w-full h-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7A0B24]"
          aria-label={`View ${product.name}`}
        >
          <SafeImage
            src={product.image}
            alt={product.imageAlt}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-105"
          />
        </Link>

        {/* Discount Badge Top-Left */}
        {product.discountPercent ? (
          <span className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-[#E07A3A] text-white text-[11px] font-semibold tracking-wide tabular-nums shadow-sm pointer-events-none">
            -{product.discountPercent}%
          </span>
        ) : product.isNewArrival ? (
          <span className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-[#7A0B24] text-white text-[11px] font-semibold tracking-wide shadow-sm pointer-events-none">
            New
          </span>
        ) : null}

        {/* Top-Right Quick Actions: Edit, Delete (Owner Only) & Wishlist */}
        <div className="absolute top-3 right-3 flex items-center gap-1.5">
          {isAdmin && (
            <>
              <button
                type="button"
                onClick={() => navigate(`/add-product?edit=${encodeURIComponent(product.id)}`)}
                aria-label={`Edit ${product.name}`}
                title="Edit product"
                className="w-9 h-9 rounded-full flex items-center justify-center border bg-white/95 border-[#EDE5DB] text-[#77736D] hover:border-[#7A0B24] hover:text-[#7A0B24] hover:scale-105 transition-all duration-200 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7A0B24]"
              >
                <Pencil className="w-3.5 h-3.5" strokeWidth={1.75} />
              </button>

              {confirmingDelete ? (
                <button
                  type="button"
                  onClick={() => deleteProduct(product.id)}
                  aria-label={`Confirm delete ${product.name}`}
                  className="h-9 px-3 rounded-full bg-red-700 text-white text-[11px] font-semibold shadow-sm hover:bg-red-800 transition-colors cursor-pointer"
                >
                  Confirm?
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setConfirmingDelete(true)}
                  aria-label={`Delete ${product.name}`}
                  title="Delete product"
                  className="w-9 h-9 rounded-full flex items-center justify-center border bg-white/95 border-[#EDE5DB] text-[#77736D] hover:border-red-600 hover:text-red-700 hover:scale-105 transition-all duration-200 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-600"
                >
                  <Trash2 className="w-4 h-4" strokeWidth={1.75} />
                </button>
              )}
            </>
          )}

          <button
            type="button"
            onClick={() => toggleWishlist(product.id, product.name)}
            aria-label={wishlisted ? `Remove ${product.name} from wishlist` : `Save ${product.name} to wishlist`}
            aria-pressed={wishlisted}
            className={`w-9 h-9 rounded-full flex items-center justify-center border transition-all duration-200 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7A0B24] ${
              wishlisted
                ? 'bg-[#7A0B24] border-[#7A0B24] text-white scale-105'
                : 'bg-white/95 border-[#EDE5DB] text-[#171A18] hover:border-[#7A0B24] hover:text-[#7A0B24] hover:scale-105'
            }`}
          >
            <Heart
              className="w-4 h-4 transition-transform duration-200"
              fill={wishlisted ? 'currentColor' : 'none'}
              strokeWidth={1.75}
            />
          </button>
        </div>
      </div>

      {/* Product Details */}
      <div className="flex flex-col flex-1 p-4 md:p-5">
        <p className="text-[11px] uppercase tracking-[0.08em] text-[#77736D] font-medium mb-1">
          {product.categoryName}
        </p>

        <Link
          to={`/product/${product.slug}`}
          className="text-base font-semibold text-[#171A18] hover:text-[#7A0B24] transition-colors line-clamp-1 mb-1.5"
        >
          {product.name}
        </Link>

        {/* Rating & Review Count */}
        <div className="flex items-center gap-1.5 text-xs text-[#77736D] mb-3">
          <Star className="w-3.5 h-3.5 text-[#EAB96B] fill-[#EAB96B]" aria-hidden="true" />
          <span className="font-semibold text-[#171A18] tabular-nums">{product.rating.toFixed(1)}</span>
          <span aria-hidden="true">·</span>
          <span className="tabular-nums">{product.reviewCount} reviews</span>
        </div>

        {/* Pricing + CTA anchored at bottom */}
        <div className="mt-auto pt-3 border-t border-[#F1E5D8] flex items-center justify-between gap-2">
          <div className="flex items-baseline gap-2">
            <span className="text-base md:text-lg font-bold text-[#171A18] tabular-nums">
              {formatPrice(product.price)}
            </span>
            {product.originalPrice && (
              <span className="text-xs text-[#77736D] line-through tabular-nums">
                {formatPrice(product.originalPrice)}
              </span>
            )}
          </div>

          <button
            type="button"
            onClick={() => addToCart(product)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#7A0B24] text-white text-xs font-semibold hover:bg-[#961734] active:scale-[0.98] transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#EAB96B]"
          >
            <ShoppingBag className="w-3.5 h-3.5" strokeWidth={1.75} />
            <span>Add</span>
          </button>
        </div>
      </div>
    </article>
  );
}
