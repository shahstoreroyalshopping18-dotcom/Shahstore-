import { ArrowRight, Search, X } from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { formatPrice } from '../../config/storeConfig';
import { useStore } from '../../context/StoreContext';
import { CATEGORIES } from '../../data/categories';
import { useRouter } from '../../router/RouterContext';
import { SafeImage } from './SafeImage';

export function SearchModal() {
  const { products, isSearchOpen, setIsSearchOpen } = useStore();
  const { navigate } = useRouter();
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isSearchOpen) {
      setTimeout(() => inputRef.current?.focus(), 40);
    } else {
      setQuery('');
    }
  }, [isSearchOpen]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isSearchOpen) {
        setIsSearchOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isSearchOpen, setIsSearchOpen]);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return products.slice(0, 4);
    return products.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.categoryName.toLowerCase().includes(q) ||
        p.shortDescription.toLowerCase().includes(q)
    );
  }, [products, query]);

  if (!isSearchOpen) return null;

  const goTo = (path: string) => {
    setIsSearchOpen(false);
    navigate(path);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4"
      role="dialog"
      aria-modal="true"
      aria-label="Search store"
    >
      <div
        className="fixed inset-0 bg-[#171A18]/50 backdrop-blur-[2px]"
        onClick={() => setIsSearchOpen(false)}
      />

      <div className="relative z-10 w-full max-w-2xl bg-[#FFF9F1] rounded-2xl border border-[#EDE5DB] shadow-2xl overflow-hidden">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            goTo(`/shop${query.trim() ? `?q=${encodeURIComponent(query.trim())}` : ''}`);
          }}
          className="flex items-center gap-3 px-5 py-4 bg-white border-b border-[#EDE5DB]"
        >
          <Search className="w-5 h-5 text-[#77736D] shrink-0" />
          <input
            ref={inputRef}
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search hoodies, sneakers, leather bags, fragrances..."
            className="flex-1 bg-transparent text-sm md:text-base text-[#171A18] placeholder:text-[#77736D] focus:outline-none"
          />
          <button
            type="button"
            onClick={() => setIsSearchOpen(false)}
            aria-label="Close search"
            className="w-9 h-9 rounded-full flex items-center justify-center text-[#77736D] hover:text-[#171A18] hover:bg-[#F8F0E6] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </form>

        <div className="p-5 max-h-[65vh] overflow-y-auto space-y-5">
          {/* Quick Categories */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.08em] text-[#77736D] mb-2.5">
              Popular Categories
            </p>
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => goTo(`/shop?category=${cat.slug}`)}
                  className="px-3.5 py-1.5 rounded-lg bg-[#F1E5D8] text-[#171A18] text-xs font-medium hover:bg-[#7A0B24] hover:text-white transition-colors cursor-pointer"
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          {/* Matching Products */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <p className="text-xs font-semibold uppercase tracking-[0.08em] text-[#77736D]">
                {query.trim() ? `Results (${results.length})` : 'Featured Selections'}
              </p>
              <button
                type="button"
                onClick={() =>
                  goTo(`/shop${query.trim() ? `?q=${encodeURIComponent(query.trim())}` : ''}`)
                }
                className="inline-flex items-center gap-1 text-xs font-semibold text-[#7A0B24] hover:underline cursor-pointer"
              >
                <span>View all in Shop</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {results.length === 0 ? (
              <p className="text-sm text-[#77736D] py-6 text-center">
                No pieces matched &ldquo;{query}&rdquo;. Try browsing our categories above.
              </p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {results.slice(0, 6).map((product) => (
                  <button
                    key={product.id}
                    type="button"
                    onClick={() => goTo(`/product/${product.slug}`)}
                    className="flex items-center gap-3 p-2.5 rounded-xl bg-white border border-[#EDE5DB] hover:border-[#7A0B24] text-left transition-colors cursor-pointer"
                  >
                    <SafeImage
                      src={product.image}
                      alt={product.imageAlt}
                      className="w-14 h-14 rounded-lg object-cover shrink-0 bg-[#F8F0E6]"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-[#171A18] truncate">
                        {product.name}
                      </p>
                      <p className="text-xs text-[#77736D] truncate">
                        {product.categoryName}
                      </p>
                      <p className="text-xs font-bold text-[#7A0B24] tabular-nums mt-0.5">
                        {formatPrice(product.price)}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
