import React from 'react';

interface ErrorBoundaryState {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      message: error?.message || 'An unexpected error occurred.',
    };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#FFF9F1] flex items-center justify-center px-4">
          <div className="max-w-md w-full bg-white border border-[#EDE5DB] rounded-3xl p-8 text-center space-y-4 shadow-sm">
            <h1 className="font-editorial text-3xl font-semibold text-[#7A0B24]">
              Something went wrong
            </h1>
            <p className="text-sm text-[#77736D] break-words">
              Please refresh the page to continue shopping.
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-6 py-3 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] cursor-pointer"
            >
              Reload Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
