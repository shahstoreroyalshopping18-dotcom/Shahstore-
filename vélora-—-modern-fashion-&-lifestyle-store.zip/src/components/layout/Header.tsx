import {
  ChevronDown,
  Heart,
  Menu,
  Search,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Tag,
  Truck,
  User,
  X,
} from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { STORE_CONFIG } from '../../config/storeConfig';
import { useFirebase } from '../../context/FirebaseContext';
import { useStore } from '../../context/StoreContext';
import { CATEGORIES } from '../../data/categories';
import { Link, useRouter } from '../../router/RouterContext';
import { BrandLogo } from '../common/BrandLogo';

const ANNOUNCEMENTS = [
  {
    icon: Truck,
    text: 'All Pakistan Free Delivery — Cash on Delivery Available',
  },
  {
    icon: Tag,
    text: 'Seasonal Sale — Up to 70% Off Selected Styles',
  },
  {
    icon: Sparkles,
    text: 'Shop New Arrivals',
    to: '/shop?filter=new',
  },
];

export function Header() {
  const { isAdmin } = useFirebase();
  const { products, cartCount, wishlistCount, setIsCartDrawerOpen, setIsSearchOpen } = useStore();
  const { pathname, navigate } = useRouter();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [categoriesOpen, setCategoriesOpen] = useState(false);
  const [mobileCategoriesOpen, setMobileCategoriesOpen] = useState(false);
  const [activeAnnouncementIdx, setActiveAnnouncementIdx] = useState(0);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setActiveAnnouncementIdx((prev) => (prev + 1) % ANNOUNCEMENTS.length);
    }, 3800);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    const onClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setCategoriesOpen(false);
      }
    };
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  useEffect(() => {
    setMobileMenuOpen(false);
    setCategoriesOpen(false);
  }, [pathname]);

  const navLinkClass = (target: string) =>
    `relative py-1 text-sm font-medium whitespace-nowrap shrink-0 transition-colors after:content-[''] after:absolute after:left-0 after:bottom-0 after:h-[1.5px] after:bg-[#7A0B24] after:transition-all after:duration-200 ${
      pathname === target
        ? 'text-[#7A0B24] font-semibold after:w-full'
        : 'text-[#171A18] hover:text-[#7A0B24] after:w-0 hover:after:w-full'
    }`;

  const currentMobileAnnouncement = ANNOUNCEMENTS[activeAnnouncementIdx];
  const MobileAnnounceIcon = currentMobileAnnouncement.icon;

  return (
    <>
      {/* Top Promotional Announcement Bar */}
      <div className="bg-[#5A071A] text-white border-b border-[#961734]/40">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10 h-9 flex items-center justify-center md:justify-between text-xs tracking-wide">
          {/* Desktop 3-column horizontal alignment */}
          <div className="hidden md:flex items-center justify-between w-full gap-6">
            <div className="flex items-center gap-2 text-white/90 whitespace-nowrap">
              <Truck className="w-3.5 h-3.5 text-[#EAB96B]" strokeWidth={1.75} />
              <span>All Pakistan Free Delivery on Every Order</span>
            </div>

            <div className="flex items-center gap-2 text-white font-medium whitespace-nowrap">
              <Tag className="w-3.5 h-3.5 text-[#EAB96B]" strokeWidth={1.75} />
              <span>Seasonal Sale: Up to 70% Off Selected Essentials</span>
            </div>

            <Link
              to="/shop?filter=sale"
              className="inline-flex items-center gap-1.5 text-[#EAB96B] hover:text-white font-semibold transition-colors whitespace-nowrap"
            >
              <span>Shop Now</span>
              <span aria-hidden="true">→</span>
            </Link>
          </div>

          {/* Mobile rotating announcement */}
          <div className="flex md:hidden items-center justify-center gap-2 text-white/95 truncate">
            <MobileAnnounceIcon className="w-3.5 h-3.5 text-[#EAB96B] shrink-0" />
            {currentMobileAnnouncement.to ? (
              <Link to={currentMobileAnnouncement.to} className="underline underline-offset-2 font-medium truncate">
                {currentMobileAnnouncement.text}
              </Link>
            ) : (
              <span className="truncate">{currentMobileAnnouncement.text}</span>
            )}
          </div>
        </div>
      </div>

      {/* Main Sticky Cream Navigation Bar */}
      <header className="sticky top-0 z-40 bg-[#FFF9F1]/95 backdrop-blur-md border-b border-[#EDE5DB]">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10 h-16 lg:h-[72px] flex items-center justify-between gap-3 lg:gap-5 xl:gap-8">
          {/* Left: Mobile Drawer Trigger + Brand */}
          <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open navigation menu"
              className="lg:hidden w-10 h-10 -ml-2 rounded-lg flex items-center justify-center text-[#171A18] hover:bg-[#F1E5D8] transition-colors cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>

            <Link
              to="/"
              aria-label={`${STORE_CONFIG.brandName} Home`}
              className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7A0B24] rounded-md"
            >
              <BrandLogo variant="dark" />
            </Link>
          </div>

          {/* Center: Desktop Links */}
          <nav
            aria-label="Main navigation"
            className="hidden lg:flex items-center gap-4 xl:gap-7"
          >
            <Link to="/" className={navLinkClass('/')}>
              Home
            </Link>
            <Link to="/shop" className={navLinkClass('/shop')}>
              Shop
            </Link>

            {/* Categories Dropdown */}
            <div
              ref={dropdownRef}
              className="relative"
              onMouseEnter={() => setCategoriesOpen(true)}
              onMouseLeave={() => setCategoriesOpen(false)}
            >
              <button
                type="button"
                onClick={() => setCategoriesOpen((prev) => !prev)}
                aria-expanded={categoriesOpen}
                aria-haspopup="true"
                className={`inline-flex items-center gap-1 py-1 text-sm font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  pathname === '/categories'
                    ? 'text-[#7A0B24] font-semibold'
                    : 'text-[#171A18] hover:text-[#7A0B24]'
                }`}
              >
                <span>Categories</span>
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform duration-200 ${
                    categoriesOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {categoriesOpen && (
                <div className="absolute left-1/2 -translate-x-1/2 top-full pt-2 w-72 z-50">
                  <div className="bg-white rounded-2xl border border-[#EDE5DB] shadow-xl p-2">
                    <div className="px-3 py-2 border-b border-[#F1E5D8] mb-1">
                      <p className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[#77736D]">
                        Collections
                      </p>
                    </div>
                    {CATEGORIES.map((cat) => {
                      const count = products.filter((p) => p.categorySlug === cat.slug).length;
                      return (
                        <Link
                          key={cat.id}
                          to={`/shop?category=${cat.slug}`}
                          className="flex items-center justify-between px-3 py-2.5 rounded-xl text-sm text-[#171A18] hover:bg-[#F8F0E6] hover:text-[#7A0B24] transition-colors"
                        >
                          <span className="font-medium">{cat.name}</span>
                          <span className="text-xs text-[#77736D] tabular-nums">
                            {count}
                          </span>
                        </Link>
                      );
                    })}
                    <div className="pt-1 mt-1 border-t border-[#F1E5D8] flex items-center justify-between">
                      <Link
                        to="/categories"
                        className="block px-3 py-2 text-xs font-semibold text-[#7A0B24] hover:underline"
                      >
                        View All Categories →
                      </Link>
                      {isAdmin && (
                        <Link
                          to="/add-product"
                          className="block px-3 py-2 text-xs font-semibold text-[#961734] hover:underline"
                        >
                          + Add Product
                        </Link>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>

            <Link to="/about" className={navLinkClass('/about')}>
              About Us
            </Link>
            <Link to="/blog" className={navLinkClass('/blog')}>
              Blog
            </Link>
            <Link to="/contact" className={navLinkClass('/contact')}>
              Contact
            </Link>
          </nav>

          {/* Right: Utility Icons */}
          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            {isAdmin && (
              <Link
                to="/owner"
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#7A0B24] text-white text-xs font-semibold hover:bg-[#961734] transition-colors mr-1"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-[#EAB96B]" />
                <span>Owner Studio</span>
              </Link>
            )}
            <button
              type="button"
              onClick={() => setIsSearchOpen(true)}
              aria-label="Search products"
              className="w-10 h-10 rounded-full flex items-center justify-center text-[#171A18] hover:bg-[#F1E5D8] hover:text-[#7A0B24] transition-colors cursor-pointer"
            >
              <Search className="w-[18px] h-[18px]" strokeWidth={1.75} />
            </button>

            <Link
              to="/wishlist"
              aria-label={`Wishlist (${wishlistCount} saved)`}
              className="relative w-10 h-10 rounded-full flex items-center justify-center text-[#171A18] hover:bg-[#F1E5D8] hover:text-[#7A0B24] transition-colors"
            >
              <Heart className="w-[18px] h-[18px]" strokeWidth={1.75} />
              {wishlistCount > 0 && (
                <span className="absolute top-1 right-1 min-w-[17px] h-[17px] px-1 rounded-full bg-[#7A0B24] text-white text-[10px] font-bold flex items-center justify-center tabular-nums">
                  {wishlistCount}
                </span>
              )}
            </Link>

            <Link
              to="/order-confirmation"
              aria-label="Orders and account"
              className="hidden sm:flex w-10 h-10 rounded-full items-center justify-center text-[#171A18] hover:bg-[#F1E5D8] hover:text-[#7A0B24] transition-colors"
            >
              <User className="w-[18px] h-[18px]" strokeWidth={1.75} />
            </Link>

            <button
              type="button"
              onClick={() => setIsCartDrawerOpen(true)}
              aria-label={`Open shopping bag (${cartCount} items)`}
              className="relative w-10 h-10 rounded-full flex items-center justify-center text-[#171A18] hover:bg-[#F1E5D8] hover:text-[#7A0B24] transition-colors cursor-pointer"
            >
              <ShoppingBag className="w-[18px] h-[18px]" strokeWidth={1.75} />
              {cartCount > 0 && (
                <span className="absolute top-1 right-1 min-w-[17px] h-[17px] px-1 rounded-full bg-[#EAB96B] text-[#171A18] text-[10px] font-bold flex items-center justify-center tabular-nums">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-50 lg:hidden flex"
          role="dialog"
          aria-modal="true"
          aria-label="Mobile Navigation"
        >
          <div
            className="fixed inset-0 bg-[#171A18]/45 backdrop-blur-[2px]"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative z-10 w-80 max-w-[85vw] bg-[#FFF9F1] h-full flex flex-col shadow-2xl border-r border-[#EDE5DB]">
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#EDE5DB] bg-white">
              <BrandLogo variant="dark" size="sm" />
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Close navigation menu"
                className="w-10 h-10 rounded-full flex items-center justify-center text-[#171A18] hover:bg-[#F8F0E6] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <nav className="flex-1 overflow-y-auto px-5 py-6 space-y-1">
              {[
                { label: 'Home', to: '/' },
                { label: 'Shop All', to: '/shop' },
              ].map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className="block px-3 py-3 rounded-xl text-base font-medium text-[#171A18] hover:bg-[#F1E5D8]"
                >
                  {link.label}
                </Link>
              ))}

              {/* Mobile Categories Accordion */}
              <div>
                <button
                  type="button"
                  onClick={() => setMobileCategoriesOpen((prev) => !prev)}
                  className="w-full flex items-center justify-between px-3 py-3 rounded-xl text-base font-medium text-[#171A18] hover:bg-[#F1E5D8] cursor-pointer"
                >
                  <span>Categories</span>
                  <ChevronDown
                    className={`w-4 h-4 transition-transform ${
                      mobileCategoriesOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {mobileCategoriesOpen && (
                  <div className="pl-4 space-y-1 pb-2">
                    {CATEGORIES.map((cat) => (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => {
                          setMobileMenuOpen(false);
                          navigate(`/shop?category=${cat.slug}`);
                        }}
                        className="w-full text-left px-3 py-2 rounded-lg text-sm text-[#77736D] hover:text-[#7A0B24] hover:bg-[#F8F0E6] cursor-pointer"
                      >
                        {cat.name}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {[
                ...(isAdmin
                  ? [
                      { label: 'Owner Studio (Products)', to: '/add-product' },
                      { label: 'Social Media Links', to: '/add-product?tab=social' },
                    ]
                  : []),
                { label: 'About Us', to: '/about' },
                { label: 'Blog', to: '/blog' },
                { label: 'Contact', to: '/contact' },
                { label: 'FAQ & Track Order', to: '/faq' },
                { label: `Wishlist (${wishlistCount})`, to: '/wishlist' },
                { label: `Shopping Bag (${cartCount})`, to: '/cart' },
              ].map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className="block px-3 py-3 rounded-xl text-base font-medium text-[#171A18] hover:bg-[#F1E5D8]"
                >
                  {link.label}
                </Link>
              ))}
            </nav>

            <div className="p-5 border-t border-[#EDE5DB] bg-white">
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  navigate('/shop');
                }}
                className="w-full py-3 rounded-lg bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734] cursor-pointer"
              >
                Shop Collection
              </button>
            </div>
          </aside>
        </div>
      )}
    </>
  );
}
