import { Facebook, Instagram, Lock, Pencil, Youtube } from 'lucide-react';
import { STORE_CONFIG } from '../../config/storeConfig';
import { useFirebase } from '../../context/FirebaseContext';
import { useStore } from '../../context/StoreContext';
import { Link } from '../../router/RouterContext';
import { BrandLogo } from '../common/BrandLogo';

export function Footer() {
  const { isAdmin } = useFirebase();
  const { socialLinks } = useStore();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#5A071A] text-white border-t border-[#961734]/40">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-10 py-14 lg:py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Column 1: Brand */}
          <div className="sm:col-span-2 lg:col-span-1 space-y-4">
            <Link to="/" className="inline-block">
              <BrandLogo variant="light" allowWrap />
            </Link>
            <p className="text-sm text-white/75 leading-relaxed">
              Thoughtfully curated fashion, accessories, beauty, and home essentials designed for enduring modern living.
            </p>
            <p className="text-xs text-white/60">
              {STORE_CONFIG.contact.email}
            </p>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h3 className="font-sans text-xs font-semibold uppercase tracking-[0.1em] text-[#EAB96B] mb-4">
              Quick Links
            </h3>
            <ul className="space-y-2.5 text-sm text-white/80">
              <li>
                <Link to="/" className="hover:text-white transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/shop" className="hover:text-white transition-colors">
                  Shop
                </Link>
              </li>
              {isAdmin && (
                <>
                  <li>
                    <Link to="/add-product" className="hover:text-white transition-colors">
                      Add / Edit Products
                    </Link>
                  </li>
                  <li>
                    <Link to="/add-product?tab=social" className="hover:text-white transition-colors">
                      Social Media Links
                    </Link>
                  </li>
                </>
              )}
              <li>
                <Link to="/about" className="hover:text-white transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-white transition-colors">
                  Contact
                </Link>
              </li>
              <li>
                <Link to="/blog" className="hover:text-white transition-colors">
                  Blog
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 3: Customer Care */}
          <div>
            <h3 className="font-sans text-xs font-semibold uppercase tracking-[0.1em] text-[#EAB96B] mb-4">
              Customer Care
            </h3>
            <ul className="space-y-2.5 text-sm text-white/80">
              <li>
                <Link to="/faq" className="hover:text-white transition-colors">
                  FAQ
                </Link>
              </li>
              <li>
                <Link to="/shipping-and-returns" className="hover:text-white transition-colors">
                  Shipping Information
                </Link>
              </li>
              <li>
                <Link to="/shipping-and-returns" className="hover:text-white transition-colors">
                  Return Policy
                </Link>
              </li>
              <li>
                <Link to="/order-confirmation" className="hover:text-white transition-colors">
                  Track Order
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-white transition-colors">
                  Help Center
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 4: Follow Us */}
          <div>
            <h3 className="font-sans text-xs font-semibold uppercase tracking-[0.1em] text-[#EAB96B] mb-4">
              Follow Us
            </h3>
            <ul className="space-y-2.5 text-sm text-white/80">
              {socialLinks.facebook && (
                <li>
                  <a
                    href={socialLinks.facebook}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2.5 hover:text-white transition-colors"
                  >
                    <Facebook className="w-4 h-4 text-[#EAB96B]" strokeWidth={1.75} />
                    <span>Facebook</span>
                  </a>
                </li>
              )}
              {socialLinks.instagram && (
                <li>
                  <a
                    href={socialLinks.instagram}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2.5 hover:text-white transition-colors"
                  >
                    <Instagram className="w-4 h-4 text-[#EAB96B]" strokeWidth={1.75} />
                    <span>Instagram</span>
                  </a>
                </li>
              )}
              {socialLinks.youtube && (
                <li>
                  <a
                    href={socialLinks.youtube}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2.5 hover:text-white transition-colors"
                  >
                    <Youtube className="w-4 h-4 text-[#EAB96B]" strokeWidth={1.75} />
                    <span>YouTube</span>
                  </a>
                </li>
              )}
              {socialLinks.pinterest && (
                <li>
                  <a
                    href={socialLinks.pinterest}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2.5 hover:text-white transition-colors"
                  >
                    <svg className="w-4 h-4 text-[#EAB96B]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
                      <circle cx="12" cy="12" r="9" />
                      <path d="M10 16l1.5-6M9.5 11.5c0-1.5 1.1-2.5 2.7-2.5 1.5 0 2.3 1 2.3 2.3 0 1.6-1 2.7-2.2 2.7-.6 0-1.1-.3-1.3-.8" strokeLinecap="round" />
                    </svg>
                    <span>Pinterest</span>
                  </a>
                </li>
              )}
              {socialLinks.tiktok && (
                <li>
                  <a
                    href={socialLinks.tiktok}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2.5 hover:text-white transition-colors"
                  >
                    <svg className="w-4 h-4 text-[#EAB96B]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
                      <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    <span>TikTok</span>
                  </a>
                </li>
              )}
            </ul>
            {isAdmin && (
              <div className="mt-4 pt-3 border-t border-white/10">
                <Link
                  to="/add-product?tab=social"
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-[#EAB96B] hover:text-white transition-colors"
                >
                  <Pencil className="w-3 h-3" />
                  <span>Add / Edit Social Links</span>
                </Link>
              </div>
            )}
          </div>

          {/* Column 5: Payment Methods */}
          <div>
            <h3 className="font-sans text-xs font-semibold uppercase tracking-[0.1em] text-[#EAB96B] mb-4">
              Payment Method
            </h3>
            <p className="text-xs text-white/75 mb-3 leading-relaxed">
              We exclusively accept Cash on Delivery for all orders.
            </p>
            <div className="flex flex-wrap gap-2">
              <span className="px-3 py-1.5 rounded-md bg-[#7A0B24] border border-[#EAB96B]/40 text-xs font-semibold text-white">
                Cash on Delivery (COD)
              </span>
            </div>
          </div>
        </div>

        {/* Bottom Legal Row */}
        <div className="mt-12 pt-7 border-t border-white/15 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-white/65">
          <p>
            © {currentYear} {STORE_CONFIG.legalEntity}. All rights reserved.
          </p>
          <div className="flex flex-wrap items-center gap-5">
            <Link to="/privacy-policy" className="hover:text-white transition-colors">
              Privacy Policy
            </Link>
            <Link to="/terms-and-conditions" className="hover:text-white transition-colors">
              Terms &amp; Conditions
            </Link>
            <Link to="/privacy-policy" className="hover:text-white transition-colors">
              Cookie Policy
            </Link>
            <Link
              to="/owner"
              className="inline-flex items-center gap-1 text-white/50 hover:text-[#EAB96B] transition-colors"
            >
              <Lock className="w-3 h-3" />
              <span>{isAdmin ? 'Owner Studio' : 'Owner'}</span>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
