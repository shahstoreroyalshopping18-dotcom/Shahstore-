export type CategorySlug =
  | 'women'
  | 'men'
  | 'accessories'
  | 'footwear'
  | 'beauty'
  | 'home-living';

export interface Category {
  id: string;
  slug: CategorySlug;
  name: string;
  description: string;
  image: string;
  imageAlt: string;
  productCount: number;
}

export interface ProductColorOption {
  name: string;
  hex: string;
}

export interface Product {
  id: string;
  sku: string;
  slug: string;
  name: string;
  categorySlug: CategorySlug;
  categoryName: string;
  price: number;
  originalPrice?: number;
  discountPercent?: number;
  rating: number;
  reviewCount: number;
  image: string;
  gallery: string[];
  imageAlt: string;
  shortDescription: string;
  description: string;
  materialsAndCare: string[];
  sizes?: string[];
  colors?: ProductColorOption[];
  stock: number;
  isBestSeller?: boolean;
  isNewArrival?: boolean;
  isOnSale?: boolean;
}

export interface CartItem {
  key: string;
  productId: string;
  slug: string;
  name: string;
  categoryName: string;
  image: string;
  imageAlt: string;
  price: number;
  originalPrice?: number;
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
}

export interface WishlistItem {
  productId: string;
  addedAt: string;
}

export interface CustomerInfo {
  fullName: string;
  phone: string;
  city: string;
  address: string;
  email?: string;
  postalCode?: string;
  country?: string;
  notes?: string;
}

export type PaymentMethodId = 'cod';

export type OrderStatus =
  | 'Order Received (COD)'
  | 'Preparing Shipment'
  | 'Dispatched'
  | 'Delivered'
  | 'Cancelled'
  | 'Demo Order Recorded (COD)';

export interface Order {
  id: string;
  orderNumber: string;
  createdAt: string;
  customer: CustomerInfo;
  items: CartItem[];
  subtotal: number;
  shippingCost: number;
  total: number;
  paymentMethod: PaymentMethodId;
  paymentVerified: boolean;
  isDemoOrder: boolean;
  status: OrderStatus;
}

export interface Review {
  id: string;
  authorName: string;
  authorLocation: string;
  authorAvatar: string;
  rating: number;
  quote: string;
  purchasedItem: string;
  isDemoSample: boolean;
}

export interface NewsletterSubscriber {
  email: string;
  subscribedAt: string;
  source: string;
}

export interface BlogPost {
  id: string;
  slug: string;
  title: string;
  category: string;
  publishedDate: string;
  readTime: string;
  excerpt: string;
  content: string[];
  image: string;
  imageAlt: string;
  author: string;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  category: 'Shipping' | 'Returns' | 'Orders' | 'Sizing';
}

export interface InventoryRecord {
  sku: string;
  productId: string;
  availableUnits: number;
  warehouseLocation: string;
}
