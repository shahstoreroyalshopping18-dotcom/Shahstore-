import { Review } from '../types/ecommerce';

export const SAMPLE_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    authorName: 'claire_bennett',
    authorLocation: 'Sample Review · Brooklyn, NY',
    authorAvatar: '/src/assets/images/customer_portrait_one_1794832188320.jpg',
    rating: 5,
    quote:
      'The Oatmeal Ribbed Cashmere Knit has an extraordinary weight and softness right out of the box. Packaging felt thoughtful and delivery arrived in three days.',
    purchasedItem: 'Oatmeal Ribbed Cashmere Knit',
    isDemoSample: true,
  },
  {
    id: 'rev-2',
    authorName: 'daniel_kaufman',
    authorLocation: 'Sample Review · Chicago, IL',
    authorAvatar: '/src/assets/images/customer_portrait_two_1794832188411.jpg',
    rating: 5,
    quote:
      'I picked up the Classic Premium Hoodie and Smartwatch Series together. Both look sharp enough for studio meetings yet comfortable enough for travel.',
    purchasedItem: 'Classic Premium Hoodie',
    isDemoSample: true,
  },
  {
    id: 'rev-3',
    authorName: 'sophia_lin',
    authorLocation: 'Sample Review · Seattle, WA',
    authorAvatar: '/src/assets/images/customer_portrait_three_1794832189329.jpg',
    rating: 5,
    quote:
      'Minimal Running Sneakers fit true to size with zero break-in time. The warm cream leather pairs effortlessly with tailored trousers and weekend denim.',
    purchasedItem: 'Minimal Running Sneakers',
    isDemoSample: true,
  },
];

export const DISPLAY_NAME_MAP: Record<string, string> = {
  claire_bennett: 'Claire Bennett',
  daniel_kaufman: 'Daniel Kaufman',
  sophia_lin: 'Sophia Lin',
};
