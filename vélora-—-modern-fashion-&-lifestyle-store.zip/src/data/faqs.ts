import { STORE_CONFIG } from '../config/storeConfig';
import { FaqItem } from '../types/ecommerce';

export const FAQ_ITEMS: FaqItem[] = [
  {
    id: 'faq-1',
    category: 'Shipping',
    question: 'Does my order qualify for free delivery across Pakistan?',
    answer:
      'Yes — Shah Store Royal Shopping offers 100% free delivery across all cities and regions of Pakistan on every order, with no minimum order amount required.',
  },
  {
    id: 'faq-2',
    category: 'Shipping',
    question: 'How long does All Pakistan free delivery take?',
    answer: `In-stock orders are packed at our studio within 24 business hours and typically arrive anywhere in Pakistan within ${STORE_CONFIG.shipping.estimatedDeliveryDays}.`,
  },
  {
    id: 'faq-3',
    category: 'Returns',
    question: 'What is your return and exchange policy?',
    answer:
      'Unworn, unwashed items with original tags and packaging may be returned or exchanged within 30 days of delivery. Fragrance bottles must remain sealed.',
  },
  {
    id: 'faq-4',
    category: 'Orders',
    question: 'What payment method is supported?',
    answer:
      'Shah Store Royal Shopping accepts Cash on Delivery (COD) exclusively. You pay directly upon courier delivery, and demonstration checkout records are saved locally in your browser until a live backend is connected.',
  },
  {
    id: 'faq-5',
    category: 'Sizing',
    question: 'How do your apparel and footwear sizes run?',
    answer:
      'Our apparel features a relaxed, contemporary fit—take your normal size for a balanced silhouette, or size down for a closer fit. Footwear runs true to European sizing.',
  },
];
