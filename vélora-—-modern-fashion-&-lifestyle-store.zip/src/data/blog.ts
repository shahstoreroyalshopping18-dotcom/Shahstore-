import { BlogPost } from '../types/ecommerce';

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'blog-1',
    slug: 'building-a-capsule-wardrobe-in-earth-tones',
    title: 'Building a Capsule Wardrobe Around Deep Forest & Warm Neutrals',
    category: 'Style Edit',
    publishedDate: 'November 2026',
    readTime: '4 min read',
    excerpt:
      'Why pairing rich botanical greens with travertine creams creates a calmer, more versatile closet for every season.',
    content: [
      'A well-edited wardrobe relies less on sheer volume and more on tonal harmony. When garments share a restrained palette—deep forest green, warm oatmeal, saddle cognac, and soft chalk—nearly every piece coordinates effortlessly.',
      'Start with three foundational textures: heavyweight organic cotton fleece for relaxed mornings, crisp Belgian linen-wool tailoring for structured days, and full-grain leather accessories that gain patina with age.',
      'By investing in natural fibers and disciplined silhouettes, getting dressed shifts from daily decision fatigue into a quiet, intentional ritual.',
    ],
    image: '/src/assets/images/category_women_fashion_1794832180483.jpg',
    imageAlt: 'Curated neutral silk dress and sage trench coat editorial flatlay',
    author: 'Elena Vance, Creative Director',
  },
  {
    id: 'blog-2',
    slug: 'caring-for-italian-suede-and-vegetable-tanned-leather',
    title: 'The Quiet Craft of Caring for Suede Footwear & Leather Goods',
    category: 'Craftsmanship',
    publishedDate: 'October 2026',
    readTime: '3 min read',
    excerpt:
      'Simple habits that keep full-grain calfskin bags and suede runners looking composed year after year.',
    content: [
      'Vegetable-tanned leather and fine Italian suede respond gracefully to regular, minimal care. Allow leather footwear to rest on cedar shoe trees between wears so natural moisture evaporates evenly.',
      'For suede panels on our Minimal Running Sneakers and Heritage Court Sneakers, a soft crepe brush restores the velvety nap after city walks without stripping natural oils.',
      'Store structured bags upright stuffed with acid-free tissue inside their organic cotton dust bags away from direct radiators.',
    ],
    image: '/src/assets/images/category_footwear_collection_1794832182655.jpg',
    imageAlt: 'Artisanal suede sneakers and leather loafers on travertine plinth',
    author: 'Marcus Sterling, Atelier Lead',
  },
  {
    id: 'blog-3',
    slug: 'tactile-living-ceramics-and-botanical-scent',
    title: 'Tactile Living: Pairing Stoneware Vessels with Botanical Fragrance',
    category: 'Home & Living',
    publishedDate: 'October 2026',
    readTime: '5 min read',
    excerpt:
      'How raw stoneware, natural linen, and warm sandalwood notes bring architectural serenity into everyday rooms.',
    content: [
      'Atmosphere at home is shaped through subtle sensory anchors: morning light across raw stoneware, the weight of a woven bouclé throw, and a grounded room scent that never overwhelms.',
      'Our Sculpted Stoneware Vessel is left unglazed on its exterior so the iron-flecked clay retains its earthy matte character next to travertine and warm oak.',
      'Pair tactile objects with warm woody fragrance notes—sandalwood, green cardamom, and amber—to establish an effortless transition from workday focus to evening calm.',
    ],
    image: '/src/assets/images/category_home_living_1794832182701.jpg',
    imageAlt: 'Matte ceramic vase, folded oat throw, and brass candle holder',
    author: 'Clara Moreau, Home Editor',
  },
];
