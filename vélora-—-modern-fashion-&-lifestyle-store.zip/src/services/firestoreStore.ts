import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { CategorySlug, Order, OrderStatus, Product } from '../types/ecommerce';
import { SocialLinksConfig } from './storeAdapter';

export interface FirestoreCatalogRecord extends Product {
  isDeleted: boolean;
  ownerId: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface FirestoreOrderRecord extends Order {
  createdAtTimestamp?: number;
}

function clampString(val: string | undefined, max: number, fallback = ''): string {
  const trimmed = (val ?? '').trim();
  if (!trimmed) return fallback;
  return trimmed.slice(0, max);
}

function sanitizeId(id: string): string {
  const cleaned = id.replace(/[^a-zA-Z0-9_-]/g, '-').slice(0, 128);
  return cleaned || `item-${Date.now()}`;
}

function sanitizeSlug(slug: string): string {
  const cleaned = slug
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 160);
  return cleaned || `item-${Date.now()}`;
}

const VALID_CATEGORIES: CategorySlug[] = [
  'women',
  'men',
  'accessories',
  'footwear',
  'beauty',
  'home-living',
];

function buildCatalogPayload(
  product: Product,
  ownerId: string,
  isDeleted: boolean,
  existingCreatedAt?: unknown
): Record<string, unknown> {
  const safeId = sanitizeId(product.id);
  const safeCategory: CategorySlug = VALID_CATEGORIES.includes(product.categorySlug)
    ? product.categorySlug
    : 'women';
  const safeGallery = (product.gallery?.length ? product.gallery : [product.image])
    .map((img) => img.slice(0, 300000))
    .filter(Boolean)
    .slice(0, 6);
  const primaryImage = (product.image || safeGallery[0] || '/assets/aistudio/file_00000000cec082119c5560af9ee80034_3edc34b2.png').slice(0, 300000);
  if (safeGallery.length === 0) {
    safeGallery.push(primaryImage);
  }
  const safeCare = (product.materialsAndCare?.length
    ? product.materialsAndCare
    : ['Premium quality finish']
  )
    .map((line) => clampString(line, 200))
    .filter(Boolean)
    .slice(0, 20);
  if (safeCare.length === 0) {
    safeCare.push('Premium quality finish');
  }

  const payload: Record<string, unknown> = {
    id: safeId,
    sku: clampString(product.sku, 40, `SHAH-${Date.now().toString().slice(-4)}`),
    slug: sanitizeSlug(product.slug || product.name),
    name: clampString(product.name, 160, 'Untitled Product'),
    categorySlug: safeCategory,
    categoryName: clampString(product.categoryName, 100, 'Collection'),
    price: Math.max(1, Math.min(100000000, Math.round(Number(product.price) || 1))),
    rating: Math.max(0, Math.min(5, Number(product.rating) || 5)),
    reviewCount: Math.max(0, Math.min(1000000, Math.round(Number(product.reviewCount) || 1))),
    image: primaryImage,
    gallery: safeGallery,
    imageAlt: clampString(product.imageAlt || product.name, 200, 'Product image'),
    shortDescription: clampString(product.shortDescription || product.description, 300, 'Curated essential'),
    description: clampString(product.description || product.shortDescription, 4000, 'Curated essential'),
    materialsAndCare: safeCare,
    stock: Math.max(0, Math.min(1000000, Math.round(Number(product.stock) || 0))),
    isBestSeller: Boolean(product.isBestSeller),
    isNewArrival: Boolean(product.isNewArrival),
    isOnSale: Boolean(product.isOnSale),
    isDeleted,
    ownerId: sanitizeId(ownerId),
    createdAt: existingCreatedAt ?? serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  if (
    typeof product.originalPrice === 'number' &&
    Number.isFinite(product.originalPrice) &&
    product.originalPrice > 0
  ) {
    payload.originalPrice = Math.min(100000000, Math.round(product.originalPrice));
  }

  if (
    typeof product.discountPercent === 'number' &&
    Number.isFinite(product.discountPercent) &&
    product.discountPercent >= 0 &&
    product.discountPercent <= 99
  ) {
    payload.discountPercent = Math.round(product.discountPercent);
  }

  if (product.sizes && product.sizes.length > 0) {
    const cleanSizes = product.sizes
      .map((s) => clampString(s, 40))
      .filter(Boolean)
      .slice(0, 20);
    if (cleanSizes.length > 0) {
      payload.sizes = cleanSizes;
    }
  }

  if (product.colors && product.colors.length > 0) {
    const cleanColors = product.colors
      .map((c) => ({
        name: clampString(c.name, 60, 'Color'),
        hex: clampString(c.hex, 20, '#7A0B24'),
      }))
      .slice(0, 20);
    if (cleanColors.length > 0) {
      payload.colors = cleanColors;
    }
  }

  return payload;
}

export function subscribeCatalogProducts(
  onData: (records: FirestoreCatalogRecord[]) => void
): () => void {
  const path = 'catalog_products';
  return onSnapshot(
    collection(db, path),
    (snapshot) => {
      const rows: FirestoreCatalogRecord[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data() as FirestoreCatalogRecord;
        rows.push({
          ...data,
          id: data.id || docSnap.id,
        });
      });
      onData(rows);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export async function upsertCatalogProduct(
  product: Product,
  ownerId: string,
  isDeleted = false
): Promise<void> {
  const safeId = sanitizeId(product.id);
  const path = `catalog_products/${safeId}`;
  const docRef = doc(db, 'catalog_products', safeId);
  try {
    const existingSnap = await getDoc(docRef);
    const existingData = existingSnap.exists() ? existingSnap.data() : null;
    const payload = buildCatalogPayload(
      product,
      ownerId,
      isDeleted,
      existingData?.createdAt
    );
    if (existingSnap.exists()) {
      const updateFields = { ...payload };
      delete updateFields.id;
      delete updateFields.ownerId;
      delete updateFields.createdAt;
      await updateDoc(docRef, updateFields);
    } else {
      await setDoc(docRef, payload);
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function removeCatalogProductDoc(productId: string): Promise<void> {
  const safeId = sanitizeId(productId);
  const path = `catalog_products/${safeId}`;
  try {
    await deleteDoc(doc(db, 'catalog_products', safeId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export function subscribeSocialSettings(
  onData: (links: SocialLinksConfig | null) => void
): () => void {
  const path = 'store_settings/social_links';
  return onSnapshot(
    doc(db, 'store_settings', 'social_links'),
    (docSnap) => {
      if (!docSnap.exists()) {
        onData(null);
        return;
      }
      const data = docSnap.data();
      onData({
        facebook: typeof data.facebook === 'string' ? data.facebook : '',
        instagram: typeof data.instagram === 'string' ? data.instagram : '',
        youtube: typeof data.youtube === 'string' ? data.youtube : '',
        pinterest: typeof data.pinterest === 'string' ? data.pinterest : '',
        tiktok: typeof data.tiktok === 'string' ? data.tiktok : '',
      });
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    }
  );
}

export async function saveSocialSettings(
  links: SocialLinksConfig,
  ownerId: string
): Promise<void> {
  const path = 'store_settings/social_links';
  const docRef = doc(db, 'store_settings', 'social_links');
  try {
    const existingSnap = await getDoc(docRef);
    const baseFields = {
      facebook: clampString(links.facebook, 300),
      instagram: clampString(links.instagram, 300),
      youtube: clampString(links.youtube, 300),
      pinterest: clampString(links.pinterest, 300),
      tiktok: clampString(links.tiktok, 300),
      updatedAt: serverTimestamp(),
    };
    if (existingSnap.exists()) {
      await updateDoc(docRef, baseFields);
    } else {
      await setDoc(docRef, {
        ...baseFields,
        ownerId: sanitizeId(ownerId),
        createdAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function createFirestoreOrder(order: Order): Promise<void> {
  const safeId = sanitizeId(order.id);
  const path = `orders/${safeId}`;
  const cleanItems = order.items.slice(0, 50).map((item) => {
    const clean: Record<string, unknown> = {
      key: clampString(item.key, 200, item.productId),
      productId: clampString(item.productId, 128),
      slug: clampString(item.slug, 160),
      name: clampString(item.name, 160),
      categoryName: clampString(item.categoryName, 100),
      image: clampString(item.image, 300000),
      imageAlt: clampString(item.imageAlt || item.name, 200),
      price: Math.max(1, Math.min(100000000, Math.round(item.price))),
      quantity: Math.max(1, Math.min(100, Math.round(item.quantity))),
    };
    if (typeof item.originalPrice === 'number' && item.originalPrice >= 0) {
      clean.originalPrice = Math.min(100000000, Math.round(item.originalPrice));
    }
    if (item.selectedSize) {
      clean.selectedSize = clampString(item.selectedSize, 40);
    }
    if (item.selectedColor) {
      clean.selectedColor = clampString(item.selectedColor, 60);
    }
    return clean;
  });

  const subtotal = Math.max(1, Math.min(500000000, Math.round(order.subtotal)));
  const payload = {
    id: safeId,
    orderNumber: order.orderNumber,
    customer: {
      fullName: clampString(order.customer.fullName, 120, 'Customer'),
      phone: clampString(order.customer.phone, 30, '0000000'),
      city: clampString(order.customer.city, 80, 'Pakistan'),
      address: clampString(order.customer.address, 500, 'Delivery address'),
    },
    items: cleanItems,
    subtotal,
    shippingCost: 0,
    total: subtotal,
    paymentMethod: 'cod',
    status: 'Order Received (COD)',
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  try {
    await setDoc(doc(db, 'orders', safeId), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export function subscribeOwnerOrders(
  onData: (orders: Order[]) => void
): () => void {
  const path = 'orders';
  const q = query(collection(db, path), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const list: Order[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        const createdAtIso =
          data.createdAt instanceof Timestamp
            ? data.createdAt.toDate().toISOString()
            : typeof data.createdAt === 'string'
              ? data.createdAt
              : new Date().toISOString();
        list.push({
          id: data.id || docSnap.id,
          orderNumber: data.orderNumber,
          createdAt: createdAtIso,
          customer: data.customer,
          items: data.items || [],
          subtotal: Number(data.subtotal) || 0,
          shippingCost: Number(data.shippingCost) || 0,
          total: Number(data.total) || 0,
          paymentMethod: 'cod',
          paymentVerified: false,
          isDemoOrder: false,
          status: (data.status as OrderStatus) || 'Order Received (COD)',
        });
      });
      onData(list);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export async function updateFirestoreOrderStatus(
  orderId: string,
  status: OrderStatus
): Promise<void> {
  const safeId = sanitizeId(orderId);
  const path = `orders/${safeId}`;
  try {
    await updateDoc(doc(db, 'orders', safeId), {
      status,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteFirestoreOrder(orderId: string): Promise<void> {
  const safeId = sanitizeId(orderId);
  const path = `orders/${safeId}`;
  try {
    await deleteDoc(doc(db, 'orders', safeId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
