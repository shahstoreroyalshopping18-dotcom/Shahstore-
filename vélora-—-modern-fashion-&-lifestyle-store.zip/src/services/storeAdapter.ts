import { STORE_CONFIG, StoreConfig } from '../config/storeConfig';
import { CATEGORIES } from '../data/categories';
import { PRODUCTS } from '../data/products';
import {
  CartItem,
  Category,
  NewsletterSubscriber,
  Order,
  Product,
  WishlistItem,
} from '../types/ecommerce';

export type SocialLinksConfig = StoreConfig['socialLinks'];

const STORAGE_KEYS = {
  CART: 'velora_cart_v1',
  WISHLIST: 'velora_wishlist_v1',
  ORDERS: 'velora_demo_orders_v1',
  NEWSLETTER: 'velora_newsletter_v1',
  CUSTOM_PRODUCTS: 'shah_custom_products_v1',
  DELETED_PRODUCT_IDS: 'shah_deleted_product_ids_v1',
  PRODUCT_OVERRIDES: 'shah_product_overrides_v1',
  SOCIAL_LINKS: 'shah_social_links_v1',
} as const;

/**
 * StoreDataAdapter defines the contract for swapping localStorage persistence
 * with Firebase Firestore, Supabase, or a custom REST/GraphQL backend.
 */
export interface StoreDataAdapter {
  getProducts(): Product[];
  loadCustomProducts(): Product[];
  saveCustomProducts(products: Product[]): void;
  loadDeletedProductIds(): string[];
  saveDeletedProductIds(ids: string[]): void;
  loadProductOverrides(): Record<string, Product>;
  saveProductOverrides(overrides: Record<string, Product>): void;
  loadSocialLinks(): SocialLinksConfig;
  saveSocialLinks(links: SocialLinksConfig): void;
  getProductBySlug(slug: string): Product | undefined;
  getCategories(): Category[];
  loadCart(): CartItem[];
  saveCart(items: CartItem[]): void;
  loadWishlist(): WishlistItem[];
  saveWishlist(items: WishlistItem[]): void;
  loadOrders(): Order[];
  saveOrder(order: Order): void;
  getOrderByNumber(orderNumber: string): Order | undefined;
  saveNewsletterSubscriber(sub: NewsletterSubscriber): void;
  hasSubscribed(email: string): boolean;
}

function safeParse<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export const localStoreAdapter: StoreDataAdapter = {
  getProducts: () => {
    const deletedSet = new Set(localStoreAdapter.loadDeletedProductIds());
    const overrides = localStoreAdapter.loadProductOverrides();
    return [
      ...localStoreAdapter.loadCustomProducts(),
      ...PRODUCTS.map((p) => overrides[p.id] ?? p),
    ].filter((p) => !deletedSet.has(p.id));
  },

  loadCustomProducts: () => {
    if (typeof window === 'undefined') return [];
    return safeParse<Product[]>(
      window.localStorage.getItem(STORAGE_KEYS.CUSTOM_PRODUCTS),
      []
    );
  },

  saveCustomProducts: (products: Product[]) => {
    if (typeof window === 'undefined') return;
    window.localStorage.setItem(
      STORAGE_KEYS.CUSTOM_PRODUCTS,
      JSON.stringify(products)
    );
  },

  loadDeletedProductIds: () => {
    if (typeof window === 'undefined') return [];
    return safeParse<string[]>(
      window.localStorage.getItem(STORAGE_KEYS.DELETED_PRODUCT_IDS),
      []
    );
  },

  saveDeletedProductIds: (ids: string[]) => {
    if (typeof window === 'undefined') return;
    window.localStorage.setItem(
      STORAGE_KEYS.DELETED_PRODUCT_IDS,
      JSON.stringify(ids)
    );
  },

  loadProductOverrides: () => {
    if (typeof window === 'undefined') return {};
    return safeParse<Record<string, Product>>(
      window.localStorage.getItem(STORAGE_KEYS.PRODUCT_OVERRIDES),
      {}
    );
  },

  saveProductOverrides: (overrides: Record<string, Product>) => {
    if (typeof window === 'undefined') return;
    window.localStorage.setItem(
      STORAGE_KEYS.PRODUCT_OVERRIDES,
      JSON.stringify(overrides)
    );
  },

  loadSocialLinks: () => {
    if (typeof window === 'undefined') return STORE_CONFIG.socialLinks;
    const saved = safeParse<Partial<SocialLinksConfig> | null>(
      window.localStorage.getItem(STORAGE_KEYS.SOCIAL_LINKS),
      null
    );
    if (!saved) return STORE_CONFIG.socialLinks;
    return {
      facebook: saved.facebook ?? STORE_CONFIG.socialLinks.facebook,
      instagram: saved.instagram ?? STORE_CONFIG.socialLinks.instagram,
      youtube: saved.youtube ?? STORE_CONFIG.socialLinks.youtube,
      pinterest: saved.pinterest ?? STORE_CONFIG.socialLinks.pinterest,
      tiktok: saved.tiktok ?? STORE_CONFIG.socialLinks.tiktok,
    };
  },

  saveSocialLinks: (links: SocialLinksConfig) => {
    if (typeof window === 'undefined') return;
    window.localStorage.setItem(
      STORAGE_KEYS.SOCIAL_LINKS,
      JSON.stringify(links)
    );
  },

  getProductBySlug: (slug: string) =>
    localStoreAdapter.getProducts().find((p) => p.slug === slug),

  getCategories: () => CATEGORIES,

  loadCart: () => {
    if (typeof window === 'undefined') return [];
    return safeParse<CartItem[]>(window.localStorage.getItem(STORAGE_KEYS.CART), []);
  },

  saveCart: (items: CartItem[]) => {
    if (typeof window === 'undefined') return;
    window.localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(items));
  },

  loadWishlist: () => {
    if (typeof window === 'undefined') return [];
    return safeParse<WishlistItem[]>(window.localStorage.getItem(STORAGE_KEYS.WISHLIST), []);
  },

  saveWishlist: (items: WishlistItem[]) => {
    if (typeof window === 'undefined') return;
    window.localStorage.setItem(STORAGE_KEYS.WISHLIST, JSON.stringify(items));
  },

  loadOrders: () => {
    if (typeof window === 'undefined') return [];
    return safeParse<Order[]>(window.localStorage.getItem(STORAGE_KEYS.ORDERS), []);
  },

  saveOrder: (order: Order) => {
    if (typeof window === 'undefined') return;
    const existing = localStoreAdapter.loadOrders();
    window.localStorage.setItem(
      STORAGE_KEYS.ORDERS,
      JSON.stringify([order, ...existing])
    );
  },

  getOrderByNumber: (orderNumber: string) => {
    const orders = localStoreAdapter.loadOrders();
    return orders.find(
      (o) => o.orderNumber.toLowerCase() === orderNumber.trim().toLowerCase()
    );
  },

  saveNewsletterSubscriber: (sub: NewsletterSubscriber) => {
    if (typeof window === 'undefined') return;
    const existing = safeParse<NewsletterSubscriber[]>(
      window.localStorage.getItem(STORAGE_KEYS.NEWSLETTER),
      []
    );
    const deduped = [
      sub,
      ...existing.filter((item) => item.email.toLowerCase() !== sub.email.toLowerCase()),
    ];
    window.localStorage.setItem(STORAGE_KEYS.NEWSLETTER, JSON.stringify(deduped));
  },

  hasSubscribed: (email: string) => {
    if (typeof window === 'undefined') return false;
    const existing = safeParse<NewsletterSubscriber[]>(
      window.localStorage.getItem(STORAGE_KEYS.NEWSLETTER),
      []
    );
    return existing.some((item) => item.email.toLowerCase() === email.trim().toLowerCase());
  },
};
