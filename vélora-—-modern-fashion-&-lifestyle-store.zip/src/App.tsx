import { CartDrawer } from './components/common/CartDrawer';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { SearchModal } from './components/common/SearchModal';
import { ToastNotification } from './components/common/ToastNotification';
import { Footer } from './components/layout/Footer';
import { Header } from './components/layout/Header';
import { FirebaseProvider } from './context/FirebaseContext';
import { StoreProvider } from './context/StoreContext';
import { AboutPage } from './pages/AboutPage';
import { AddProductPage } from './pages/AddProductPage';
import { BlogPage } from './pages/BlogPage';
import { CartPage } from './pages/CartPage';
import { CategoriesPage } from './pages/CategoriesPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { ContactPage } from './pages/ContactPage';
import { FaqPage } from './pages/FaqPage';
import { HomePage } from './pages/HomePage';
import { OrderConfirmationPage } from './pages/OrderConfirmationPage';
import { PolicyPage } from './pages/PolicyPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { ShopPage } from './pages/ShopPage';
import { WishlistPage } from './pages/WishlistPage';
import { Link, RouterProvider, useRouter } from './router/RouterContext';

function PageSwitch() {
  const { pathname } = useRouter();
  const cleanPath = pathname.length > 1 ? pathname.replace(/\/+$/, '') : pathname;

  if (cleanPath === '/') return <HomePage />;
  if (cleanPath === '/shop') return <ShopPage />;
  if (cleanPath === '/add-product' || cleanPath === '/owner' || cleanPath === '/admin') {
    return <AddProductPage />;
  }
  if (cleanPath === '/categories') return <CategoriesPage />;
  if (cleanPath.startsWith('/product/')) {
    const slug = cleanPath.replace('/product/', '');
    return <ProductDetailPage slug={slug} />;
  }
  if (cleanPath === '/wishlist') return <WishlistPage />;
  if (cleanPath === '/cart') return <CartPage />;
  if (cleanPath === '/checkout') return <CheckoutPage />;
  if (cleanPath === '/order-confirmation') return <OrderConfirmationPage />;
  if (cleanPath === '/about') return <AboutPage />;
  if (cleanPath === '/contact') return <ContactPage />;
  if (cleanPath === '/faq') return <FaqPage />;
  if (cleanPath === '/blog') return <BlogPage />;
  if (cleanPath === '/privacy-policy') return <PolicyPage type="privacy" />;
  if (cleanPath === '/terms-and-conditions') return <PolicyPage type="terms" />;
  if (cleanPath === '/shipping-and-returns') return <PolicyPage type="shipping" />;

  return (
    <div className="bg-[#FFF9F1] py-20 px-4 text-center">
      <h1 className="font-editorial text-4xl font-semibold text-[#171A18] mb-3">
        Page Not Found
      </h1>
      <p className="text-sm text-[#77736D] mb-6">
        The requested page could not be located.
      </p>
      <Link
        to="/"
        className="inline-flex px-6 py-3 rounded-xl bg-[#7A0B24] text-white text-sm font-semibold hover:bg-[#961734]"
      >
        Return Home
      </Link>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <RouterProvider>
        <FirebaseProvider>
          <StoreProvider>
            <div className="min-h-screen flex flex-col bg-[#FFF9F1] text-[#171A18]">
              <Header />
              <main className="flex-1">
                <PageSwitch />
              </main>
              <Footer />
              <CartDrawer />
              <SearchModal />
              <ToastNotification />
            </div>
          </StoreProvider>
        </FirebaseProvider>
      </RouterProvider>
    </ErrorBoundary>
  );
}
