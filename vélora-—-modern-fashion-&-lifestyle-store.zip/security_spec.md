# Security Specification — Shah Store Royal Shopping

## 1. Data Invariants
1. **Owner-Only Store Settings & Catalog Writes**: Only the verified store owner (`asadumrani360@gmail.com` or an entry in `/admins/{uid}`) can create, update, or delete documents in `/catalog_products/{productId}` and `/store_settings/{settingId}`. Public visitors have read-only access to the storefront catalog and social links.
2. **Path & ID Integrity**: Every single-document operation (`get`, `create`, `update`, `delete`) enforces `isValidId()` (`^[a-zA-Z0-9_\-]+$`, `<= 128` chars), and on creation `incoming().id == pathId`.
3. **Immutable Ownership & Timestamps**: `ownerId` and `createdAt` cannot be modified after creation. All `createdAt` (on create) and `updatedAt` (on create/update) fields must strictly equal `request.time`.
4. **PII Isolation on Customer Orders (`/orders/{orderId}`)**: Public shoppers can submit validated Cash on Delivery orders (`paymentMethod == 'cod'`, `shippingCost == 0`, `status == 'Order Received (COD)'`) without authentication, but `get`, `list`, `update`, and `delete` on `/orders` are strictly restricted to the verified store owner so no customer phone numbers or addresses can ever be scraped.
5. **Bounded Strings & Lists**: All strings and arrays (`gallery <= 6`, `materialsAndCare <= 20`, `sizes <= 20`, `colors <= 20`, `items <= 50`) enforce strict `.size()` limits to prevent document-size and Denial-of-Wallet attacks.
6. **Terminal Order State Protection**: Once an order reaches a terminal status (`Delivered` or `Cancelled`), updates are blocked unless overridden by `isAdmin()`.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Unauthenticated Product Creation**: Anonymous visitor attempts `setDoc(/catalog_products/hack-1, ...)` -> `PERMISSION_DENIED`.
2. **Non-Owner Authenticated Product Creation**: Customer signed in with a non-owner Gmail account attempts `setDoc(/catalog_products/hack-2, ...)` -> `PERMISSION_DENIED`.
3. **Unverified Admin Email Spoof**: User with `email: 'asadumrani360@gmail.com'` and `email_verified: false` attempts write -> `PERMISSION_DENIED`.
4. **Shadow Ghost Field Injection on Product**: Owner or attacker adds `"isAdmin": true` or `"ghostField": 123` to `/catalog_products/prod-1` -> `PERMISSION_DENIED` (`keys().hasOnly(...)`).
5. **Social Links Tampering**: Non-admin user attempts to overwrite `/store_settings/social_links` -> `PERMISSION_DENIED`.
6. **Order PII Scraping (`list` / `get`)**: Public visitor or non-owner signed-in user attempts `getDocs(/orders)` or `getDoc(/orders/ord-1)` -> `PERMISSION_DENIED`.
7. **Order Shipping Cost Manipulation**: Shopper submits order with `shippingCost: -500` or `paymentMethod: 'stripe'` -> `PERMISSION_DENIED`.
8. **Order Status Bypass on Create**: Shopper submits new order with `status: 'Delivered'` instead of `'Order Received (COD)'` -> `PERMISSION_DENIED`.
9. **Client Timestamp Forgery**: Payload includes `createdAt: "2020-01-01T00:00:00Z"` instead of `request.time` -> `PERMISSION_DENIED`.
10. **ID Poisoning**: Single-doc request with 500-char ID or `/../` characters -> `PERMISSION_DENIED` (`isValidId()`).
11. **Unbounded Array / Resource Exhaustion**: Product created with 15 gallery URLs (> 6 max) or 50KB `name` string -> `PERMISSION_DENIED`.
12. **Self-Assigned Admin Escalation**: Non-primary user attempts `setDoc(/admins/selfUid, { role: 'owner' })` -> `PERMISSION_DENIED`.
